package com.demo.cadena.tcil.entity;

import java.util.Objects;


/**
 * DSRDetails
 */

public class DSRDetails   {

  private Long id = null;

  private String dsrNo = null;

  private String description = null;

  public DSRDetails id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public DSRDetails dsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
    return this;
  }

  /**
   * Get dsrNo
   * @return dsrNo
  **/

  public String getDsrNo() {
    return dsrNo;
  }

  public void setDsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
  }

  public DSRDetails description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
  **/


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DSRDetails dsRDetails = (DSRDetails) o;
    return Objects.equals(this.id, dsRDetails.id) &&
        Objects.equals(this.dsrNo, dsRDetails.dsrNo) &&
        Objects.equals(this.description, dsRDetails.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, dsrNo, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DSRDetails {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    dsrNo: ").append(toIndentedString(dsrNo)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

