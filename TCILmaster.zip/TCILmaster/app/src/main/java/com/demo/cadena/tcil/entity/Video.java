package com.demo.cadena.tcil.entity;

import java.util.Objects;
/**
 * Video
 */

public class Video   {
  private Long id = null;

  private String link = null;

  private double latitude = 0;

  private double longitude = 0;

  private String description = null;

  public Video id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Video link(String link) {
    this.link = link;
    return this;
  }

  /**
   * Get link
   * @return link
  **/


  public String getLink() {
    return link;
  }

  public void setLink(String link) {
    this.link = link;
  }

  public Video latitude(double latitude) {
    this.latitude = latitude;
    return this;
  }

  /**
   * Get latitude
   * @return latitude
  **/


  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public Video longitude(double longitude) {
    this.longitude = longitude;
    return this;
  }

  /**
   * Get longitude
   * @return longitude
  **/


  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  public Video description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
  **/


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Video video = (Video) o;
    return Objects.equals(this.id, video.id) &&
        Objects.equals(this.link, video.link) &&
        Objects.equals(this.latitude, video.latitude) &&
        Objects.equals(this.longitude, video.longitude) &&
        Objects.equals(this.description, video.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, link, latitude, longitude, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Video {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    link: ").append(toIndentedString(link)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

