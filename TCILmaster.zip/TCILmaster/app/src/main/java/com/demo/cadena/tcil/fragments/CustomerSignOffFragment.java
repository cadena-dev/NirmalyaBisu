package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.Image;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;
import com.demo.cadena.tcil.utils.DatabaseInitializer;
import com.demo.cadena.tcil.utils.SubmitPDFCompose;
import com.github.gcacace.signaturepad.views.SignaturePad;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link CustomerSignOffFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CustomerSignOffFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private static final String TAG = "CustomerSignOff";

    //private OnFragmentInteractionListener mListener;

    private TextView txtFormId;
    //private TextView txtClientName;
    private EditText edtCustomerName;
    private SignaturePad signaturePad;
//    private RatingBar rbWellTrainedEngg;
//    private RatingBar rbProfessionalStandard;
//    private RatingBar rbWellSupervisedEngineer;
//    private RatingBar rbCustomerSatisfied;
    private EditText edtCustomerComment;
    private Button btnSubmitData;
    //private Button btnSave;
    private Button btnClear;

    public CustomerSignOffFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CustomerSignOffFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CustomerSignOffFragment newInstance(String param1, String param2) {
        CustomerSignOffFragment fragment = new CustomerSignOffFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_sign_off, container, false);

        initializeViews(view);

        loadDBData();

        //disable both buttons at start
        btnSubmitData.setEnabled(false);
        btnClear.setEnabled(false);

        signaturePad.setOnSignedListener(new SignaturePad.OnSignedListener() {
            @Override
            public void onStartSigning() {

            }

            @Override
            public void onSigned() {
                btnSubmitData.setEnabled(true);
                btnClear.setEnabled(true);
            }

            @Override
            public void onClear() {
                btnSubmitData.setEnabled(false);
                btnClear.setEnabled(false);
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signaturePad.clear();
            }
        });

        btnSubmitData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Confirm Submit !");
                builder.setMessage("Are you sure you want to submit the data ?");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Data submitted successfully !", Toast.LENGTH_SHORT).show();

                        DigitalFormActivity.SELECTEDFORM.setCustomerName(edtCustomerName.getText().toString());
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        Bitmap bitmap = signaturePad.getSignatureBitmap();

                        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL";
                        File dir = new File(path);
                        if (!dir.exists()) {
                            dir.mkdirs();
                        }

                        File dest = new File(dir, "Sign" + DigitalFormActivity.SELECTEDFORM.getFormid() + ".jpg");
                        FileOutputStream out = null;
                        try {
                            out = new FileOutputStream(dest);
                            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                            out.flush();
                            out.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                if (out != null) {
                                    out.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                        DigitalFormActivity.SELECTEDFORM.setCustomerSignature(dest.getAbsolutePath());


//                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
//                        byte[] bytes = byteArrayOutputStream.toByteArray();
//                        DigitalFormActivity.SELECTEDFORM.setCustomerSignature(bytes);
//                        DigitalFormActivity.SELECTEDFORM.setWellTrainedEngineer(rbWellTrainedEngg.getRating());
//                        DigitalFormActivity.SELECTEDFORM.setWellSupervisedEngineer(rbWellSupervisedEngineer.getRating());
//                        DigitalFormActivity.SELECTEDFORM.setProfessionalStandard(rbProfessionalStandard.getRating());
//                        DigitalFormActivity.SELECTEDFORM.setCustomerSatisfied(rbCustomerSatisfied.getRating());
                        DigitalFormActivity.SELECTEDFORM.setCustomerComment(edtCustomerComment.getText().toString());

//                        if (DigitalFormActivity.SELECTEDFORM.getFormStatus().equals(DigitalFormActivity.INBOX) || DigitalFormActivity.SELECTEDFORM.getFormStatus().equals(DigitalFormActivity.DRAFT)) {
//                        if (isOnline()) {
//                            DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.SENT);
//                            DigitalFormActivity.SELECTEDFORM.setSync(false);
//                        } else {
//                            DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
//                            DigitalFormActivity.SELECTEDFORM.setSync(true);
//                        }


//                        Activity activity = new Activity();
//                        activity.setActivityId(DigitalFormActivity.SELECTEDFORM.getJobid());
//                        Job job = new Job();
//                        job.setJobId(DigitalFormActivity.SELECTEDFORM.getFormid());
//                        activity.setCivilJob(job);
//                        activity.setActivity_status("completed");
//                        activity.setCompleteDate(new Date().toString());
//                        APICalls.updateActivity(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, activity);

//                        DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
//                        DigitalFormActivity.initializeLists(getActivity());

                        SubmitPDFCompose.getSubmitPDF(getActivity());

                        startActivity(new Intent(getActivity(), DigitalFormActivity.class));

//                        HomeFragment videoReferenceFragment = HomeFragment.newInstance("", "");
////                        FrameLayout fl = (FrameLayout) view.findViewById(R.id.main_frame);
////                        DigitalFormActivity.MAIN_FRAME.removeAllViews();
//                        FragmentManager fm = getActivity().getSupportFragmentManager();
//                        fm.popBackStack();
//                        FragmentTransaction transaction = fm.beginTransaction();
////                        transaction.remove(fm.findFragmentByTag(DraftJobsFragment.TAG));
////                        transaction.remove(fm.findFragmentByTag(InboxJobsFragment.TAG));
//                        transaction.replace(R.id.main_frame, videoReferenceFragment);
//                        transaction.disallowAddToBackStack();
//                        transaction.addToBackStack(HomeFragment.TAG);
//                        transaction.commit();

                        emailSend();

                        getAndupdateActivity(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, getContext());
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Submission Cancelled !", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.show();

                //Toast.makeText(getActivity(),"Data submitted successfully !",Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }

    private void getAndupdateActivity(JobsService jobService, AppExecutors appExecutors, Context context) {
        appExecutors.getNetworkIO().execute(() -> {
            jobService.getActivityById(DigitalFormActivity.SELECTEDFORM.getJobid()+""
                    , APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Activity activity = response.body();
                        activity.setComment(DigitalFormActivity.SELECTEDFORM.getCustomerComment());
                        activity.setInspector(DigitalFormActivity.SELECTEDFORM.getInspector());
                        activity.setLocation(DigitalFormActivity.SELECTEDFORM.getJobLocation());
                        updateActivity(jobService, appExecutors, context, activity);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    private void updateActivity(JobsService jobService, AppExecutors appExecutors, Context context, Activity activity) {
        Log.e(TAG, activity.toString());
        appExecutors.getNetworkIO().execute(() -> {
            jobService.updateActivity(activity, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, "Activity updated");
                        Toast.makeText(getContext(), "Activity updated", Toast.LENGTH_LONG).show();
                        APICalls.updateActivityStatus(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, getContext(), "completed", DigitalFormActivity.SELECTEDFORM.getJobid()+"");
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + t.getMessage());
                }
            });
        });
    }

    private void emailSend() {
        Log.e("Send email", "");
        Intent emailIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
        String[] TO = {""};
        String[] CC = {""};

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        //emailIntent.putExtra(Intent.EXTRA_SUBJECT, "TCIL Project Automation");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "TCIL Project Automation");
        String emailBody = "SITE INFORMATION DETAIL \n\n Job Id : "+ Integer.toString(DigitalFormActivity.SELECTEDFORM.getFormid())+
                            "\nClient Name : "+ DigitalFormActivity.SELECTEDFORM.getClientName()+
                            "\nJob Title : "+DigitalFormActivity.SELECTEDFORM.getProject();
//                            if(DigitalFormActivity.SELECTEDFORM.getJobDescription() != null){
//                                emailBody = emailBody + "\nDescription : "+DigitalFormActivity.SELECTEDFORM.getJobDescription();
//                            }else {
//                                emailBody = emailBody + "\nDescription : "+" ";
//                            }
//                            if(DigitalFormActivity.SELECTEDFORM.getInspector() != null) {
//                                emailBody = emailBody + "\nInspector : " + DigitalFormActivity.SELECTEDFORM.getInspector();
//                            }else {
//                                emailBody = emailBody + "\nInspector : "+" ";
//                            }
                            if(DigitalFormActivity.SELECTEDFORM.getJobLocation() != null) {
                                emailBody = emailBody + "\nJob Location : " + DigitalFormActivity.SELECTEDFORM.getJobLocation();
                            }else
                            {
                                emailBody = emailBody + "\nJob Location : "+" ";
                            }
//                            emailBody = emailBody + "\n\nEVALUATING YOUR WORK AREA\n\n"+
//                            "Do you have appropriate labor license? : "+DigitalFormActivity.SELECTEDFORM.isWalked()+
//                            "\nDo you have certified labor resources? : "+DigitalFormActivity.SELECTEDFORM.isLiveSystem()+
//                            "\nDo you have any site access hours? : "+DigitalFormActivity.SELECTEDFORM.isTrained()+
//                            "\nHazardous material facility? : "+DigitalFormActivity.SELECTEDFORM.isMsds()+
//                            "\nAny specific truck capacity? : "+DigitalFormActivity.SELECTEDFORM.isAirMonitoring()+
//                            "\nDo workers have the necessary tools and equipments to get the jobs completed on schedule, avoiding cost overruns and penalties? : "+DigitalFormActivity.SELECTEDFORM.isWorkPermits()+
//                            "\n\nEQUIPMENT DETAILS\n\n";
//                            if(DigitalFormActivity.SELECTEDFORM.getScanContent() != null){
//                                emailBody = emailBody + "Barcode / QR Value : "+DigitalFormActivity.SELECTEDFORM.getScanContent();
//                            }else {
//                                emailBody = emailBody + "Barcode / QR Value : " + " ";
//                            }
                            emailBody = emailBody + "\n\nSIGN OFF\n\n";
                            if(DigitalFormActivity.SELECTEDFORM.getCustomerName() != null) {
                                emailBody=emailBody+"Engineer name : " + DigitalFormActivity.SELECTEDFORM.getCustomerName();
                            }
                            else {
                                emailBody=emailBody+"Engineer name : "+ " ";
                            }
//                            emailBody=emailBody+"\nCustomer Rating->"+
//                            "\nHow well trained were the service representatives? : "+DigitalFormActivity.SELECTEDFORM.getWellTrainedEngineer()+
//                            "\nDo service representatives adhere to professional standards of conduct? : "+DigitalFormActivity.SELECTEDFORM.getProfessionalStandard()+
//                            "\nWere the service representatives well supervised? : "+DigitalFormActivity.SELECTEDFORM.getWellSupervisedEngineer()+
//                            "\nOverall, how satisfied am I with the service? : "+DigitalFormActivity.SELECTEDFORM.getCustomerSatisfied()+"\n";

                            emailIntent.putExtra(Intent.EXTRA_TEXT, emailBody);

        try {
//            File file = new File(DigitalFormActivity.SELECTEDFORM.getImage());
//            FileOutputStream fOut = new FileOutputStream(file);
//            fOut.write(DigitalFormActivity.SELECTEDFORM.getImage());
//            fOut.close();
//            emailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            ArrayList<Uri> uris = new ArrayList<Uri>();
            // Image 1

            if (DigitalFormActivity.SELECTEDFORM.getImage() != null) {
                File img = new File(DigitalFormActivity.SELECTEDFORM.getImage());
//                APICalls.uploadSingleImage(DigitalFormActivity.mService,
//                        DigitalFormActivity.appExecutors,
//                        DigitalFormActivity.SELECTEDFORM.getFormid(),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage1Lat()),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage1Long()),
//                        DigitalFormActivity.SELECTEDFORM.getImageComment(),
//                        Long.parseLong(DigitalFormActivity.EMPLOYEE_ID),
//                        DigitalFormActivity.SELECTEDFORM.getImage1Timestamp(),
//                        img);
                APICalls.uploadActivityImage(ApiUtils.getJobService(),
                        DigitalFormActivity.appExecutors,
                        DigitalFormActivity.SELECTEDFORM.getJobid()+"",
                        img,
                        DigitalFormActivity.SELECTEDFORM.getImage1Lat(),
                        DigitalFormActivity.SELECTEDFORM.getImage1Long(),
                        DigitalFormActivity.SELECTEDFORM.getImageComment());
                Uri imgPath = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", img);
                uris.add(imgPath);
                emailIntent.setType("application/image");

            }
            // Image 2

            if (DigitalFormActivity.SELECTEDFORM.getImage2() != null) {
                File img2 = new File(DigitalFormActivity.SELECTEDFORM.getImage2());
//                APICalls.uploadSingleImage(DigitalFormActivity.mService,
//                        DigitalFormActivity.appExecutors,
//                        DigitalFormActivity.SELECTEDFORM.getFormid(),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage2Lat()),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage2Long()),
//                        DigitalFormActivity.SELECTEDFORM.getImageComment2(),
//                        Long.parseLong(DigitalFormActivity.EMPLOYEE_ID),
//                        DigitalFormActivity.SELECTEDFORM.getImage2Timestamp(),
//                        img2);
                APICalls.uploadActivityImage(ApiUtils.getJobService(),
                        DigitalFormActivity.appExecutors,
                        DigitalFormActivity.SELECTEDFORM.getJobid()+"",
                        img2,
                        DigitalFormActivity.SELECTEDFORM.getImage2Lat(),
                        DigitalFormActivity.SELECTEDFORM.getImage2Long(),
                        DigitalFormActivity.SELECTEDFORM.getImageComment2());
                Uri imgPath2 = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", img2);
                uris.add(imgPath2);
                emailIntent.setType("application/image");
            }
            // Image 3

            if (DigitalFormActivity.SELECTEDFORM.getImage3() != null) {
                File img3 = new File(DigitalFormActivity.SELECTEDFORM.getImage3());
//                APICalls.uploadSingleImage(DigitalFormActivity.mService,
//                        DigitalFormActivity.appExecutors,
//                        DigitalFormActivity.SELECTEDFORM.getFormid(),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage3Lat()),
//                        Double.parseDouble(DigitalFormActivity.SELECTEDFORM.getImage3Long()),
//                        DigitalFormActivity.SELECTEDFORM.getImageComment3(),
//                        Long.parseLong(DigitalFormActivity.EMPLOYEE_ID),
//                        DigitalFormActivity.SELECTEDFORM.getImage3Timestamp(),
//                        img3);
                APICalls.uploadActivityImage(ApiUtils.getJobService(),
                        DigitalFormActivity.appExecutors,
                        DigitalFormActivity.SELECTEDFORM.getJobid()+"",
                        img3,
                        DigitalFormActivity.SELECTEDFORM.getImage3Lat(),
                        DigitalFormActivity.SELECTEDFORM.getImage3Long(),
                        DigitalFormActivity.SELECTEDFORM.getImageComment3());
                Uri imgPath3 = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", img3);
                uris.add(imgPath3);
                emailIntent.setType("application/image");
            }


            // Signature

            if (DigitalFormActivity.SELECTEDFORM.getCustomerSignature() != null) {
                File sign = new File(DigitalFormActivity.SELECTEDFORM.getCustomerSignature());
                Log.e(TAG + "MobCall", DigitalFormActivity.SELECTEDFORM.isWalked()+"");
//                APICalls.mobileJobDataUpload(DigitalFormActivity.mService,
//                        DigitalFormActivity.appExecutors,
//                        DigitalFormActivity.SELECTEDFORM.getFormid(),
//                        DigitalFormActivity.SELECTEDFORM.isWalked(),
//                        DigitalFormActivity.SELECTEDFORM.isLiveSystem(),
//                        DigitalFormActivity.SELECTEDFORM.isTrained(),
//                        DigitalFormActivity.SELECTEDFORM.isMsds(),
//                        DigitalFormActivity.SELECTEDFORM.isAirMonitoring(),
//                        DigitalFormActivity.SELECTEDFORM.isWorkPermits(),
//                        DigitalFormActivity.SELECTEDFORM.getCustomerComment(),
//                        DigitalFormActivity.SELECTEDFORM.getEnggLocation(),
//                        sign);
                APICalls.uploadActivitySign(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getJobid()+"", sign);
                Uri signPath = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", sign);
                uris.add(signPath);
                emailIntent.setType("application/image");
            }

//            Log.e(TAG, "Image Attachment Path : " + imgPath.toString());
//            emailIntent.putExtra(Intent.EXTRA_STREAM, imgPath);
            ArrayList<String> filePaths = loadFile();
            if (!filePaths.isEmpty()) {
                for (String path : filePaths) {
                    File file = new File(path);
                    Uri filePath = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", file);
                    uris.add(filePath);
                    emailIntent.setType("application/pdf");
                    Log.e(TAG, "File Attachment Path : " + filePath.toString());
//            emailIntent.putExtra(Intent.EXTRA_STREAM, filePath);

                }
            }

//            File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL" + "/Form" + DigitalFormActivity.SELECTEDFORM.getFormid() + ".pdf");
            // Form PDF upload
            if (new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL" + "/Form" + DigitalFormActivity.SELECTEDFORM.getFormid() + ".pdf").exists()) {
                File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL" + "/Form" + DigitalFormActivity.SELECTEDFORM.getFormid() + ".pdf");
                Uri formPdf = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", pdfFile);
                uris.add(formPdf);
//                Log.e(TAG, formPdf.getPath());
            }


            // Video upload
            if (DigitalFormActivity.SELECTEDFORM.getVideoURI() != null) {
                File video = new File(DigitalFormActivity.SELECTEDFORM.getVideoURI());
                APICalls.uploadActivityVideo(ApiUtils.getJobService(),
                        DigitalFormActivity.appExecutors,
                        DigitalFormActivity.SELECTEDFORM.getJobid()+"",
                        video,
                        "0",
                        "0",
                        DigitalFormActivity.SELECTEDFORM.getVideoDescription());
                Uri videoUri = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".provider", video);
                uris.add(videoUri);
            }

            emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);

//            emailIntent.setType("image/png");
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            startActivityForResult(Intent.createChooser(emailIntent, "Send mail..."), 200);
//            getActivity().finish();
            Log.e(TAG, "Finished sending email...");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getActivity(), "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private ArrayList<String> loadFile() {

        ArrayList<String> filePaths = new ArrayList<>();

        if (DigitalFormActivity.SELECTEDFORM.getFiles() != null) {
            try {
                JSONObject json = new JSONObject(DigitalFormActivity.SELECTEDFORM.getFiles());
                JSONArray pathArray = json.optJSONArray("filePaths");
                if (pathArray != null) {
                    for (int i = 0; i < pathArray.length(); i++) {
//                        String path = pathArray.getString(i);
//                        String fileName = path.substring(path.lastIndexOf('/'));
                        filePaths.add(pathArray.getString(i));
                    }
                }
            } catch (JSONException e) {
                Log.e(TAG, "Files read error : " + e);
                Toast.makeText(getContext(), "Files read issue", Toast.LENGTH_SHORT).show();
            }
        }

        return filePaths;
    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }

    private void loadDBData() {
        txtFormId.setText(Integer.toString(DigitalFormActivity.SELECTEDFORM.getFormid()));
        //txtClientName.setText(DigitalFormActivity.SELECTEDFORM.getClientName());
        edtCustomerName.setText(DigitalFormActivity.SELECTEDFORM.getCustomerName());
//        if (DigitalFormActivity.SELECTEDFORM.getCustomerSignature() != null) {
//            signaturePad.setSignatureBitmap(BitmapFactory.decodeByteArray(DigitalFormActivity.SELECTEDFORM.getCustomerSignature(), 0, DigitalFormActivity.SELECTEDFORM.getCustomerSignature().length));
//        }
//        rbWellTrainedEngg.setRating(DigitalFormActivity.SELECTEDFORM.getWellTrainedEngineer());
//        rbWellSupervisedEngineer.setRating(DigitalFormActivity.SELECTEDFORM.getWellSupervisedEngineer());
//        rbProfessionalStandard.setRating(DigitalFormActivity.SELECTEDFORM.getProfessionalStandard());
//        rbCustomerSatisfied.setRating(DigitalFormActivity.SELECTEDFORM.getCustomerSatisfied());
        edtCustomerComment.setText(DigitalFormActivity.SELECTEDFORM.getCustomerComment());
    }

    private void initializeViews(View view) {
        txtFormId = (TextView) view.findViewById(R.id.job_id);
        //txtClientName = (TextView) view.findViewById(R.id.txt_client_name);
        edtCustomerName = (EditText) view.findViewById(R.id.edt_customer_name);
        signaturePad = (SignaturePad) view.findViewById(R.id.signature_pad);
//        rbWellTrainedEngg = (RatingBar) view.findViewById(R.id.rb_well_trained_engineer);
//        rbWellSupervisedEngineer = (RatingBar) view.findViewById(R.id.rb_well_supervised_engineer);
//        rbProfessionalStandard = (RatingBar) view.findViewById(R.id.rb_professional_standard);
//        rbCustomerSatisfied = (RatingBar) view.findViewById(R.id.rb_customer_satisfied);
        edtCustomerComment = (EditText) view.findViewById(R.id.edt_customer_comment);
        btnSubmitData = (Button) view.findViewById(R.id.btn_submit);
        btnClear = (Button) view.findViewById(R.id.btn_clear_button);
    }

    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    /**
//     * This interface must be implemented by activities that contain this
//     * fragment to allow an interaction in this fragment to be communicated
//     * to the activity and potentially other fragments contained in that
//     * activity.
//     * <p>
//     * See the Android Training lesson <a href=
//     * "http://developer.android.com/training/basics/fragments/communicating.html"
//     * >Communicating with Other Fragments</a> for more information.
//     */
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        void onFragmentInteraction(Uri uri);
//    }
}
