package com.demo.cadena.tcil.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Activity
 */
public class Activity extends AuditModel  {
  private Long activityId = null;

  private String location = null;

  private String inspector = null;

  private List<Image> images = null;

  private Video video = null;

  private String signature = null;
  
  private List<String> files = null;

  private String comment = null;

  private String enggName = null;
  
  /**
   * Gets or Sets status
   */
  public enum StatusEnum {
    CREATED("created"),
    
    UPDATED("updated"),
    
    BLOCKED("blocked"),
    
    COMPLETED("completed");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  private StatusEnum status = null;

  private String blockReason = null;
  
  private List<Quantity> quantity = null;

  private Job civilJob = null;

  private EarthWork earthWork = null;

  private ConcreteWork concreteWork = null;

  private SurfaceDressing surfaceDressing = null;

  private SteelReinforcement steelReinforcement = null;

  private FencingWire fencingWire = null;

    public Activity activityId(Long activityId) {
        this.activityId = activityId;
        return this;
    }

    /**
     * Get activityId
     * @return activityId
     **/

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public Activity location(String location) {
        this.location = location;
        return this;
    }

    /**
     * Get location
     * @return location
     **/

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Activity inspector(String inspector) {
        this.inspector = inspector;
        return this;
    }

    /**
     * Get inspector
     * @return inspector
     **/

    public String getInspector() {
        return inspector;
    }

    public void setInspector(String inspector) {
        this.inspector = inspector;
    }

    public Activity images(List<Image> images) {
        this.images = images;
        return this;
    }

    public Activity addImagesItem(Image imagesItem) {
        if (this.images == null) {
            this.images = new ArrayList<Image>();
        }
        this.images.add(imagesItem);
        return this;
    }

    /**
     * Get images
     * @return images
     **/
    public List<Image> getImages() {
        return images;
    }

    public void setImages(List<Image> images) {
        this.images = images;
    }

    public Activity video(Video video) {
        this.video = video;
        return this;
    }

    /**
     * Get video
     * @return video
     **/

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public Activity signature(String signature) {
        this.signature = signature;
        return this;
    }

    /**
     * Get signature
     * @return signature
     **/


    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Activity files(List<String> files) {
        this.files = files;
        return this;
    }

    public Activity addFilesItem(String filesItem) {
        if (this.files == null) {
            this.files = new ArrayList<String>();
        }
        this.files.add(filesItem);
        return this;
    }

    /**
     * Get files
     * @return files
     **/

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public Activity comment(String comment) {
        this.comment = comment;
        return this;
    }

    /**
     * Get comment
     * @return comment
     **/

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Activity enggName(String enggName) {
        this.enggName = enggName;
        return this;
    }

    /**
     * Get enggName
     * @return enggName
     **/

    public String getEnggName() {
        return enggName;
    }

    public void setEnggName(String enggName) {
        this.enggName = enggName;
    }

    public Activity status(StatusEnum status) {
        this.status = status;
        return this;
    }

    /**
     * Get status
     * @return status
     **/

    public StatusEnum getStatus() {
        return status;
    }

    public void setStatus(StatusEnum status) {
        this.status = status;
    }

    public Activity blockReason(String blockReason) {
        this.blockReason = blockReason;
        return this;
    }

    /**
     * Get blockReason
     * @return blockReason
     **/

    public String getBlockReason() {
        return blockReason;
    }

    public void setBlockReason(String blockReason) {
        this.blockReason = blockReason;
    }

    public Activity quantity(List<Quantity> quantity) {
        this.quantity = quantity;
        return this;
    }

    public Activity addQuantityItem(Quantity quantityItem) {
        if (this.quantity == null) {
            this.quantity = new ArrayList<Quantity>();
        }
        this.quantity.add(quantityItem);
        return this;
    }

    /**
     * Get quantity
     * @return quantity
     **/

    public List<Quantity> getQuantity() {
        return quantity;
    }

    public void setQuantity(List<Quantity> quantity) {
        this.quantity = quantity;
    }

    public Activity civilJob(Job civilJob) {
        this.civilJob = civilJob;
        return this;
    }

    /**
     * Get civilJob
     * @return civilJob
     **/

    public Job getCivilJob() {
        return civilJob;
    }

    public void setCivilJob(Job civilJob) {
        this.civilJob = civilJob;
    }


    public Activity earthWork(EarthWork earthWork) {
        this.earthWork = earthWork;
        return this;
    }

    /**
     * Get earthWork
     * @return earthWork
     **/
     public EarthWork getEarthWork() {
        return earthWork;
    }

    public void setEarthWork(EarthWork earthWork) {
        this.earthWork = earthWork;
    }

    public Activity concreteWork(ConcreteWork concreteWork) {
        this.concreteWork = concreteWork;
        return this;
    }

    /**
     * Get concreteWork
     * @return concreteWork
     **/
    public ConcreteWork getConcreteWork() {
        return concreteWork;
    }

    public void setConcreteWork(ConcreteWork concreteWork) {
        this.concreteWork = concreteWork;
    }



    public Activity surfaceDressing(SurfaceDressing surfaceDressing) {
        this.surfaceDressing = surfaceDressing;
        return this;
    }

    /**
     * Get surfaceDressing
     * @return surfaceDressing
     **/


    public SurfaceDressing getSurfaceDressing() {
        return surfaceDressing;
    }

    public void setSurfaceDressing(SurfaceDressing surfaceDressing) {
        this.surfaceDressing = surfaceDressing;
    }

    public Activity steelReinforcement(SteelReinforcement steelReinforcement) {
        this.steelReinforcement = steelReinforcement;
        return this;
    }

    /**
     * Get steelReinforcement
     * @return steelReinforcement
     **/

    public SteelReinforcement getSteelReinforcement() {
        return steelReinforcement;
    }

    public void setSteelReinforcement(SteelReinforcement steelReinforcement) {
        this.steelReinforcement = steelReinforcement;
    }

    public Activity fencingWire(FencingWire fencingWire) {
        this.fencingWire = fencingWire;
        return this;
    }

    /**
     * Get fencingWire
     * @return fencingWire
     **/

    public FencingWire getFencingWire() {
        return fencingWire;
    }

    public void setFencingWire(FencingWire fencingWire) {
        this.fencingWire = fencingWire;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Activity activity = (Activity) o;
        return Objects.equals(this.activityId, activity.activityId) &&
                Objects.equals(this.location, activity.location) &&
                Objects.equals(this.inspector, activity.inspector) &&
                Objects.equals(this.images, activity.images) &&
                Objects.equals(this.video, activity.video) &&
                Objects.equals(this.signature, activity.signature) &&
                Objects.equals(this.files, activity.files) &&
                Objects.equals(this.comment, activity.comment) &&
                Objects.equals(this.enggName, activity.enggName) &&
                Objects.equals(this.status, activity.status) &&
                Objects.equals(this.blockReason, activity.blockReason) &&
                Objects.equals(this.quantity, activity.quantity) &&
                Objects.equals(this.civilJob, activity.civilJob) &&
                Objects.equals(this.earthWork, activity.earthWork) &&
                Objects.equals(this.concreteWork, activity.concreteWork) &&
                Objects.equals(this.surfaceDressing, activity.surfaceDressing) &&
                Objects.equals(this.steelReinforcement, activity.steelReinforcement) &&
                Objects.equals(this.fencingWire, activity.fencingWire);
    }

    @Override
    public int hashCode() {
        return Objects.hash(activityId, location, inspector, images, video, signature, files, comment, enggName, status, blockReason, quantity, civilJob, earthWork, concreteWork, surfaceDressing, steelReinforcement, fencingWire);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Activity {\n");

        sb.append("    activityId: ").append(toIndentedString(activityId)).append("\n");
        sb.append("    location: ").append(toIndentedString(location)).append("\n");
        sb.append("    inspector: ").append(toIndentedString(inspector)).append("\n");
        sb.append("    images: ").append(toIndentedString(images)).append("\n");
        sb.append("    video: ").append(toIndentedString(video)).append("\n");
        sb.append("    signature: ").append(toIndentedString(signature)).append("\n");
        sb.append("    files: ").append(toIndentedString(files)).append("\n");
        sb.append("    comment: ").append(toIndentedString(comment)).append("\n");
        sb.append("    enggName: ").append(toIndentedString(enggName)).append("\n");
        sb.append("    status: ").append(toIndentedString(status)).append("\n");
        sb.append("    blockReason: ").append(toIndentedString(blockReason)).append("\n");
        sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
        sb.append("    civilJob: ").append(toIndentedString(civilJob)).append("\n");
        sb.append("    earthWork: ").append(toIndentedString(earthWork)).append("\n");
        sb.append("    concreteWork: ").append(toIndentedString(concreteWork)).append("\n");
        sb.append("    surfaceDressing: ").append(toIndentedString(surfaceDressing)).append("\n");
        sb.append("    steelReinforcement: ").append(toIndentedString(steelReinforcement)).append("\n");
        sb.append("    fencingWire: ").append(toIndentedString(fencingWire)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}