package com.demo.cadena.tcil.entity;

import java.util.Objects;

/**
 * Quantity
 */

public class Quantity   {
  private Long id = null;

  private String dsrNo = null;

  private double quantity = 0;

  public Quantity id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Quantity dsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
    return this;
  }

  /**
   * Get dsrNo
   * @return dsrNo
  **/


  public String getDsrNo() {
    return dsrNo;
  }

  public void setDsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
  }

  public Quantity quantity(double quantity) {
    this.quantity = quantity;
    return this;
  }

  /**
   * Get quantity
   * @return quantity
  **/


  public double getQuantity() {
    return quantity;
  }

  public void setQuantity(double quantity) {
    this.quantity = quantity;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Quantity quantity = (Quantity) o;
    return Objects.equals(this.id, quantity.id) &&
        Objects.equals(this.dsrNo, quantity.dsrNo) &&
        Objects.equals(this.quantity, quantity.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, dsrNo, quantity);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Quantity {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    dsrNo: ").append(toIndentedString(dsrNo)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}