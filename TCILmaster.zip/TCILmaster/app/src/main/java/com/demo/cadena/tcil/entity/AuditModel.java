package com.demo.cadena.tcil.entity;

import java.util.Date;


/**
 * AuditModel
 */

public abstract class AuditModel {

	private Date createdAt;

	private Date updatedAt;

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
}
