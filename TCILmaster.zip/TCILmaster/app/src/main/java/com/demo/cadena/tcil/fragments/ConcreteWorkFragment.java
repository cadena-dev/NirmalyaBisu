package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.ConcreteWork;
import com.demo.cadena.tcil.entity.DSRDetails;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.FormService;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.math.BigDecimal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConcreteWorkFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "ConcreteWork";

    private String mParam1;
    private String mParam2;

    String dsr1 = "4.1.3";
    String str1 = dsr1 + " Providing and laying in position cement concrete of specified grade excluding the cost of centering and shuttering - All work up to plinth level : \"1:2:4 (1 cement : 2 coarse sand (zone-III) : 4 graded stone aggregate 20 mm nominal size)";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewOneConcreteWork;
    String dsr2 = "4.1.8";
    String str2 = dsr2 + " Providing and laying in position cement concrete of specified grade excluding the cost of centering and shuttering - All work up to plinth level : 1:4:8 (1 Cement : 4 coarse sand (zone-III) : 8 graded stone aggregate 40 mm nominal size)";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewTwoConcreteWork;
    String dsr3 = "5.2.2";
    String str3 = dsr3  + " Reinforced cement concrete work in walls (any thickness), including attached pilasters, buttresses, plinth and string courses, fillets, columns, pillars, piers, abutments, posts and struts etc. above plinth level up to floor five level, excluding cost of centering, shuttering, finishing and reinforcement : 1:1.5:3 (1 cement : 1.5 coarse sand(zone-III) : 3 graded stone aggregate 20 mm nominal size)";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewThreeConcreteWork;

    Button btnCalculateConcreteWork;
    EditText edtConcreteWorkNosOne;
    EditText edtConcreteWorkNosTwo;
    EditText edtConcreteWorkNosThree;
    EditText edtConcreteWorkLOne;
    EditText edtConcreteWorkLTwo;
    EditText edtConcreteWorkA;
    EditText edtConcreteWorkBOne;
    EditText edtConcreteWorkBTwo;
    EditText edtConcreteWorkB;
    EditText edtConcreteWorkHOne;
    EditText edtConcreteWorkHTwo;
    EditText edtConcreteWorkH;
    EditText edtConcreteWorkPercentOne;
    EditText edtConcreteWorkPercentTwo;
    EditText edtConcreteWorkPercentThree;
    Float quantityOne;
    Float quantityTwo;
    Float quantityThree;
    Float percentOne;
    Float percentTwo;
    Float percentThree;
    Float volume;
    TextView txtConcreteQuantityOne;
    TextView txtConcreteQuantityTwo;
    TextView txtConcreteQuantityThree;
    LinearLayout layoutConcreteWorkQuantityOne;
    LinearLayout layoutConcreteWorkQuantityTwo;
    LinearLayout layoutConcreteWorkQuantityThree;
    String percent = "100";

    public ConcreteWorkFragment() {
        // Required empty public constructor
    }

    public static ConcreteWorkFragment newInstance(String param1, String param2) {
        ConcreteWorkFragment fragment = new ConcreteWorkFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view;
        view = inflater.inflate(R.layout.fragment_concrete_work, container, false);

        expandableTextViewOneConcreteWork = (com.ms.square.android.expandabletextview.ExpandableTextView) view.findViewById(R.id.expand_text_view_one_concrete_work);
        expandableTextViewOneConcreteWork.setText(str1);
        edtConcreteWorkNosOne = (EditText)view.findViewById(R.id.edt_concrete_work_one_nos);
        edtConcreteWorkPercentOne = (EditText)view.findViewById(R.id.edt_concrete_work_one_percentage);
        edtConcreteWorkLOne = (EditText)view.findViewById(R.id.edt_concrete_work_one_L);
        edtConcreteWorkBOne = (EditText)view.findViewById(R.id.edt_concrete_work_one_B);
        edtConcreteWorkHOne = (EditText)view.findViewById(R.id.edt_concrete_work_one_H);
        txtConcreteQuantityOne = (TextView)view.findViewById(R.id.txtConcreteQuantityOne);
        layoutConcreteWorkQuantityOne = (LinearLayout)view.findViewById(R.id.layoutConcreteWorkQuantityOne);

        expandableTextViewTwoConcreteWork = (com.ms.square.android.expandabletextview.ExpandableTextView) view.findViewById(R.id.expand_text_view_two_concrete_work);
        expandableTextViewTwoConcreteWork.setText(str2);
        edtConcreteWorkNosTwo = (EditText)view.findViewById(R.id.edt_concrete_work_two_nos);
        edtConcreteWorkPercentTwo = (EditText)view.findViewById(R.id.edt_concrete_work_two_percentage);
        edtConcreteWorkLTwo = (EditText)view.findViewById(R.id.edt_concrete_work_two_L);
        edtConcreteWorkBTwo = (EditText)view.findViewById(R.id.edt_concrete_work_two_B);
        edtConcreteWorkHTwo = (EditText)view.findViewById(R.id.edt_concrete_work_two_H);
        txtConcreteQuantityTwo = (TextView)view.findViewById(R.id.txtConcreteQuantityTwo);
        layoutConcreteWorkQuantityTwo = (LinearLayout)view.findViewById(R.id.layoutConcreteWorkQuantityTwo);

        expandableTextViewThreeConcreteWork = (com.ms.square.android.expandabletextview.ExpandableTextView) view.findViewById(R.id.expand_text_view_three_concrete_work);
        expandableTextViewThreeConcreteWork.setText(str3);
        edtConcreteWorkNosThree = (EditText)view.findViewById(R.id.edt_concrete_work_three_nos);
        edtConcreteWorkPercentThree = (EditText)view.findViewById(R.id.edt_concrete_work_three_percentage);
        edtConcreteWorkA = (EditText)view.findViewById(R.id.edt_concrete_work_a);
        edtConcreteWorkB = (EditText)view.findViewById(R.id.edt_concrete_work_b);
        edtConcreteWorkH = (EditText)view.findViewById(R.id.edt_concrete_work_h);
        txtConcreteQuantityThree = (TextView)view.findViewById(R.id.txtConcreteQuantityThree);
        layoutConcreteWorkQuantityThree = (LinearLayout)view.findViewById(R.id.layoutConcreteWorkQuantityThree);

        btnCalculateConcreteWork = (Button)view.findViewById(R.id.btnCalculateConcreteWork);
        btnCalculateConcreteWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtConcreteWorkNosOne.getText().toString().equals("") || edtConcreteWorkPercentOne.getText().toString().equals("") || edtConcreteWorkLOne.getText().toString().equals("") || edtConcreteWorkBOne.getText().toString().equals("") || edtConcreteWorkHOne.getText().toString().equals("") || edtConcreteWorkNosTwo.getText().toString().equals("") || edtConcreteWorkLTwo.getText().toString().equals("") || edtConcreteWorkBTwo.getText().toString().equals("") || edtConcreteWorkHTwo.getText().toString().equals("") || edtConcreteWorkPercentTwo.getText().toString().equals("") || edtConcreteWorkNosThree.getText().toString().equals("") || edtConcreteWorkA.getText().toString().equals("") || edtConcreteWorkB.getText().toString().equals("") || edtConcreteWorkH.getText().toString().equals("") || edtConcreteWorkPercentThree.getText().toString().equals("")){
                    Toast.makeText(view.getContext(), "Please enter data in all fields !", Toast.LENGTH_LONG).show();
                }else{
                    percentOne = Float.parseFloat(edtConcreteWorkPercentOne.getText().toString())/Float.parseFloat(percent);
                    quantityOne = Float.parseFloat(edtConcreteWorkNosOne.getText().toString()) * percentOne * Float.parseFloat(edtConcreteWorkLOne.getText().toString()) * Float.parseFloat(edtConcreteWorkBOne.getText().toString()) * Float.parseFloat(edtConcreteWorkHOne.getText().toString());
                    txtConcreteQuantityOne.setText(quantityOne.toString());
                    layoutConcreteWorkQuantityOne.setVisibility(View.VISIBLE);

                    percentTwo = Float.parseFloat(edtConcreteWorkPercentTwo.getText().toString())/Float.parseFloat(percent);
                    quantityTwo = Float.parseFloat(edtConcreteWorkNosTwo.getText().toString()) * percentTwo * Float.parseFloat(edtConcreteWorkLTwo.getText().toString()) * Float.parseFloat(edtConcreteWorkBTwo.getText().toString()) * Float.parseFloat(edtConcreteWorkHTwo.getText().toString());
                    txtConcreteQuantityTwo.setText(quantityTwo.toString());
                    layoutConcreteWorkQuantityTwo.setVisibility(View.VISIBLE);

                    percentThree = Float.parseFloat(edtConcreteWorkPercentThree.getText().toString())/Float.parseFloat(percent);
                    Float dummy1 =  (Float.parseFloat(edtConcreteWorkA.getText().toString()) * Float.parseFloat(edtConcreteWorkA.getText().toString())) + (Float.parseFloat(edtConcreteWorkB.getText().toString()) * Float.parseFloat(edtConcreteWorkB.getText().toString())) + (Float.parseFloat(edtConcreteWorkA.getText().toString()) * Float.parseFloat(edtConcreteWorkB.getText().toString()));
                    Float dummy2 = dummy1 * Float.parseFloat(edtConcreteWorkH.getText().toString());
                    volume = dummy2 / 3;
                    quantityThree = Float.parseFloat(edtConcreteWorkNosThree.getText().toString()) * percentThree * volume;
                    txtConcreteQuantityThree.setText(quantityThree.toString());
                    layoutConcreteWorkQuantityThree.setVisibility(View.VISIBLE);
                }
                ConcreteWork concreteWork = new ConcreteWork();
                DSRDetails dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("4.1.3");
                concreteWork.setDsrNo1(dsrDetails);
                dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("4.1.8");
                concreteWork.setDsrNo2(dsrDetails);
                dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("5.2.2");
                concreteWork.setDsrNo3(dsrDetails);

//                dsrDetails.setId(Long.parseLong(4+""));
//                concreteWork.setDsrNo1(dsrDetails);
                concreteWork.setNos1(Integer.parseInt(edtConcreteWorkNosOne.getText().toString()));
                concreteWork.setBredth1(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkBOne.getText().toString())));
                concreteWork.setLength1(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkLOne.getText().toString())));
                concreteWork.setHeight1(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkHOne.getText().toString())));
                concreteWork.setQuantity1(BigDecimal.valueOf(quantityOne));
//                dsrDetails = new DSRDetails();
//                dsrDetails.setId(Long.parseLong(5+""));
//                concreteWork.setDsrNo2(dsrDetails);
                concreteWork.setNos2(Integer.parseInt(edtConcreteWorkNosTwo.getText().toString()));
                concreteWork.setBredth2(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkBTwo.getText().toString())));
                concreteWork.setLength2(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkLTwo.getText().toString())));
                concreteWork.setHeight2(BigDecimal.valueOf(Double.parseDouble(edtConcreteWorkHTwo.getText().toString())));
                concreteWork.setQuantity2(BigDecimal.valueOf(quantityTwo));
//                dsrDetails = new DSRDetails();
//                dsrDetails.setId(Long.parseLong(8+""));
//                concreteWork.setDsrNo3(dsrDetails);
                concreteWork.setNos3(Integer.parseInt(edtConcreteWorkNosThree.getText().toString()));
                concreteWork.setVol(BigDecimal.valueOf(volume));
                concreteWork.setQuantity3(BigDecimal.valueOf(quantityThree));
                createConcreteWork(ApiUtils.getFormService(), DigitalFormActivity.appExecutors, concreteWork);
            }
        });
        return view;
    }

    private void createConcreteWork(FormService formService, AppExecutors appExecutors, ConcreteWork concreteWork) {
        appExecutors.getNetworkIO().execute(() -> {
            formService.createConcreteWork(concreteWork, APICalls.setHeaders()).enqueue(new Callback<ConcreteWork>() {
                @Override
                public void onResponse(Call<ConcreteWork> call, Response<ConcreteWork> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, response.toString());
                        updateActivityById(ApiUtils.getJobService(), appExecutors, DigitalFormActivity.SELECTEDFORM.getJobid()+"", response.body());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<ConcreteWork> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    private void updateActivityById(JobsService jobService, AppExecutors appExecutors, String activityId, ConcreteWork concreteWork) {
        appExecutors.getNetworkIO().execute(() -> {
            jobService.getActivityById(activityId, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Activity resActivity = response.body();
                        Log.e(TAG, resActivity.toString());
                        resActivity.setConcreteWork(concreteWork);
                        APICalls.updateActivity(jobService, appExecutors, resActivity);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
