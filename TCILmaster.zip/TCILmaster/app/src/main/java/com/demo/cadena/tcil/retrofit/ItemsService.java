package com.demo.cadena.tcil.retrofit;

import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.entity.JobForm;
import com.demo.cadena.tcil.entity.LocationEntity;
import com.demo.cadena.tcil.entity.LoginForm;
import com.demo.cadena.tcil.entity.LoginResponse;
import com.demo.cadena.tcil.entity.MobileJobDataUploadResponse;
import com.demo.cadena.tcil.entity.ModelApiResponse;
import com.demo.cadena.tcil.entity.PDFResponse;
import com.demo.cadena.tcil.entity.SingleImageUploadResponse;
import com.demo.cadena.tcil.entity.User;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by Suman on 08-03-2018.
 */

public interface ItemsService {

    @GET("civil")
    Call<List<Job>> getJobs(
            @Path("employeeId") String employeeId,
            @HeaderMap Map<String, String> headers
    );

    @GET("engineerWiseCompleteJobs/{employeeId}")
    Call<List<Job>> getCompletedJobs(
            @Path("employeeId") String employeeId,
            @HeaderMap Map<String, String> headers
    );

    @GET("user")
    Call<List<User>> getUsers(
            @HeaderMap Map<String, String> headers
    );

    @GET("form/{formId}")
    Call<List<JobForm>> getForm(
            @Path("formId") long formId,
            @HeaderMap Map<String, String> headers
    );

    @GET("job/findByUser")
    Call<List<Job>> getJobsByUsername(
            @Query("username") String username,
            @HeaderMap Map<String, String> headers
    );

//    @POST("user/login")
    @POST("mobileLogin/")
    Call<LoginResponse> login(
            @Body LoginForm loginForm,
            @HeaderMap Map<String, String> headers
    );

    @POST("mobileJobUpdate")
    Call<List<Job>> updateJobStatus(
            @HeaderMap Map<String, String> stringStringMap,
            @Query("jobid") Long jobId,
            @Query("activityStatus") String status
    );

    @Multipart
    @POST("uploadFile/")
    Call<PDFResponse> uploadFile(
            @Part("jobid") RequestBody jobid,
            @Part MultipartBody.Part file
    );

    @Multipart
    @POST("uploadSingleImage/")
    Call<SingleImageUploadResponse> uploadSingleImage(
            @Part("jobid") RequestBody jobid,
            @Part("latitude") RequestBody latitude,
            @Part("longitude") RequestBody longitude,
            @Part("description") RequestBody description,
            @Part("engineerid") RequestBody engineerid,
            @Part("updatedatetime") RequestBody updatedatetime,
            @Part MultipartBody.Part file
    );

    @Multipart
    @POST("mobileJobDataUpload/")
    Call<MobileJobDataUploadResponse> mobileJobDataUpload(
            @Part("jobid") RequestBody jobid,
            @Part("q1") RequestBody q1,
            @Part("q2") RequestBody q2,
            @Part("q3") RequestBody q3,
            @Part("q4") RequestBody q4,
            @Part("q5") RequestBody q5,
            @Part("q6") RequestBody q6,
            @Part("comments") RequestBody comments,
            @Part("location") RequestBody location,
            @Part MultipartBody.Part file
    );

    @GET("/")
    Call<String> getLatLong(
            @Query("address") String address,
            @Query("sensor") boolean sensor,
            @Query("key") String key
    );
}
