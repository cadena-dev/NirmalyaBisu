package com.demo.cadena.tcil.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.adapters.MyTabViewPagerAdapter;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.fragments.ActivityListTabFragment;
import com.demo.cadena.tcil.fragments.ConcreteWorkFragment;
import com.demo.cadena.tcil.fragments.CumulativeFragment;
import com.demo.cadena.tcil.fragments.EarthWorkCumulativeFragment;
import com.demo.cadena.tcil.fragments.ConcreteWorkCumulativeFragment;
import com.demo.cadena.tcil.fragments.EarthWorkFragment;
import com.demo.cadena.tcil.fragments.FencingWireFragment;
import com.demo.cadena.tcil.fragments.SteelReinforcementFragment;
import com.demo.cadena.tcil.fragments.SurfaceDressingCumulativeFragment;
import com.demo.cadena.tcil.fragments.SteelReinforcementCumulativeFragment;
import com.demo.cadena.tcil.fragments.FencingWireCumulativeFragment;
import com.demo.cadena.tcil.fragments.HomeFragment;
import com.demo.cadena.tcil.fragments.JobDetailsTabFragment;
import com.demo.cadena.tcil.fragments.SurfaceDressingFragment;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class JobActivity extends AppCompatActivity {

    //private android.support.v7.widget.Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager tabViewPager;
    private MyTabViewPagerAdapter tabViewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job);

//        toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("  Jiffy");
        setSupportActionBar(toolbar);

        tabViewPager = (ViewPager) findViewById(R.id.viewpager);
        tabViewPagerAdapter = new MyTabViewPagerAdapter(getSupportFragmentManager());
        tabViewPagerAdapter.addFragment(JobDetailsTabFragment.newInstance("",""), "Details");
        tabViewPagerAdapter.addFragment(ActivityListTabFragment.newInstance("",""), "Activities");
        //tabViewPagerAdapter.addFragment(CumulativeFragment.newInstance("",""), "Cumulative");

        getJobById(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, getApplicationContext(), DigitalFormActivity.SELECTEDFORM.getFormid()+"");
        //tabViewPagerAdapter.addFragment(EarthWorkCumulativeFragment.newInstance("",""), "Cumulative");
        //tabViewPagerAdapter.addFragment(ConcreteWorkCumulativeFragment.newInstance("",""), "Cumulative");
        //tabViewPagerAdapter.addFragment(SurfaceDressingCumulativeFragment.newInstance("",""), "Cumulative");
        //tabViewPagerAdapter.addFragment(SteelReinforcementCumulativeFragment.newInstance("",""), "Cumulative");
        //tabViewPagerAdapter.addFragment(FencingWireCumulativeFragment.newInstance("",""), "Cumulative");

        tabViewPager.setAdapter(tabViewPagerAdapter);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(tabViewPager);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.job_activity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        if(item!=null) {  //Exception : Checking whether item is null or not.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

            if (id == R.id.action_logout) {
                //Toast.makeText(getApplicationContext(),"Logged out",Toast.LENGTH_LONG).show();
                SharedPreferences.Editor editor = LoginActivity.sharedPreferences.edit();
                editor.putString(getString(R.string.jwtToken), null);
                editor.apply();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return true;
            }

            if (id == R.id.action_home) {
                //Toast.makeText(getApplicationContext(),"Home Clicked..!!",Toast.LENGTH_LONG).show();
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.main_frame, HomeFragment.newInstance("intelligentsurveymanagement", "test2"));
//            transaction.disallowAddToBackStack();
//            transaction.commit();

                Intent myIntent = new Intent(JobActivity.this, DigitalFormActivity.class);
                myIntent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                JobActivity.this.startActivity(myIntent);

                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public void getJobById(JobsService mService, AppExecutors executors, Context context, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobById(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<Job>() {
                @Override
                public void onResponse(Call<Job> call, Response<Job> response) {
                    if (response.code() == 200) {
                        String jobType = response.body().getJobType().getName();
                        switch (jobType) {
                            case "Earth Work":
                                /************ Earth Work Form ******************/
                                tabViewPagerAdapter.addFragment(EarthWorkCumulativeFragment.newInstance("",""), "Cumulative");
                                break;
                            case "Concrete Work":
                                /************ Concrete Work Form ******************/
                                tabViewPagerAdapter.addFragment(ConcreteWorkCumulativeFragment.newInstance("",""), "Cumulative");
                                break;
                            case "Fencing Wire":
                                /************ Fencing Wire Form ******************/
                                tabViewPagerAdapter.addFragment(FencingWireCumulativeFragment.newInstance("",""), "Cumulative");
                                break;
                            case "Steel Reinforcement":
                                /************ Steel Reinforcement Form ******************/
                                tabViewPagerAdapter.addFragment(SteelReinforcementCumulativeFragment.newInstance("",""), "Cumulative");
                                break;
                            case "Surface Dressing":
                                /************ Surface Dressing Form ******************/
                                tabViewPagerAdapter.addFragment(SurfaceDressingCumulativeFragment.newInstance("",""), "Cumulative");
                                break;
                        }
                        tabViewPagerAdapter.notifyDataSetChanged();

                    } else {
                        int statusCode = response.code();
                        //Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody() + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<Job> call, Throwable t) {
                    //Log.e(TAG, "Error during API call" + call.toString() + t);
                }
            });
        });
    }
}
