package com.demo.cadena.tcil.retrofit;

import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.CumulativeJob;
import com.demo.cadena.tcil.entity.Job;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface JobsService {

    @GET("civil/assigned/{userId}/status/{status}")
    Call<List<Job>> getJobs(
            @Path("userId") String employeeId,
            @Path("status") String status,
            @HeaderMap Map<String, String> headers
    );

    @PUT("civil/status")
    Call<Void> updateJobStatus(
            @Query("jobId") String jobId,
            @Query("status") String status,
            @HeaderMap Map<String, String> headers
    );

    @GET("civil/{jobId}")
    Call<Job> getJobById(
            @Path("jobId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @GET("activity/{activityId}")
    Call<Activity> getActivityById(
            @Path("activityId") String activityId,
            @HeaderMap Map<String, String> headers
    );

    @GET("activity/job/{jobId}/status/{status}")
    Call<List<Activity>> getActivityListByJobAndStatus(
            @Path("jobId") String jobId,
            @Path("status") String status,
            @HeaderMap Map<String, String> headers
    );

    @POST("activity")
    Call<Activity> createActivity(
            @Body Activity activity,
            @HeaderMap Map<String, String> headers
    );

    @PUT("activity")
    Call<Activity> updateActivity(
            @Body Activity activity,
            @HeaderMap Map<String, String> headers
    );

    @PUT("activity/status")
    Call<Void> updateActivityStatus(
            @Query("activityId") String activityId,
            @Query("status") String status,
            @HeaderMap Map<String, String> headers
    );

    @Multipart
    @POST("activity/uploadImage")
    Call<Activity> uploadImage(
            @Query("activityId") String activityId,
            @Query("latitude") String latitude,
            @Query("longitude") String longitude,
            @Query("description") String description,
            @Part MultipartBody.Part file,
            @HeaderMap Map<String, String> headers
    );

    @Multipart
    @POST("activity/uploadSign")
    Call<Activity> uploadSign(
            @Query("activityId") String activityId,
            @Part MultipartBody.Part file,
            @HeaderMap Map<String, String> headers
    );

    @Multipart
    @POST("activity/uploadVideo")
    Call<Activity> uploadVideo(
            @Query("activityId") String activityId,
            @Query("latitude") String latitude,
            @Query("longitude") String longitude,
            @Query("description") String description,
            @Part MultipartBody.Part file,
            @HeaderMap Map<String, String> headers
    );

    @GET("activity/job/{jobId}/cumulative")
    Call<List<CumulativeJob>> getJobCumulative(
            @Path("jobId") String jobId,
            @HeaderMap Map<String, String> headers
    );

}
