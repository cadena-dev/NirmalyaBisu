package com.demo.cadena.tcil.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.broadcastReceivers.CheckConnectivity;
import com.demo.cadena.tcil.database.AppDatabase;
import com.demo.cadena.tcil.dummy.LeftPanelContent.DummyItem;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.entity.JobForm;
import com.demo.cadena.tcil.entity.User;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.fragments.BOQFragment;
import com.demo.cadena.tcil.fragments.CustomerSignOffFragment;
import com.demo.cadena.tcil.fragments.DetailMeasurmentFragment;
import com.demo.cadena.tcil.fragments.DraftJobsFragment;
import com.demo.cadena.tcil.fragments.EarthWorkFragment;
import com.demo.cadena.tcil.fragments.EquipmentDetailsFragment;
import com.demo.cadena.tcil.fragments.EvaluatingWorkFragment;
import com.demo.cadena.tcil.fragments.FileUploadFragment;
import com.demo.cadena.tcil.fragments.FormFragment;
import com.demo.cadena.tcil.fragments.HomeFragment;
import com.demo.cadena.tcil.fragments.InboxJobsFragment;
import com.demo.cadena.tcil.fragments.LeftFragment;
import com.demo.cadena.tcil.fragments.MeasurmentBookFragment;
import com.demo.cadena.tcil.fragments.SentJobDetailsFragment;
import com.demo.cadena.tcil.fragments.SentJobsFragment;
import com.demo.cadena.tcil.fragments.SiteInformationFragment;
import com.demo.cadena.tcil.fragments.SteelReinforcementFragment;
import com.demo.cadena.tcil.fragments.SurfaceDressingFragment;
import com.demo.cadena.tcil.fragments.VideoReferenceFragment;
import com.demo.cadena.tcil.fragments.WorkStepsAndHazardsFragment;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.ItemsService;
import com.demo.cadena.tcil.utils.DatabaseInitializer;

import java.util.ArrayList;
import java.util.List;



public class DigitalFormActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        LeftFragment.OnListFragmentInteractionListener,
        SentJobsFragment.OnListFragmentInteractionListener,
        InboxJobsFragment.OnListFragmentInteractionListener,
        DraftJobsFragment.OnListFragmentInteractionListener {

    public static final String DRAFT = "draft";
    public static final String INBOX = "inbox";
    public static final String SENT = "sent";
    public static String EMPLOYEE_ID = "";
    public static List<Form> ALLFORMS;
    public static List<Form> SENTFORMS;
    public static List<Form> INBOXFORMS;
    public static List<Form> DRAFTFORMS;
    public static List<Form> SYNCFORMS;
    public static Form SELECTEDFORM;

    public static List<Job> jobs;
    public static List<JobForm> jobForms;
    public static List<User> users;

    public static ItemsService mService;

    public static AppDatabase appDatabase;
    public static AppExecutors appExecutors;

    public static SharedPreferences sharedPreferences;
    private static boolean firstTimeAppLaunch;
    private static String JWTToken;

//    private CheckConnectivity checkConnectivity;

    private static final String TAG = "DigitalForm";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digital_form);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        TextView mTitle = (TextView) toolbar.findViewById(R.id.toolbar_title);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Jiffy");
        //toolbar.setLogo(R.drawable.ic_action_home);
        setSupportActionBar(toolbar);
        //getSupportActionBar().setDisplayShowHomeEnabled(true);

        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.CAMERA,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
        };

        if(!hasPermissions(this, PERMISSIONS)){
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

        appExecutors = new AppExecutors();

        sharedPreferences = this.getPreferences(MODE_PRIVATE);
        firstTimeAppLaunch = sharedPreferences.getBoolean(getString(R.string.firstTimeAppLaunch), true);

        Log.e(TAG, firstTimeAppLaunch+"");

//        if (firstTimeAppLaunch) {
//            DatabaseInitializer.populateAsync(appDatabase, appExecutors, getApplicationContext());
//            SharedPreferences.Editor editor = sharedPreferences.edit();
//            editor.putBoolean(getString(R.string.firstTimeAppLaunch), false);
//            editor.apply();
//            finish();
//            startActivity(getIntent());
//        }

        mService = ApiUtils.getItemsService();

        initializeLists(this);

//        checkConnectivity = new CheckConnectivity();
//        registerReceiver(checkConnectivity, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));


//        APICalls.populateJobFromNetwork(mService, appExecutors, this);
//        populateFormByIdFromNetwork(mService, appExecutors, this, 1);
//        populateJobsByUsernameFromNetwork(mService, appExecutors, this, "charly194");

//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        Log.e(TAG, "HomeFragment called");
//        if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            Fragment fragment = new HomeFragment();
            transaction.replace(R.id.main_frame, fragment);
//            transaction.disallowAddToBackStack();
            transaction.commit();
//        }
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
//                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawer.addDrawerListener(toggle);
//        toggle.syncState();

//        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
//        navigationView.setNavigationItemSelectedListener(this);
    }

//    @Override
//    protected void onDestroy() {
//        if (checkConnectivity != null) {
//            unregisterReceiver(checkConnectivity);
//        }
//        super.onDestroy();
//    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.e(TAG, "On Resume");
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void initializeLists(Context context) {
        Log.e(TAG, "Initialize List");

//        if (firstTimeAppLaunch) {
//        DigitalFormActivity.EMPLOYEE_ID = sharedPreferences.getString(String.valueOf(R.string.employee_id), null);
        Log.e(TAG, "Employee ID in Activity : " + DigitalFormActivity.EMPLOYEE_ID);
//        APICalls.populateJobFromNetwork(mService, DigitalFormActivity.appExecutors, context);
//        APICalls.populateCompletedJobsFromNetwork(mService, DigitalFormActivity.appExecutors, context);
//            DatabaseInitializer.populateAsync(appDatabase, appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(context.getString(R.string.firstTimeAppLaunch), false);
            editor.apply();
//            finish();
//            startActivity(getIntent());
//        }

        DatabaseInitializer.getAllJobs(appDatabase, appExecutors, context.getApplicationContext());
//        DatabaseInitializer.getSentJobs(appDatabase, appExecutors, context.getApplicationContext());
//        DatabaseInitializer.getInboxJobs(appDatabase, appExecutors, context.getApplicationContext());
        DatabaseInitializer.getDraftJobs(appDatabase, appExecutors, context.getApplicationContext());
        DatabaseInitializer.getSyncJobs(appDatabase, appExecutors, context.getApplicationContext());
    }

//    @Override
//    public void onBackPressed() {
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//        } else {
//            super.onBackPressed();
//        }
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.digital_form, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        if(item!=null) {  //Exception : Checking whether item is null or not.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

            if (id == R.id.action_logout) {
                //Toast.makeText(getApplicationContext(),"Logged out",Toast.LENGTH_LONG).show();
                SharedPreferences.Editor editor = LoginActivity.sharedPreferences.edit();
                editor.putString(getString(R.string.jwtToken), null);
                editor.apply();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return true;
            }

            if (id == R.id.action_home) {
                //Toast.makeText(getApplicationContext(),"Home Clicked..!!",Toast.LENGTH_LONG).show();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.main_frame, HomeFragment.newInstance("intelligentsurveymanagement", "test2"));
                transaction.disallowAddToBackStack();
                transaction.commit();

                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        if(item!=null) {  //Exception : Checking whether item is null or not.
            int id = item.getItemId();

        /*if (id == R.id.nav_digital_form) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.main_frame, FormFragment.newInstance("intelligentsurveymanagement", "test2"));
            //transaction.replace(R.id.main_frame, LeftFragment.newInstance(1));
            transaction.addToBackStack(null);
            transaction.commit();
        } else */
            if (id == R.id.nav_home) {
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.main_frame, HomeFragment.newInstance("intelligentsurveymanagement", "test2"));
//            transaction.disallowAddToBackStack();
//            transaction.commit();
            } else if (id == R.id.nav_settings) {

            } else if (id == R.id.nav_help) {

            }
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    // LeftPanelFragment listener method
    @Override
    public void onListFragmentInteraction(DummyItem item) {

        if(item!=null) {  //Exception : Checking whether item is null or not.
            switch (item.id) {
                case R.layout.fragment_site_information:
                    Fragment fragment = new SiteInformationFragment();
                    FrameLayout fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, fragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_earth_work:
                    /************ Earth Work Form ******************/
//                EarthWorkFragment earthWorkFragment = EarthWorkFragment.newInstance("","");
//                fl = (FrameLayout) findViewById(R.id.right_panel);
//                fl.removeAllViews();
//                transaction = getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.right_panel, earthWorkFragment);
//                transaction.disallowAddToBackStack();
//                transaction.commit();


                    break;
//            case R.layout.fragment_boq:
//                BOQFragment boqFragment = BOQFragment.newInstance("","");
//                fl = (FrameLayout) findViewById(R.id.right_panel);
//                fl.removeAllViews();
//                transaction = getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.right_panel, boqFragment);
//                transaction.disallowAddToBackStack();
//                transaction.commit();
//                break;
//            case R.layout.fragment_detail_measurment:
//                DetailMeasurmentFragment detailMeasurmentFragment = DetailMeasurmentFragment.newInstance("","");
//                fl=(FrameLayout)findViewById(R.id.right_panel);
//                fl.removeAllViews();
//                transaction = getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.right_panel,detailMeasurmentFragment);
//                transaction.disallowAddToBackStack();
//                transaction.commit();
//                break;
                case R.layout.fragment_evaluating_work:
                    EvaluatingWorkFragment evaluatingWorkFragment = EvaluatingWorkFragment.newInstance("", "");
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, evaluatingWorkFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_work_steps_and_hazards:
                    WorkStepsAndHazardsFragment workStepsAndHazardsFragment = WorkStepsAndHazardsFragment.newInstance("", "");
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, workStepsAndHazardsFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_equipment_details:
                    EquipmentDetailsFragment equipmentDetailsFragment = EquipmentDetailsFragment.newInstance("", "");
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, equipmentDetailsFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_customer_sign_off:
                    CustomerSignOffFragment customerSignOffFragment = CustomerSignOffFragment.newInstance("", "");
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, customerSignOffFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_video_reference:
                    VideoReferenceFragment videoReferenceFragment = VideoReferenceFragment.newInstance("", "");
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, videoReferenceFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                case R.layout.fragment_file_upload:
                    FileUploadFragment fileUploadFragment = new FileUploadFragment();
                    fl = (FrameLayout) findViewById(R.id.right_panel);
                    fl.removeAllViews();
                    transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.right_panel, fileUploadFragment);
                    transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
            }
        }
    }

    // JobsFragment listener method
    @Override
    public void onListFragmentInteraction(Form item) {

        if(item!=null) {  //Exception : Checking whether item is null or not.
            switch (item.getFormStatus()) {
                case DigitalFormActivity.SENT:
                    SELECTEDFORM = item;
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.main_frame, new SentJobDetailsFragment());
                    transaction.addToBackStack(SentJobDetailsFragment.TAG);
//                transaction.disallowAddToBackStack();
                    transaction.commit();
                    break;
                default:
                    SELECTEDFORM = item;
//                Log.e(TAG, "Form Fragment call");
//                transaction = getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.main_frame, FormFragment.newInstance("intelligentsurveymanagement", "test2"));
//                //transaction.replace(R.id.main_frame, LeftFragment.newInstance(1));
//                transaction.addToBackStack(FormFragment.TAG);
////                transaction.disallowAddToBackStack();
//                transaction.commit();
//                startActivity(new Intent(this, FormActivity.class));
                    startActivity(new Intent(this, JobActivity.class));
                    break;
            }
        }
    }
}
