package com.demo.cadena.tcil.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.fragments.ConcreteWorkFragment;
import com.demo.cadena.tcil.fragments.CustomerSignOffFragment;
import com.demo.cadena.tcil.fragments.EarthWorkFragment;
import com.demo.cadena.tcil.fragments.EquipmentDetailsFragment;
import com.demo.cadena.tcil.fragments.EvaluatingWorkFragment;
import com.demo.cadena.tcil.fragments.FencingWireFragment;
import com.demo.cadena.tcil.fragments.FileUploadFragment;
import com.demo.cadena.tcil.fragments.HomeFragment;
import com.demo.cadena.tcil.fragments.MeasurmentBookFragment;
import com.demo.cadena.tcil.fragments.SiteInformationFragment;
import com.demo.cadena.tcil.fragments.SteelReinforcementFragment;
import com.demo.cadena.tcil.fragments.SurfaceDressingFragment;
import com.demo.cadena.tcil.fragments.VideoReferenceFragment;
import com.demo.cadena.tcil.fragments.WorkStepsAndHazardsFragment;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FormActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public static String jobType = "";

    private static final String TAG = "FormActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Jiffy");
        setSupportActionBar(toolbar);



//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

//        Fragment fragment = new SiteInformationFragment();
//        FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
//        fl.removeAllViews();
//        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//        transaction.replace(R.id.form_frame, fragment);
//        transaction.disallowAddToBackStack();
//        transaction.commit();



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.form, menu);
        return true;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        if(item!=null) {  //Exception : Checking whether item is null or not.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

            if (id == R.id.action_logout) {
                //Toast.makeText(getApplicationContext(),"Logged out",Toast.LENGTH_LONG).show();
                SharedPreferences.Editor editor = LoginActivity.sharedPreferences.edit();
                editor.putString(getString(R.string.jwtToken), null);
                editor.apply();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return true;
            }

            if (id == R.id.action_home) {
                //Toast.makeText(getApplicationContext(),"Home Clicked..!!",Toast.LENGTH_LONG).show();
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
////            transaction.replace(R.id.main_frame, HomeFragment.newInstance("intelligentsurveymanagement", "test2"));
////            transaction.disallowAddToBackStack();
////            transaction.commit();
                startActivity(new Intent(this, DigitalFormActivity.class));
                finish();

                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        if(item!=null) {  //Exception : Checking whether item is null or not.
            int id = item.getItemId();

            if (id == R.id.nav_site_info_details) {
                Fragment fragment = new SiteInformationFragment();
                FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
                fl.removeAllViews();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.form_frame, fragment);
                transaction.disallowAddToBackStack();
                transaction.commit();
            } else if (id == R.id.nav_measurement_book) {
                getJobById(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, getApplicationContext(), DigitalFormActivity.SELECTEDFORM.getFormid() + "");

//        } else if (id == R.id.nav_eval_work_area) {
//            EvaluatingWorkFragment evaluatingWorkFragment = EvaluatingWorkFragment.newInstance("", "");
//            FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
//            fl.removeAllViews();
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.form_frame, evaluatingWorkFragment);
//            transaction.disallowAddToBackStack();
//            transaction.commit();
            } else if (id == R.id.nav_work_steps) {
                WorkStepsAndHazardsFragment workStepsAndHazardsFragment = WorkStepsAndHazardsFragment.newInstance("", "");
                FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
                fl.removeAllViews();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.form_frame, workStepsAndHazardsFragment);
                transaction.disallowAddToBackStack();
                transaction.commit();
            } else if (id == R.id.nav_video_ref) {
                VideoReferenceFragment videoReferenceFragment = VideoReferenceFragment.newInstance("", "");
                FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
                fl.removeAllViews();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.form_frame, videoReferenceFragment);
                transaction.disallowAddToBackStack();
                transaction.commit();
//        } else if (id == R.id.nav_equipment_details) {
//            EquipmentDetailsFragment equipmentDetailsFragment = EquipmentDetailsFragment.newInstance("", "");
//            FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
//            fl.removeAllViews();
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.form_frame, equipmentDetailsFragment);
//            transaction.disallowAddToBackStack();
//            transaction.commit();
            } else if (id == R.id.nav_file_upload) {
                FileUploadFragment fileUploadFragment = new FileUploadFragment();
                FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
                fl.removeAllViews();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.form_frame, fileUploadFragment);
                transaction.disallowAddToBackStack();
                transaction.commit();
            } else if (id == R.id.nav_cust_sign_off) {
                CustomerSignOffFragment customerSignOffFragment = CustomerSignOffFragment.newInstance("", "");
                FrameLayout fl = (FrameLayout) findViewById(R.id.form_frame);
                fl.removeAllViews();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.form_frame, customerSignOffFragment);
                transaction.disallowAddToBackStack();
                transaction.commit();
            }
// else if (id == R.id.nav_share) {
//
//        } else if (id == R.id.nav_send) {
//
//        }
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void getJobById(JobsService mService, AppExecutors executors, Context context, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobById(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<Job>() {
                @Override
                public void onResponse(Call<Job> call, Response<Job> response) {
                    if (response.code() == 200) {
                        String jobType = response.body().getJobType().getName();
                        switch (jobType) {
                            case "Earth Work":
                                /************ Earth Work Form ******************/
                                EarthWorkFragment earthWorkFragment = new EarthWorkFragment();
                                FrameLayout f1 = (FrameLayout) findViewById(R.id.form_frame);
                                f1.removeAllViews();
                                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                                transaction.replace(R.id.form_frame, earthWorkFragment);
                                transaction.disallowAddToBackStack();
                                transaction.commit();
                                break;
                            case "Concrete Work":
                                /************ Concrete Work Form ******************/
                                ConcreteWorkFragment concreteWorkFragment = new ConcreteWorkFragment();
                                f1 = (FrameLayout) findViewById(R.id.form_frame);
                                f1.removeAllViews();
                                transaction = getSupportFragmentManager().beginTransaction();
                                transaction.replace(R.id.form_frame, concreteWorkFragment);
                                transaction.disallowAddToBackStack();
                                transaction.commit();
                                break;
                            case "Fencing Wire":
                                /************ Fencing Wire Form ******************/
                                FencingWireFragment fencingWireFragment = new FencingWireFragment();
                                f1 = (FrameLayout) findViewById(R.id.form_frame);
                                f1.removeAllViews();
                                transaction = getSupportFragmentManager().beginTransaction();
                                transaction.replace(R.id.form_frame, fencingWireFragment);
                                transaction.disallowAddToBackStack();
                                transaction.commit();
                                break;
                            case "Steel Reinforcement":
                                /************ Steel Reinforcement Form ******************/
                                SteelReinforcementFragment steelReinforcementFragment = new SteelReinforcementFragment();
                                f1 = (FrameLayout) findViewById(R.id.form_frame);
                                f1.removeAllViews();
                                transaction = getSupportFragmentManager().beginTransaction();
                                transaction.replace(R.id.form_frame, steelReinforcementFragment);
                                transaction.disallowAddToBackStack();
                                transaction.commit();
                                break;
                            case "Surface Dressing":
                                /************ Surface Dressing Form ******************/
                                SurfaceDressingFragment surfaceDressingFragment = new SurfaceDressingFragment();
                                f1 = (FrameLayout) findViewById(R.id.form_frame);
                                f1.removeAllViews();
                                transaction = getSupportFragmentManager().beginTransaction();
                                transaction.replace(R.id.form_frame, surfaceDressingFragment);
                                transaction.disallowAddToBackStack();
                                transaction.commit();
                                break;
                        }

                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody() + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<Job> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                }
            });
        });
    }
}
