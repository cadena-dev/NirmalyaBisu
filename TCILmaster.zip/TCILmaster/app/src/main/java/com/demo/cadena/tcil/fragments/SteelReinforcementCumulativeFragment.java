package com.demo.cadena.tcil.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.CumulativeJob;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SteelReinforcementCumulativeFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SteelReinforcementCumulativeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SteelReinforcementCumulativeFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    View view;
    TextView cumSRdsr1;
    TextView cumSRQuantity1;

    public SteelReinforcementCumulativeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SteelReinforcementCumulativeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SteelReinforcementCumulativeFragment newInstance(String param1, String param2) {
        SteelReinforcementCumulativeFragment fragment = new SteelReinforcementCumulativeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_steel_reinforcement_cumulative, container, false);
        cumSRdsr1 = (TextView)view.findViewById(R.id.cumSRdsr1);
        cumSRQuantity1 = (TextView)view.findViewById(R.id.cumSRQuantity1);
        return view;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void getCumulativeByJob(JobsService mService, AppExecutors executors, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobCumulative(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<CumulativeJob>>() {
                @Override
                public void onResponse(Call<List<CumulativeJob>> call, Response<List<CumulativeJob>> response) {
                    Log.e("Call Request", call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Log.e("Response", response.body()+"");
                        List<CumulativeJob> cumulativeJobs = response.body();
                        if (cumulativeJobs.isEmpty()){
                          //  Toast.makeText(view.getContext(), "No Data to be fetched !", Toast.LENGTH_LONG).show();
                        }else{
                            if(cumulativeJobs.get(0) == null){
                                cumSRdsr1.setText("0");
                                cumSRQuantity1.setText("0");
                            }else{
                                cumSRdsr1.setText(cumulativeJobs.get(0).getDsrNo().toString());
                                String quantity1 = String.format("%.2f", cumulativeJobs.get(0).getActQuantity());
                                cumSRQuantity1.setText(quantity1);
                            }

                        }
                    } else {
                        int statusCode = response.code();
                        Log.e("Status Code", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                        //Toast.makeText(view.getContext(), "No Data to be fetched !", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<List<CumulativeJob>> call, Throwable t) {
                    Log.e("Error", "Error during API call" + call.toString() + t);
                }
            });
        });
    }
}
