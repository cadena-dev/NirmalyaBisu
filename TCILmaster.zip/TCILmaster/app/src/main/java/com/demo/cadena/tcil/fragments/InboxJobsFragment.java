package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.adapters.MyInboxFormRecyclerViewAdapter;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;
import com.demo.cadena.tcil.utils.DatabaseInitializer;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link OnListFragmentInteractionListener}
 * interface.
 */
public class InboxJobsFragment extends Fragment {


    private View view;
    private RecyclerView recyclerView;

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    public static final String TAG = "InboxJobs";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    private OnListFragmentInteractionListener mListener;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public InboxJobsFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static InboxJobsFragment newInstance() {
        InboxJobsFragment fragment = new InboxJobsFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, 1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }

//        APICalls.populateJobFromNetwork(mService, DigitalFormActivity.appExecutors, getContext());
//        DatabaseInitializer.getInboxJobs(appDatabase, appExecutors, getContext().getApplicationContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_inboxform_list, container, false);

        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            recyclerView = (RecyclerView) view;
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }

        }

        populateJobFromNetwork(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, getContext());

        return view;
    }

    public void populateJobFromNetwork(JobsService mService, AppExecutors executors, Context context) {
        Log.e(TAG, "Employee ID : " + DigitalFormActivity.EMPLOYEE_ID);

        executors.getMainThread().execute(() -> {
            mService.getJobs(DigitalFormActivity.EMPLOYEE_ID, "created", APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<Job>>() { //20181215
//            mService.getJobs(APICalls.setHeaders()).enqueue(new Callback<List<Job>>() { //20181215
            @Override
                public void onResponse(Call<List<Job>> call, Response<List<Job>> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code() == 200) {
//                        DigitalFormActivity.jobs = response.body();
//                        Log.e(TAG, DigitalFormActivity.jobs.size()+"");
                        Log.e(TAG, response.body().size()+"");
                        DatabaseInitializer.populateInboxJob(response.body());
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), response.body());
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                        Log.e(TAG, "Inbox fragment View created");


                        try {
                            recyclerView.setAdapter(new MyInboxFormRecyclerViewAdapter(DigitalFormActivity.INBOXFORMS, mListener, getActivity().getSupportFragmentManager())); //20181215
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        }


                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<List<Job>> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                }
            });
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.e(TAG, "On Pause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e(TAG, "On Resume");
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(Form item);
    }
}
