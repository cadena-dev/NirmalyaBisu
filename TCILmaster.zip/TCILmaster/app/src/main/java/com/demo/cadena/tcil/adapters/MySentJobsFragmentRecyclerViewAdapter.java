package com.demo.cadena.tcil.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.fragments.SentJobsFragment.OnListFragmentInteractionListener;

import java.util.List;


/**
 * {@link RecyclerView.Adapter} that can display a {@link Form} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MySentJobsFragmentRecyclerViewAdapter extends RecyclerView.Adapter<MySentJobsFragmentRecyclerViewAdapter.ViewHolder> {

    private final List<Job> mValues;
    private final OnListFragmentInteractionListener mListener;

    public MySentJobsFragmentRecyclerViewAdapter(List<Job> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_sentjobsfragment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if((mValues!=null)&&(mValues.size()>0)) { // Exception : checking the list is null or not.

            holder.mItem = mValues.get(position);
            holder.txtSentJobId.setText(mValues.get(position).getJobId() + "");
            holder.txtSentJobTitle.setText(mValues.get(position).getJobTitle());
            holder.txtSentClientName.setText(mValues.get(position).getProject().getClient().getClientName());
            holder.txtSentStartDate.setText(mValues.get(position).getCreatedAt() + "");
            holder.txtSentEndDate.setText(mValues.get(position).getUpdatedAt() + "");

//        holder.mView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (null != mListener) {
//                    // Notify the active callbacks interface (the activity, if the
//                    // fragment is attached to one) that an item has been selected.
//                    mListener.onListFragmentInteraction(holder.mItem);
//                }
//            }
//        });
        }
    }

    @Override
    public int getItemCount() {
        if((mValues!=null)&&(mValues.size()>0)) { // Exception : checking the list is null or not.
            return mValues.size();
        }
        else
            return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView txtSentJobId;
        //public final TextView txtSentJobType;
        public final TextView txtSentJobTitle;
        public final TextView txtSentClientName;
        public final TextView txtSentStartDate;
        public final TextView txtSentEndDate;
        public Job mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txtSentJobId = (TextView) view.findViewById(R.id.txt_sent_job_id);
            //txtSentJobType = (TextView) view.findViewById(R.id.txt_sent_job_type);
            txtSentJobTitle = (TextView) view.findViewById(R.id.txt_sent_job_title);
            txtSentClientName = (TextView) view.findViewById(R.id.txt_sent_client_name);
            txtSentStartDate = (TextView) view.findViewById(R.id.txt_sent_started_at);
            txtSentEndDate = (TextView) view.findViewById(R.id.txt_sent_ended_at);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + txtSentJobTitle.getText() + "'";
        }
    }
}
