package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.adapters.ActivityListAdapter;
import com.demo.cadena.tcil.entity.CumulativeJob;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CumulativeFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Float cumQty = 160f;
    public Float netQty = 0.0f;

//    public EditText edtAdjustment;
    public TextView txtNetQty;
    public TextView txtCumQuantity;
//    public Button btnApply;

    private static final String TAG = "CumulativeFragment";

    public CumulativeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CumulativeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CumulativeFragment newInstance(String param1, String param2) {
        CumulativeFragment fragment = new CumulativeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cumulative, container, false);
//        edtAdjustment = (EditText)view.findViewById(R.id.adjustment_earth_work_quantity);
        txtNetQty = (TextView)view.findViewById(R.id.net_earth_work_quantity);
        txtCumQuantity = (TextView) view.findViewById(R.id.cum_quantity);
//        btnApply = (Button)view.findViewById(R.id.btnApply);
//
//        btnApply.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(edtAdjustment.getText().toString().equals("")){
//                    Toast.makeText(view.getContext(), "Please enter the Adjustment Value !", Toast.LENGTH_LONG).show();
//                }else {
//                    String adjtStr = edtAdjustment.getText().toString();
//                    Float adjstQty = Float.valueOf(edtAdjustment.getText().toString());
//                    netQty = cumQty + adjstQty;
//                    txtNetQty.setText(netQty.toString());
//
//                }
//            }
//        });

        getCumulativeByJob(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getFormid()+"");

        return view;
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void getCumulativeByJob(JobsService mService, AppExecutors executors, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobCumulative(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<CumulativeJob>>() {
                @Override
                public void onResponse(Call<List<CumulativeJob>> call, Response<List<CumulativeJob>> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        List<CumulativeJob> cumulativeJobs = response.body();
                        double sum = 0;
                        for (CumulativeJob job : cumulativeJobs) {
                            sum += job.getActQuantity().doubleValue();
                        }
                        txtCumQuantity.setText(sum+"");
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<List<CumulativeJob>> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                }
            });
        });
    }

}
