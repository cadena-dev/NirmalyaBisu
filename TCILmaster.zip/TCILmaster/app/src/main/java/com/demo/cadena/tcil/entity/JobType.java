package com.demo.cadena.tcil.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class JobType {

    @SerializedName("createdAt")
    @Expose
    private String createdAt;
    @SerializedName("updatedAt")
    @Expose
    private String updatedAt;
    @SerializedName("jobtypeId")
    @Expose
    private Integer jobtypeId;
    @SerializedName("name")
    @Expose
    private String name;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getJobtypeId() {
        return jobtypeId;
    }

    public void setJobtypeId(Integer jobtypeId) {
        this.jobtypeId = jobtypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
