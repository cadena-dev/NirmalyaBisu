package com.demo.cadena.tcil.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.fragments.DraftJobsFragment.OnListFragmentInteractionListener;

import java.util.List;
import java.util.Random;


/**
 * {@link RecyclerView.Adapter} that can display a {@link Form} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MyDraftJobsRecyclerViewAdapter extends RecyclerView.Adapter<MyDraftJobsRecyclerViewAdapter.ViewHolder> {

    private final List<Form> mValues;
    private final OnListFragmentInteractionListener mListener;

    public MyDraftJobsRecyclerViewAdapter(List<Form> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_draftjobs, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        if((mValues!=null)&&(mValues.size()>0)) { // Exception : checking the list is null or not.
            holder.mItem = mValues.get(position);
            holder.txtDraftJobId.setText(Integer.toString(mValues.get(position).getFormid()));
            holder.txtDraftJobTitle.setText(mValues.get(position).getJobDescription());
            holder.txtDraftProjectTitle.setText(mValues.get(position).getProject());
            holder.txtDraftClientName.setText(mValues.get(position).getClientName());
            Random r = new Random();
            int i1 = r.nextInt(90 - 10) + 10;
            //holder.progressBar.setProgress(i1);

            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != mListener) {
                        // Notify the active callbacks interface (the activity, if the
                        // fragment is attached to one) that an item has been selected.
                        mListener.onListFragmentInteraction(holder.mItem);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        if((mValues!=null)&&(mValues.size()>0)) { // Exception : checking the list is null or not.
            return mValues.size();
        }
        else
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView txtDraftJobId;
        public final TextView txtDraftJobTitle;
        public final TextView txtDraftProjectTitle;
        public final TextView txtDraftClientName;
        //public final ProgressBar progressBar;
        public Form mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txtDraftJobId = (TextView) view.findViewById(R.id.txt_draft_job_id);
            txtDraftJobTitle = (TextView) view.findViewById(R.id.txt_draft_job_title);
            txtDraftProjectTitle = (TextView) view.findViewById(R.id.txt_draft_project_title);
            txtDraftClientName = (TextView) view.findViewById(R.id.txt_draft_client_name);
            //progressBar = (ProgressBar)view.findViewById(R.id.progressBar);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + txtDraftJobTitle.getText() + "'";
        }
    }
}
