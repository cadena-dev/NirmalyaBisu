package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.adapters.ActivityListAdapter;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link ActivityListTabFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ActivityListTabFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_COLUMN_COUNT = "column-count";
    private int mColumnCount = 1;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    FloatingActionButton addActivityFab;

    private ArrayList<Activity> activities;
    private static int count = 1;

    private RecyclerView recyclerView;

    private static final String TAG = "ActivityList";

    public ActivityListTabFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static ActivityListTabFragment newInstance(String param1, String param2) {
        ActivityListTabFragment fragment = new ActivityListTabFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, 1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);

        }
        activities = new ArrayList<Activity>();
        getActivityListByJobAndStatus(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getFormid()+"");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_activity_list_tab,container,false);
        if((activities!=null)&&(activities.size()>0)) { //Exception : checking whether list is null or not
            Log.e(TAG, activities.size() + "");
        }
        recyclerView = (RecyclerView)view.findViewById(R.id.activityList);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        addActivityFab = (FloatingActionButton)view.findViewById(R.id.fab);

        addActivityFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(getActivity(),"Currently functional!",Toast.LENGTH_SHORT).show();
                long date = System.currentTimeMillis();

                SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy h:mm a");
                String dateString = sdf.format(date);

                Activity activity = new Activity();
//                activity.setActivityId((long)count++);
//                activity.setActivity_status("In Process");
//                activity.setStartDate(dateString);
                activity.setStatus(Activity.StatusEnum.CREATED);
                Job job = new Job();
                job.setJobId(DigitalFormActivity.SELECTEDFORM.getFormid());
                activity.setCivilJob(job);
                createActivity(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, activity);
//                activities.add(activity);
//                recyclerView.setAdapter(new ActivityListAdapter(activities, getActivity()));
            }
        });

        return view;

    }

    public void getActivityListByJobAndStatus(JobsService mService, AppExecutors executors, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getActivityListByJobAndStatus(jobId, "created", APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<Activity>>() {
                @Override
                public void onResponse(Call<List<Activity>> call, Response<List<Activity>> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        activities = new ArrayList<>(response.body());
                        if (activities.size()>0){
                            DigitalFormActivity.SELECTEDFORM.setJobid(activities.get(0).getActivityId());
                        }
                        recyclerView.setAdapter(new ActivityListAdapter(activities, getActivity()));
//                        activities.addAll(response.body());
//                        Log.e(TAG, activities.size()+"");
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " activity", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<List<Activity>> call, Throwable t) {
                    Log.e(TAG + " activity", "Error during API call" + call.toString() + t);
                }
            });
        });
    }

    public void createActivity(JobsService mService, AppExecutors executors, Activity activity) {
        executors.getNetworkIO().execute(() -> {
            mService.createActivity(activity, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, "Activity created " + response.body().getActivityId());
                        getActivityListByJobAndStatus(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getFormid()+"");
                    } else if (response.code()==226) {
                        Toast.makeText(getContext(), "Active activity is already present.. cannot create new", Toast.LENGTH_LONG).show();
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " activity", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG + " activity", "Error during API call" + call.request().url() + " : " + t);
                    Toast.makeText(getContext(), "Active activity is already present.. cannot create new", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    public void setActivityList(List<Activity> activityList) {
        activities = new ArrayList<>(activityList);
    }
}
