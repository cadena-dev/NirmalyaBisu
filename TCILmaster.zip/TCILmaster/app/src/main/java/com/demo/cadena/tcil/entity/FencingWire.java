package com.demo.cadena.tcil.entity;

import java.util.Objects;
import java.math.BigDecimal;
/**
 * FencingWire
 */


public class FencingWire extends AuditModel  {

  private Long id = null;

  private DSRDetails dsrNo = null;

  private Integer noOfPillars = null;

  private BigDecimal length = null;

  private BigDecimal quantity = null;

  public FencingWire id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public FencingWire dsrNo(DSRDetails dsrNo) {
    this.dsrNo = dsrNo;
    return this;
  }

  /**
   * Get dsrNo
   * @return dsrNo
  **/

  public DSRDetails getDsrNo() {
    return dsrNo;
  }

  public void setDsrNo(DSRDetails dsrNo) {
    this.dsrNo = dsrNo;
  }

  public FencingWire noOfPillars(Integer noOfPillars) {
    this.noOfPillars = noOfPillars;
    return this;
  }

  /**
   * Get noOfPillars
   * @return noOfPillars
  **/


  public Integer getNoOfPillars() {
    return noOfPillars;
  }

  public void setNoOfPillars(Integer noOfPillars) {
    this.noOfPillars = noOfPillars;
  }

  public FencingWire length(BigDecimal length) {
    this.length = length;
    return this;
  }

  /**
   * Get length
   * @return length
  **/

  public BigDecimal getLength() {
    return length;
  }

  public void setLength(BigDecimal length) {
    this.length = length;
  }

  public FencingWire quantity(BigDecimal quantity) {
    this.quantity = quantity;
    return this;
  }

  /**
   * Get quantity
   * @return quantity
  **/

  public BigDecimal getQuantity() {
    return quantity;
  }

  public void setQuantity(BigDecimal quantity) {
    this.quantity = quantity;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FencingWire fencingWire = (FencingWire) o;
    return Objects.equals(this.id, fencingWire.id) &&
        Objects.equals(this.dsrNo, fencingWire.dsrNo) &&
        Objects.equals(this.noOfPillars, fencingWire.noOfPillars) &&
        Objects.equals(this.length, fencingWire.length) &&
        Objects.equals(this.quantity, fencingWire.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, dsrNo, noOfPillars, length, quantity);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FencingWire {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    dsrNo: ").append(toIndentedString(dsrNo)).append("\n");
    sb.append("    noOfPillars: ").append(toIndentedString(noOfPillars)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

