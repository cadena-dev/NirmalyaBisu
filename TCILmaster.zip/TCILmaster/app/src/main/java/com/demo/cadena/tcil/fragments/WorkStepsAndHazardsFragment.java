package com.demo.cadena.tcil.fragments;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.CursorLoader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.utils.DatabaseInitializer;
import com.github.gcacace.signaturepad.views.SignaturePad;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

//import com.google.zxing.integration.android.IntentIntegrator;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link WorkStepsAndHazardsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WorkStepsAndHazardsFragment extends Fragment implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    private static final String DATA = "data";
    private Button btnCaptureImage1;
    private Button btnCaptureImage2;
    private Button btnCaptureImage3;
    private Button btnEditImage1;
    private Button btnEditImage2;
    private Button btnEditImage3;
    private Button btnWorkStepsAndHazardsSave;

    private SignaturePad imageEditPad1;
    private SignaturePad imageEditPad2;
    private SignaturePad imageEditPad3;
    private EditText edtImageComment1;
    private EditText edtImageComment2;
    private EditText edtImageComment3;

    private TextView txtLatLongImage1;
    private TextView txtLatLongImage2;
    private TextView txtLatLongImage3;

    private TextView txtTimestampImage1;
    private TextView txtTimestampImage2;
    private TextView txtTimestampImage3;

//    private GoogleMap googleMap;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    private double latitude;
    private double longitude;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int RESULT_OK = -1;
    private static  final int MY_PERMISSIONS_REQUEST_CAMERA = 3;

    private static int imageNumber;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public static final String TAG = "WorkStepsAndHazard";

    public WorkStepsAndHazardsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment WorkStepsAndHazardsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static WorkStepsAndHazardsFragment newInstance(String param1, String param2) {
        WorkStepsAndHazardsFragment fragment = new WorkStepsAndHazardsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        mGoogleApiClient = new GoogleApiClient.Builder(getActivity().getApplicationContext())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    // ...
                }
            }

            ;
        };

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_work_steps_and_hazards, container, false);
        btnCaptureImage1 = (Button) view.findViewById(R.id.btn_capture_image1);
        btnCaptureImage2 = (Button) view.findViewById(R.id.btn_capture_image2);
        btnCaptureImage3 = (Button) view.findViewById(R.id.btn_capture_image3);
        btnEditImage1 = (Button) view.findViewById(R.id.btn_edit_image1);
        btnEditImage2 = (Button) view.findViewById(R.id.btn_edit_image2);
        btnEditImage3 = (Button) view.findViewById(R.id.btn_edit_image3);
        imageEditPad1 = (SignaturePad) view.findViewById(R.id.image_edit_pad1);
        imageEditPad2 = (SignaturePad) view.findViewById(R.id.image_edit_pad2);
        imageEditPad3 = (SignaturePad) view.findViewById(R.id.image_edit_pad3);
//        imageEditPad.setBackgroundColor(Color.TRANSPARENT);
        edtImageComment1 = (EditText)view.findViewById(R.id.edt_image_comment1);
        edtImageComment2 = (EditText)view.findViewById(R.id.edt_image_comment2);
        edtImageComment3 = (EditText)view.findViewById(R.id.edt_image_comment3);
        txtLatLongImage1 = (TextView) view.findViewById(R.id.txt_lat_long_image1);
        txtLatLongImage2 = (TextView) view.findViewById(R.id.txt_lat_long_image2);
        txtLatLongImage3 = (TextView) view.findViewById(R.id.txt_lat_long_image3);

        txtTimestampImage1 = (TextView) view.findViewById(R.id.txt_timestamp_image1);
        txtTimestampImage2 = (TextView) view.findViewById(R.id.txt_timestamp_image2);
        txtTimestampImage3 = (TextView) view.findViewById(R.id.txt_timestamp_image3);

        btnWorkStepsAndHazardsSave = (Button)view.findViewById(R.id.btn_work_steps_and_hazards_save);

        Log.e(TAG, "Image at onCreateView");
//        if (DigitalFormActivity.SELECTEDFORM.getImage() != null) {
            loadimage();
            loadComments();
            loadLatLong();
            loadTimestamp();
//        }

        imageEditPad1.setEnabled(false);
        imageEditPad2.setEnabled(false);
        imageEditPad3.setEnabled(false);
        imageEditPad1.setPenColor(Color.RED);
        imageEditPad2.setPenColor(Color.RED);
        imageEditPad3.setPenColor(Color.RED);

//        imageNumber = 0;

        btnCaptureImage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent();
                btnEditImage1.setEnabled(true);
                //btnSaveData.setEnabled(true);
                imageNumber = btnCaptureImage1.getId();
            }
        });
        btnCaptureImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent();
                btnEditImage2.setEnabled(true);
                //btnSaveData.setEnabled(true);
                imageNumber = btnCaptureImage2.getId();
            }
        });
        btnCaptureImage3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent();
                btnEditImage3.setEnabled(true);
                //btnSaveData.setEnabled(true);
                imageNumber = btnCaptureImage3.getId();
                Log.e(TAG, "Image 3 ImageNumber : " + imageNumber);
            }
        });

        btnEditImage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (btnEditImage1.getText().equals("Save")) {
                    btnEditImage1.setText("Edit Image");
                    imageEditPad1.setEnabled(false);



                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    Bitmap bitmap = imageEditPad1.getSignatureBitmap();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byte[] bytes = byteArrayOutputStream.toByteArray();

                    Log.e(TAG, "Image at save : " + Environment.getExternalStorageDirectory().toString());
                    DigitalFormActivity.appExecutors.getMainThread().execute(() -> {
                        FileOutputStream fileOutputStream = null;
                        try {
                            File file = new File (DigitalFormActivity.SELECTEDFORM.getImage());
                            fileOutputStream = new FileOutputStream(file);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            Log.e(TAG, "Image write complete");
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }  finally {
                            try {
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    Toast.makeText(getActivity(), "Saved", Toast.LENGTH_LONG).show();
                } else {
                    btnEditImage1.setText("Save");
                    imageEditPad1.setEnabled(true);
                    Log.e(TAG, "Image at Edit");
                }
            }
        });
        btnEditImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (btnEditImage2.getText().equals("Save")) {
                    btnEditImage2.setText("Edit Image");
                    imageEditPad2.setEnabled(false);



                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    Bitmap bitmap = imageEditPad2.getSignatureBitmap();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byte[] bytes = byteArrayOutputStream.toByteArray();

                    Log.e(TAG, "Image at save : " + Environment.getExternalStorageDirectory().toString());
                    DigitalFormActivity.appExecutors.getMainThread().execute(() -> {
                        FileOutputStream fileOutputStream = null;
                        try {
                            File file = new File (DigitalFormActivity.SELECTEDFORM.getImage2());
                            fileOutputStream = new FileOutputStream(file);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            Log.e(TAG, "Image write complete");
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }  finally {
                            try {
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    Toast.makeText(getActivity(), "Saved", Toast.LENGTH_LONG).show();
                } else {
                    btnEditImage2.setText("Save");
                    imageEditPad2.setEnabled(true);
                    Log.e(TAG, "Image at Edit");
                }
            }
        });
        btnEditImage3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (btnEditImage3.getText().equals("Save")) {
                    btnEditImage3.setText("Edit Image");
                    imageEditPad3.setEnabled(false);



                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    Bitmap bitmap = imageEditPad3.getSignatureBitmap();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byte[] bytes = byteArrayOutputStream.toByteArray();

                    Log.e(TAG, "Image at save : " + Environment.getExternalStorageDirectory().toString());
                    DigitalFormActivity.appExecutors.getMainThread().execute(() -> {
                        FileOutputStream fileOutputStream = null;
                        try {
                            File file = new File (DigitalFormActivity.SELECTEDFORM.getImage3());
                            fileOutputStream = new FileOutputStream(file);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            Log.e(TAG, "Image write complete");
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }  finally {
                            try {
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    Toast.makeText(getActivity(), "Saved", Toast.LENGTH_LONG).show();
                } else {
                    btnEditImage3.setText("Save");
                    imageEditPad3.setEnabled(true);
                    Log.e(TAG, "Image at Edit");
                }
            }
        });

        btnWorkStepsAndHazardsSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DigitalFormActivity.SELECTEDFORM.setImageComment(edtImageComment1.getText().toString());
                DigitalFormActivity.SELECTEDFORM.setImageComment2(edtImageComment2.getText().toString());
                DigitalFormActivity.SELECTEDFORM.setImageComment3(edtImageComment3.getText().toString());
                DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                DigitalFormActivity.initializeLists(getActivity());
                Toast.makeText(getActivity(),"Saved",Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }

    private void loadLatLong() {
        if (DigitalFormActivity.SELECTEDFORM.getImage1Lat() != null) {
            String latLong = DigitalFormActivity.SELECTEDFORM.getImage1Lat() + " : " + DigitalFormActivity.SELECTEDFORM.getImage1Long();
            txtLatLongImage1.setText(latLong);
        }
        if (DigitalFormActivity.SELECTEDFORM.getImage2Lat() != null) {
            String latLong = DigitalFormActivity.SELECTEDFORM.getImage2Lat() + " : " + DigitalFormActivity.SELECTEDFORM.getImage2Long();
            txtLatLongImage2.setText(latLong);
        }
        if (DigitalFormActivity.SELECTEDFORM.getImage3Lat() != null) {
            String latLong = DigitalFormActivity.SELECTEDFORM.getImage3Lat() + " : " + DigitalFormActivity.SELECTEDFORM.getImage3Long();
            txtLatLongImage3.setText(latLong);
        }
    }

    private void loadTimestamp() {
        if (DigitalFormActivity.SELECTEDFORM.getImage1Timestamp() != null) {
            String timestamp = DigitalFormActivity.SELECTEDFORM.getImage1Timestamp();
            txtTimestampImage1.setText(timestamp);
        }
        if (DigitalFormActivity.SELECTEDFORM.getImage2Timestamp() != null) {
            String timestamp = DigitalFormActivity.SELECTEDFORM.getImage2Timestamp();
            txtTimestampImage2.setText(timestamp);
        }
        if (DigitalFormActivity.SELECTEDFORM.getImage3Timestamp() != null) {
            String timestamp = DigitalFormActivity.SELECTEDFORM.getImage3Timestamp();
            txtTimestampImage3.setText(timestamp);
        }
    }

    private void dispatchTakePictureIntent(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePictureIntent.resolveActivity(getContext().getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void loadimage() {
        imageEditPad1.setBackgroundColor(Color.TRANSPARENT);
        Bitmap imageBitmap = null;
        imageBitmap = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getImage());
        imageEditPad1.clear();
        if (imageBitmap != null) {
            imageEditPad1.setSignatureBitmap(imageBitmap);
        }
        else
        {
            imageEditPad1.setSignatureBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.default_capture_image_one));
        }

        imageEditPad2.setBackgroundColor(Color.TRANSPARENT);
        Bitmap imageBitmap2 = null;
        imageBitmap2 = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getImage2());
        imageEditPad2.clear();
        if (imageBitmap2 != null) {
            imageEditPad2.setSignatureBitmap(imageBitmap2);
        }
        else
        {
            imageEditPad2.setSignatureBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.default_capture_image_two));
        }

        imageEditPad3.setBackgroundColor(Color.TRANSPARENT);
        Bitmap imageBitmap3 = null;
        imageBitmap3 = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getImage3());
        imageEditPad3.clear();
        if (imageBitmap3 != null) {
            imageEditPad3.setSignatureBitmap(imageBitmap3);
        }
        else
        {
            imageEditPad3.setSignatureBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.default_capture_image_three));
        }
    }

    private void loadComments() {
        edtImageComment1.setText(DigitalFormActivity.SELECTEDFORM.getImageComment());
        edtImageComment2.setText(DigitalFormActivity.SELECTEDFORM.getImageComment2());
        edtImageComment3.setText(DigitalFormActivity.SELECTEDFORM.getImageComment3());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.e(TAG, "On Activity Result call" + requestCode + " " + resultCode);

        switch (imageNumber) {
            case R.id.btn_capture_image1:
                if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {

                    SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    String format = s.format(new Date());
                    txtTimestampImage1.setText(format);
                    String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL";
                    File dir = new File(path);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    File dest = new File(dir, "Image" + DigitalFormActivity.SELECTEDFORM.getFormid() + "1.jpg");
                    Bitmap bitmap = (Bitmap)data.getExtras().get("data");
                    FileOutputStream out = null;
                    try {
                        out = new FileOutputStream(dest);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                        out.flush();
                        out.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (out != null) {
                                out.close();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    getLatLong();

                    DigitalFormActivity.SELECTEDFORM.setImage1Lat(latitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage1Long(longitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage1Timestamp(format);
                    DigitalFormActivity.SELECTEDFORM.setImage(dest.getAbsolutePath());
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                    DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                    DigitalFormActivity.initializeLists(getActivity());
                    loadimage();
                    loadLatLong();
                    loadTimestamp();
                }
                break;

            case R.id.btn_capture_image2:
                if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {

                    SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    String format = s.format(new Date());
                    txtTimestampImage2.setText(format);
                    String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL";
                    File dir = new File(path);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    File dest = new File(dir, "Image" + DigitalFormActivity.SELECTEDFORM.getFormid() + "2.jpg");
                    Bitmap bitmap = (Bitmap)data.getExtras().get("data");
                    FileOutputStream out = null;
                    try {
                        out = new FileOutputStream(dest);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                        out.flush();
                        out.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (out != null) {
                                out.close();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    getLatLong();

                    DigitalFormActivity.SELECTEDFORM.setImage2Lat(latitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage2Long(longitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage2Timestamp(format);
                    DigitalFormActivity.SELECTEDFORM.setImage2(dest.getAbsolutePath());
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                    DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                    DigitalFormActivity.initializeLists(getActivity());
                    loadimage();
                    loadLatLong();
                    loadTimestamp();
                    loadTimestamp();
                }
                break;

            case R.id.btn_capture_image3:
                if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {

                    SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    String format = s.format(new Date());
                    txtTimestampImage3.setText(format);
                    String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL";
                    File dir = new File(path);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    File dest = new File(dir, "Image" + DigitalFormActivity.SELECTEDFORM.getFormid() + "3.jpg");
                    Bitmap bitmap = (Bitmap)data.getExtras().get("data");
                    FileOutputStream out = null;
                    try {
                        out = new FileOutputStream(dest);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                        out.flush();
                        out.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (out != null) {
                                out.close();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    getLatLong();

                    DigitalFormActivity.SELECTEDFORM.setImage3Lat(latitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage3Long(longitude+"");
                    DigitalFormActivity.SELECTEDFORM.setImage3Timestamp(format);
                    DigitalFormActivity.SELECTEDFORM.setImage3(dest.getAbsolutePath());
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                    DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                    DigitalFormActivity.initializeLists(getActivity());
                    loadimage();
                    loadLatLong();
                    loadTimestamp();
                }
                break;
        }

    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    public void getLatLong () {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        } else {
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());
            Task<Location> location = mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location == null) {
                                startLocationUpdates();
                            } else {
                                //If everything went fine lets get latitude and longitude
                                latitude = location.getLatitude();
                                longitude = location.getLongitude();
                            }
                        }
                    });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        //mapView.onResume();
        mGoogleApiClient.connect();
    }

//    @Override
//    public void onPause() {
//        super.onPause();
//        //mapView.onPause();
//        if (mGoogleApiClient.isConnected()) {
//            mGoogleApiClient.disconnect();
//        }
//        stopLocationUpdates();
//    }


//    @Override
//    public void onDestroy() {
//        Log.e(TAG, "On Destroy");
//        if (mGoogleApiClient.isConnected()) {
//            mGoogleApiClient.disconnect();
//        }
//        stopLocationUpdates();
//        super.onDestroy();
//    }

    private void stopLocationUpdates() {
        mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                } else {
                    Toast.makeText(getContext(), "Camera permission denied. Cannot scan QR.", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        getLatLong();
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    // TODO: Rename method, update argument and hook method into UI event
//    public void onButtonPressed(Uri uri) {
//        if (mListener != null) {
//            mListener.onFragmentInteraction(uri);
//        }
//    }
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    /**
//     * This interface must be implemented by activities that contain this
//     * fragment to allow an interaction in this fragment to be communicated
//     * to the activity and potentially other fragments contained in that
//     * activity.
//     * <p>
//     * See the Android Training lesson <a href=
//     * "http://developer.android.com/training/basics/fragments/communicating.html"
//     * >Communicating with Other Fragments</a> for more information.
//     */
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        void onFragmentInteraction(Uri uri);
//    }
}
