package com.demo.cadena.tcil.retrofit;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;


import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.activities.FormActivity;
import com.demo.cadena.tcil.activities.LoginActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.entity.LoginForm;
import com.demo.cadena.tcil.entity.LoginResponse;
import com.demo.cadena.tcil.entity.MobileJobDataUploadResponse;
import com.demo.cadena.tcil.entity.PDFResponse;
import com.demo.cadena.tcil.entity.SingleImageUploadResponse;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.utils.DatabaseInitializer;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class APICalls {

    private static final String TAG = "APICalls";

    public static Map<String, String> setHeaders(SharedPreferences sharedPreferences) {
        String jwtToken = sharedPreferences.getString(String.valueOf(R.string.jwtToken), null);
        Map<String, String> map = new HashMap<>();
        map.put("Accept", "application/json");
        map.put("Content-Type", "application/json");
//        if (jwtToken != null) {
//            map.put("Authorization", jwtToken);
//            map.put("Content-Type", "application/json");
//        }
        return map;
    }

    public static Map<String, String> setHeaders() {
        Map<String, String> map = new HashMap<>();
        map.put("Accept", "application/json");
        map.put("Content-Type", "application/json");
        return map;
    }

    public static Map<String, String> setFileHeaders() {
        Map<String, String> map = new HashMap<>();
        map.put("Accept", "application/json");
//        map.put("Content-Type", "multipart/form-data");
        return map;
    }

    public static void login(UserService mService, AppExecutors executors, LoginActivity context, String username, String password) {
        LoginForm loginForm = new LoginForm();
        loginForm.setUserName(username);
        loginForm.setPassword(password);

        executors.getNetworkIO().execute(() -> {
            mService.login(loginForm, setHeaders(LoginActivity.sharedPreferences)).enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (response.code() == 200) {
                        Log.e(TAG, "Response Body : " + response.body().toString());
//                        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
                        Log.e(TAG, response.body().getEmployee_id());
                        Log.e(TAG, "Login in progress");
                        String jwtToken = response.body().getToken_value();
                        String employeeId = response.body().getEmployee_id();
                        SharedPreferences.Editor editor = LoginActivity.sharedPreferences.edit();
                        editor.putString(context.getString(R.string.jwtToken), jwtToken);
                        editor.putString(context.getString(R.string.employee_id), employeeId);
//                        Log.e(TAG, "Employee ID : " + employeeId);
                        DigitalFormActivity.EMPLOYEE_ID = employeeId;
                        editor.apply();
                        context.startActivity(new Intent(context, DigitalFormActivity.class));
                        Log.e(TAG, "JWT Key : " + jwtToken);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody() + response.raw());
                        Toast.makeText(context, "Invalid Username/Password", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                    Toast.makeText(context, "Error during API call", Toast.LENGTH_LONG).show();
                }
            });
        });
    }


    public static void getJobById(JobsService mService, AppExecutors executors, Context context, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobById(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<Job>() {
                @Override
                public void onResponse(Call<Job> call, Response<Job> response) {
                    if (response.code() == 200) {

                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody() + response.raw());
                        Toast.makeText(context, "Invalid Username/Password", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<Job> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                    Toast.makeText(context, "Error during API call", Toast.LENGTH_LONG).show();
                }
            });
        });
    }



//    public static void loginUserWithNetwork(ItemsService mService, AppExecutors executors, LoginActivity context, String username, String password) {
//        LoginForm loginForm = new LoginForm();
//        loginForm.setUserName(username);
//        loginForm.setPassword(password);
//        executors.getNetworkIO().execute(() -> {
//            mService.login(loginForm, setHeaders(LoginActivity.sharedPreferences)).enqueue(new Callback<ModelApiResponse>() {
//                @Override
//                public void onResponse(Call<ModelApiResponse> call, Response<ModelApiResponse> response) {
//                    if (response.isSuccessful()) {
////                        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
//                        String jwtToken = response.body().getMessage();
//                        SharedPreferences.Editor editor = LoginActivity.sharedPreferences.edit();
//                        editor.putString(context.getString(R.string.jwtToken), jwtToken);
//                        editor.apply();
//                        context.startActivity(new Intent(context, DigitalFormActivity.class));
//                        Log.e(TAG, "JWT Key : " + jwtToken);
//                    } else {
//                        int statusCode = response.code();
//                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody() + response.raw());
//                        Toast.makeText(context, "Invalid Username/Password", Toast.LENGTH_LONG).show();
//                    }
//                }
//
//                @Override
//                public void onFailure(Call<ModelApiResponse> call, Throwable t) {
//                    Log.e(TAG, "Error during API call" + call.toString() + t);
//                    Toast.makeText(context, "Error during API call", Toast.LENGTH_LONG).show();
//                }
//            });
//        });
//    }

//    public static void populateJobFromNetwork(ItemsService mService, AppExecutors executors, Context context) {
//        Log.e(TAG, "Employee ID : " + DigitalFormActivity.EMPLOYEE_ID);
//        executors.getMainThread().execute(() -> {
//            mService.getJobs(APICalls.setHeaders()).enqueue(new Callback<List<Job>>() {
//                @Override
//                public void onResponse(Call<List<Job>> call, Response<List<Job>> response) {
//                    if (response.isSuccessful()) {
////                        DigitalFormActivity.jobs = response.body();
////                        Log.e(TAG, DigitalFormActivity.jobs.size()+"");
//                        DatabaseInitializer.populateInboxJob(response.body());
////                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
////                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
////                        DatabaseInitializer.populateJobNetworkToDB(database);
////                        for (int i = 0; i < response.body().size(); i++) {
////                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
////                        }
//                    } else {
//                        int statusCode = response.code();
//                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
//                    }
//                }
//
//                @Override
//                public void onFailure(Call<List<Job>> call, Throwable t) {
//                    Log.e(TAG, "Error during API call" + call.toString() + t);
//                }
//            });
//        });
//    }

    public static void populateCompletedJobsFromNetwork(ItemsService mService, AppExecutors executors, Context context) {
        Log.e(TAG, "Employee ID : " + DigitalFormActivity.EMPLOYEE_ID);
        executors.getMainThread().execute(() -> {
            mService.getCompletedJobs(DigitalFormActivity.EMPLOYEE_ID, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<Job>>() {
                @Override
                public void onResponse(Call<List<Job>> call, Response<List<Job>> response) {
                    if (response.isSuccessful()) {
                        DatabaseInitializer.populateSentJob(response.body());
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<List<Job>> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.toString() + t);
                }
            });
        });
    }

    public static void updateJobStatus(JobsService mService, AppExecutors executors, Context context, String status, String jobId) {
        Log.e(TAG + " status", "Employee ID : " + DigitalFormActivity.EMPLOYEE_ID);
        executors.getNetworkIO().execute(() -> {
            mService.updateJobStatus(jobId, status, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Log.e(TAG, "Job status updated");
                        if (status.equals("completed")) {
                            Toast.makeText(context, "Job completed..!! Submitted!", Toast.LENGTH_LONG).show();
                        } else if (status.equals("updated")) {
                            Toast.makeText(context, "Job updated..!! In Progress!", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " status", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Log.e(TAG + " status", "Error during API call" + call.toString() + t);
                }
            });
        });
    }


    public static void updateActivityStatus(JobsService mService, AppExecutors executors, Context context, String status, String activityId) {
        Log.e(TAG + " status", "Employee ID : " + DigitalFormActivity.EMPLOYEE_ID);
        executors.getNetworkIO().execute(() -> {
            mService.updateActivityStatus(activityId, status, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        if (status.equals("completed")) {
                            Log.e(TAG, "Activity status completed");
                            Toast.makeText(context, "Activity completed..!! Submitted!", Toast.LENGTH_LONG).show();
                        } else if (status.equals("updated")) {
                            Log.e(TAG, "Activity status updated");
                            Toast.makeText(context, "Activity updated..!! In Progress!", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " status", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Log.e(TAG + " status", "Error during API call" + call.toString() + t);
                }
            });
        });
    }


    public static void getLatLong(ItemsService mService, AppExecutors executors, Context context, String address, boolean sensor) {
        ApplicationInfo ai = null;
        try {
            ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String key = bundle.getString("com.google.android.geo.API_KEY");

            executors.getNetworkIO().execute(() -> {
                mService.getLatLong(address, sensor, key).enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        if (response.isSuccessful()) {
//                        DigitalFormActivity.jobs = response.body();
//                            Job job = response.body();
                            Log.e(TAG + " latlong", "Lat Long : " + response.body().toString());
//                        DatabaseInitializer.populateInboxJob(DigitalFormActivity.jobs);
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                        } else {
                            int statusCode = response.code();
                            Log.e(TAG + " latlong", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                        }
                    }

                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                        Log.e(TAG + " latlong", "Error during API call" + call.toString() + t);
                    }
                });
            });

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void uploadFile(ItemsService mService, AppExecutors executors, int jobId, File file) {
        Log.e(TAG, "File uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        String jobStr = jobId + "";
        RequestBody jobIdBody = RequestBody.create(MultipartBody.FORM, jobStr);
        MultipartBody.Part pdfFile = prepareFilePart("file", file);
        ItemsService service = ApiUtils.createService(ItemsService.class);
        Log.e(TAG, pdfFile.toString());
        executors.getNetworkIO().execute(() -> {
            service.uploadFile(jobIdBody, pdfFile).enqueue(new Callback<PDFResponse>() {
                @Override
                public void onResponse(Call<PDFResponse> call, Response<PDFResponse> response) {
                    if (response.isSuccessful()) {
                        Log.e(TAG + " uploadFile", "File Upload Successful : " + response.body().getResult());
//                        DigitalFormActivity.jobs = response.body();
//                        Job job = response.body();
//                        Log.e(TAG, job.toString());
//                        DatabaseInitializer.populateInboxJob(DigitalFormActivity.jobs);
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " uploadFile", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<PDFResponse> call, Throwable t) {
                    Log.e(TAG + " uploadFile", "Error during API call" + t.getMessage());
                }
            });
        });
    }

    public static void uploadActivityImage(JobsService mService,
                                           AppExecutors executors,
                                           String activityId,
                                           File file,
                                           String latitude,
                                           String longitude,
                                           String description) {
        Log.e(TAG, "File uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        MultipartBody.Part imageFile = prepareFilePart("file", file);
        executors.getNetworkIO().execute(() -> {
            mService.uploadImage(activityId, latitude, longitude, description, imageFile, APICalls.setFileHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG + " image", "Image Upload Successful ");
//                        DigitalFormActivity.jobs = response.body();
//                        Job job = response.body();
//                        Log.e(TAG, job.toString());
//                        DatabaseInitializer.populateInboxJob(DigitalFormActivity.jobs);
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                    } else {
                        int statusCode = response.code();
                        try {
                            Log.e(TAG + " image", "Status Code : " + statusCode + "; Error : " + response.errorBody().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG + " image", "Error during API call" + t.getMessage());
                }
            });
        });
    }

    public static void uploadActivitySign(JobsService mService, AppExecutors executors, String activityId, File file) {
        Log.e(TAG, "File uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        MultipartBody.Part imageFile = prepareFilePart("file", file);
        executors.getNetworkIO().execute(() -> {
            mService.uploadSign(activityId, imageFile, APICalls.setFileHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG + " Sign", "Sign Upload Successful ");
//                        DigitalFormActivity.jobs = response.body();
//                        Job job = response.body();
//                        Log.e(TAG, job.toString());
//                        DatabaseInitializer.populateInboxJob(DigitalFormActivity.jobs);
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                    } else {
                        int statusCode = response.code();
                        try {
                            Log.e(TAG + " Sign", "Status Code : " + statusCode + "; Error : " + response.errorBody().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG + " Sign", "Error during API call" + t.getMessage());
                }
            });
        });
    }

    public static void uploadActivityVideo(JobsService mService,
            AppExecutors executors,
            String activityId,
            File file,
            String latitude,
            String longitude,
            String description) {
        Log.e(TAG, "File uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        MultipartBody.Part videoFile = prepareFilePart("file", file);
        executors.getNetworkIO().execute(() -> {
            mService.uploadVideo(activityId, latitude, longitude, description, videoFile, APICalls.setFileHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG + " Video", "Video Upload Successful " + response.body().getVideo().getLink());
//                        DigitalFormActivity.jobs = response.body();
//                        Job job = response.body();
//                        Log.e(TAG, job.toString());
//                        DatabaseInitializer.populateInboxJob(DigitalFormActivity.jobs);
//                        DatabaseInitializer.populateAsync(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.jobs);
//                        AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//                        DatabaseInitializer.populateJobNetworkToDB(database);
//                        for (int i = 0; i < response.body().size(); i++) {
//                            Log.e(TAG, "Jobs : " + response.body().get(i).getJobTitle());
//                        }
                    } else {
                        int statusCode = response.code();
                        try {
                            Log.e(TAG + " Video", "Status Code : " + statusCode + "; Error : " + response.errorBody().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG + " Video", "Error during API call" + t.getMessage());
                }
            });
        });
    }


    public static void uploadSingleImage(ItemsService mService, AppExecutors executors, int jobId, double lat, double lon, String desc, long enggId, String timestamp, File file) {
        Log.e(TAG, "Image File uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        String jobStr = jobId + "";
        RequestBody jobIdBody = RequestBody.create(MultipartBody.FORM, jobStr);
        RequestBody latBody = RequestBody.create(MultipartBody.FORM, lat+"");
        RequestBody lonBody = RequestBody.create(MultipartBody.FORM, lon+"");
        RequestBody descBody = RequestBody.create(MultipartBody.FORM, desc);
        RequestBody enggIdBody = RequestBody.create(MultipartBody.FORM, enggId+"");
        RequestBody timeStampBody = RequestBody.create(MultipartBody.FORM, timestamp);
        MultipartBody.Part pdfFile = prepareFilePart("file", file);
        ItemsService service = ApiUtils.createService(ItemsService.class);
        Log.e(TAG, pdfFile.toString());
        executors.getNetworkIO().execute(() -> {
            service.uploadSingleImage(jobIdBody, latBody, lonBody, descBody, enggIdBody, timeStampBody, pdfFile).enqueue(new Callback<SingleImageUploadResponse>() {
                @Override
                public void onResponse(Call<SingleImageUploadResponse> call, Response<SingleImageUploadResponse> response) {
                    if (response.isSuccessful()) {
                        Log.e(TAG + " image", "File Upload Successful : " + response.body().getResult());
                        Log.e(TAG + " image", "Image Link : " + response.body().getResult());
//                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " image", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<SingleImageUploadResponse> call, Throwable t) {
                    Log.e(TAG + " image", "Error during API call" + t.getMessage());
                }
            });
        });
    }


    public static void mobileJobDataUpload(ItemsService mService, AppExecutors executors, int jobId, boolean q1, boolean q2, boolean q3, boolean q4, boolean q5, boolean q6, String comment, String location, File file) {
        Log.e(TAG, "Mobile Data uploading");
//        RequestBody pdfFile = RequestBody.create(MediaType.parse("file"), file);
        String jobStr = jobId + "";
        RequestBody jobIdBody = RequestBody.create(MultipartBody.FORM, jobStr);
        RequestBody q1Body = null;
        RequestBody q2Body = null;
        RequestBody q3Body = null;
        RequestBody q4Body = null;
        RequestBody q5Body = null;
        RequestBody q6Body = null;
        if (q1 == true) {
            q1Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q1Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        if (q2 == true) {
            q2Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q2Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        if (q3 == true) {
            q3Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q3Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        if (q4 == true) {
            q4Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q4Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        if (q5 == true) {
            q5Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q5Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        if (q6 == true) {
            q6Body = RequestBody.create(MultipartBody.FORM, "Yes");
        } else {
            q6Body = RequestBody.create(MultipartBody.FORM, "No");
        }
        RequestBody commentsBody = RequestBody.create(MultipartBody.FORM, comment);
        RequestBody locationBody = RequestBody.create(MultipartBody.FORM, location);
        MultipartBody.Part pdfFile = prepareFilePart("file", file);
        ItemsService service = ApiUtils.createService(ItemsService.class);
        Log.e(TAG, pdfFile.toString());
        RequestBody finalQ1Body = q1Body;
        RequestBody finalQ2Body = q2Body;
        RequestBody finalQ3Body = q3Body;
        RequestBody finalQ4Body = q4Body;
        RequestBody finalQ5Body = q5Body;
        RequestBody finalQ6Body = q6Body;
        executors.getNetworkIO().execute(() -> {
            service.mobileJobDataUpload(jobIdBody, finalQ1Body, finalQ2Body, finalQ3Body, finalQ4Body, finalQ5Body, finalQ6Body, locationBody, commentsBody, pdfFile).enqueue(new Callback<MobileJobDataUploadResponse>() {
                @Override
                public void onResponse(Call<MobileJobDataUploadResponse> call, Response<MobileJobDataUploadResponse> response) {
                    if (response.isSuccessful()) {
                        Log.e(TAG + " mobData", "Image Link : " + response.body().getImagePath());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " mobData", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<MobileJobDataUploadResponse> call, Throwable t) {
                    Log.e(TAG + " mobData", "Error during API call" + t.getMessage());
                }
            });
        });
    }


    @NonNull
    private static MultipartBody.Part prepareFilePart(String partName, File file) {
        // https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
        // use the FileUtils to get the actual file by uri
//        File file = new File(fileUri.getPath());
//        File file = FileUtils.getFile(context, fileUri);


        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create( MediaType.parse("application/pdf"),
                        file
                );

        // MultipartBody.Part is used to send also the actual file name
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }

    public static void updateActivity(JobsService mService, AppExecutors executors, Activity activity) {
        executors.getNetworkIO().execute(() -> {
            mService.updateActivity(activity, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, "Activity updated " + response.body().getActivityId());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG + " activity", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG + " activity", "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

}
