package com.demo.cadena.tcil.broadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;

import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.database.AppDatabase;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.utils.DatabaseInitializer;

import java.net.InetAddress;
import java.util.List;

public class CheckConnectivity extends BroadcastReceiver {

    private boolean isConnected = false;

    @Override
    public void onReceive(Context context, Intent intent) {

//        boolean isConnected = intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);
        if(!isNetworkAvailable(context)){
            // No Internet connectivity

        }
        else{
            // Internet Connected
            for (Form form: DigitalFormActivity.SYNCFORMS) {
                if (form.isSync()) {
                    form.setSync(false);
                    form.setFormStatus(DigitalFormActivity.SENT);
                }
            }
            Toast.makeText(context, "Forms to be synched : " + DigitalFormActivity.SYNCFORMS.size(), Toast.LENGTH_SHORT).show();
//            DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, context.getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
//            DigitalFormActivity.initializeLists(context);
        }
    }

    private boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        if (!isConnected) {
//                            Log.v(LOG_TAG, "Now you are connected to Internet!");
                            Toast.makeText(context, "Internet availablle via Broadcast receiver", Toast.LENGTH_SHORT).show();
                            isConnected = true;
                            // do your processing here ---
                            // if you need to post any data to the server or get
                            // status
                            // update from the server
                        }
                        return true;
                    }
                }
            }
        }
//        Log.v(LOG_TAG, "You are not connected to Internet!");
        Toast.makeText(context, "Internet NOT availablle via Broadcast receiver", Toast.LENGTH_SHORT).show();
        isConnected = false;
        return false;
    }
}
