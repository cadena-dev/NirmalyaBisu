package com.demo.cadena.tcil.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.utils.DatabaseInitializer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MyUploadFileRecyclerViewAdapter extends RecyclerView.Adapter<MyUploadFileRecyclerViewAdapter.ViewHolder> {

    private final ArrayList<String> files;
    private Context mContext;

    public static final String TAG = "FileAdapter";

    public MyUploadFileRecyclerViewAdapter (Context context) {
        mContext = context;
        files = loadFile();
    }

    private ArrayList<String> loadFile() {

        ArrayList<String> filePaths = new ArrayList<>();

        if (DigitalFormActivity.SELECTEDFORM.getFiles() != null) {
            try {
                JSONObject json = new JSONObject(DigitalFormActivity.SELECTEDFORM.getFiles());
                JSONArray pathArray = json.optJSONArray("filePaths");
                if (pathArray != null) {
                    for (int i = 0; i < pathArray.length(); i++) {
//                        String path = pathArray.getString(i);
//                        String fileName = path.substring(path.lastIndexOf('/'));
                        filePaths.add(pathArray.getString(i));
                    }
                }
            } catch (JSONException e) {
                Log.e(TAG, "Files read error : " + e);
                Toast.makeText(mContext, "Files read issue", Toast.LENGTH_SHORT).show();
            }
        }
        return filePaths;
    }

    @NonNull
    @Override
    public MyUploadFileRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.upload_file_adapter, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyUploadFileRecyclerViewAdapter.ViewHolder holder, int position) {
        holder.txtUploadFiles.setText(files.get(position));

        holder.btnCancelFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                files.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, files.size());
                JSONObject json = new JSONObject();
                try {
                    json.put("filePaths", new JSONArray(files));
                    String arrayList = json.toString();

                    DigitalFormActivity.SELECTEDFORM.setFiles(arrayList);
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                    DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, mContext.getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                    DigitalFormActivity.initializeLists(mContext);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return files.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        private TextView txtUploadFiles;
        public ImageButton btnCancelFile;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txtUploadFiles = (TextView) view.findViewById(R.id.txt_upload_files);
            btnCancelFile = (ImageButton) view.findViewById(R.id.btn_remove_file);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + txtUploadFiles.getText() + "'";
        }
    }

}
