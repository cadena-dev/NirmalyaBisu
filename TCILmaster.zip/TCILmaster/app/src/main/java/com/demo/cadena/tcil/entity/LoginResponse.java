package com.demo.cadena.tcil.entity;

public class LoginResponse {

    private String employeeId;

    private String token;

    public String getEmployee_id() {
        return employeeId;
    }

    public void setEmployee_id(String employee_id) {
        this.employeeId = employee_id;
    }

    public String getToken_value() {
        return token;
    }

    public void setToken_value(String token_value) {
        this.token = token_value;
    }
}
