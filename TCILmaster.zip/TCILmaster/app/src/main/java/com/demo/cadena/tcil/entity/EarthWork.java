package com.demo.cadena.tcil.entity;

import java.math.BigDecimal;
import java.util.Objects;


/**
 * EarthWork
 */

public class EarthWork extends AuditModel{

  private Long id = null;

  private Integer noOfPillars = null;


  private BigDecimal length = null;


  private BigDecimal bredth = null;


  private BigDecimal height = null;

  private DSRDetails dsrNo1 = null;

  private String quantity1 = null;

  private DSRDetails dsrNo2 = null;

  private String quantity2 = null;

  private DSRDetails dsrNo3 = null;

  private String quantity3 = null;

  public EarthWork id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EarthWork noOfPillars(Integer noOfPillars) {
    this.noOfPillars = noOfPillars;
    return this;
  }

  /**
   * Get noOfPillars
   * @return noOfPillars
  **/

  public Integer getNoOfPillars() {
    return noOfPillars;
  }

  public void setNoOfPillars(Integer noOfPillars) {
    this.noOfPillars = noOfPillars;
  }

  public EarthWork length(BigDecimal length) {
    this.length = length;
    return this;
  }

  /**
   * Get length
   * @return length
  **/

  public BigDecimal getLength() {
    return length;
  }

  public void setLength(BigDecimal length) {
    this.length = length;
  }

  public EarthWork bredth(BigDecimal bredth) {
    this.bredth = bredth;
    return this;
  }

  /**
   * Get bredth
   * @return bredth
  **/

  public BigDecimal getBredth() {
    return bredth;
  }

  public void setBredth(BigDecimal bredth) {
    this.bredth = bredth;
  }

  public EarthWork height(BigDecimal height) {
    this.height = height;
    return this;
  }

  /**
   * Get height
   * @return height
  **/

  public BigDecimal getHeight() {
    return height;
  }

  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  public EarthWork dsrNo1(DSRDetails dsrNo1) {
    this.dsrNo1 = dsrNo1;
    return this;
  }

  /**
   * Get dsrNo1
   * @return dsrNo1
  **/

  public DSRDetails getDsrNo1() {
    return dsrNo1;
  }

  public void setDsrNo1(DSRDetails dsrNo1) {
    this.dsrNo1 = dsrNo1;
  }

  public EarthWork quantity1(String quantity1) {
    this.quantity1 = quantity1;
    return this;
  }

  /**
   * Get quantity1
   * @return quantity1
  **/


  public String getQuantity1() {
    return quantity1;
  }

  public void setQuantity1(String quantity1) {
    this.quantity1 = quantity1;
  }

  public EarthWork dsrNo2(DSRDetails dsrNo2) {
    this.dsrNo2 = dsrNo2;
    return this;
  }

  /**
   * Get dsrNo2
   * @return dsrNo2
  **/

  public DSRDetails getDsrNo2() {
    return dsrNo2;
  }

  public void setDsrNo2(DSRDetails dsrNo2) {
    this.dsrNo2 = dsrNo2;
  }

  public EarthWork quantity2(String quantity2) {
    this.quantity2 = quantity2;
    return this;
  }

  /**
   * Get quantity2
   * @return quantity2
  **/

  public String getQuantity2() {
    return quantity2;
  }

  public void setQuantity2(String quantity2) {
    this.quantity2 = quantity2;
  }

  public EarthWork dsrNo3(DSRDetails dsrNo3) {
    this.dsrNo3 = dsrNo3;
    return this;
  }

  /**
   * Get dsrNo3
   * @return dsrNo3
  **/

  public DSRDetails getDsrNo3() {
    return dsrNo3;
  }

  public void setDsrNo3(DSRDetails dsrNo3) {
    this.dsrNo3 = dsrNo3;
  }

  public EarthWork quantity3(String quantity3) {
    this.quantity3 = quantity3;
    return this;
  }

  /**
   * Get quantity3
   * @return quantity3
  **/


  public String getQuantity3() {
    return quantity3;
  }

  public void setQuantity3(String quantity3) {
    this.quantity3 = quantity3;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EarthWork earthWork = (EarthWork) o;
    return Objects.equals(this.id, earthWork.id) &&
        Objects.equals(this.noOfPillars, earthWork.noOfPillars) &&
        Objects.equals(this.length, earthWork.length) &&
        Objects.equals(this.bredth, earthWork.bredth) &&
        Objects.equals(this.height, earthWork.height) &&
        Objects.equals(this.dsrNo1, earthWork.dsrNo1) &&
        Objects.equals(this.quantity1, earthWork.quantity1) &&
        Objects.equals(this.dsrNo2, earthWork.dsrNo2) &&
        Objects.equals(this.quantity2, earthWork.quantity2) &&
        Objects.equals(this.dsrNo3, earthWork.dsrNo3) &&
        Objects.equals(this.quantity3, earthWork.quantity3);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, noOfPillars, length, bredth, height, dsrNo1, quantity1, dsrNo2, quantity2, dsrNo3, quantity3);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EarthWork {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    noOfPillars: ").append(toIndentedString(noOfPillars)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    bredth: ").append(toIndentedString(bredth)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    dsrNo1: ").append(toIndentedString(dsrNo1)).append("\n");
    sb.append("    quantity1: ").append(toIndentedString(quantity1)).append("\n");
    sb.append("    dsrNo2: ").append(toIndentedString(dsrNo2)).append("\n");
    sb.append("    quantity2: ").append(toIndentedString(quantity2)).append("\n");
    sb.append("    dsrNo3: ").append(toIndentedString(dsrNo3)).append("\n");
    sb.append("    quantity3: ").append(toIndentedString(quantity3)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

