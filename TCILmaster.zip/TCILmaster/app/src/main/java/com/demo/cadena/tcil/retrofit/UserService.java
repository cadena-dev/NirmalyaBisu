package com.demo.cadena.tcil.retrofit;

import com.demo.cadena.tcil.entity.LoginForm;
import com.demo.cadena.tcil.entity.LoginResponse;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.HeaderMap;
import retrofit2.http.POST;

public interface UserService {

    @POST("user/login")
    Call<LoginResponse> login(
            @Body LoginForm loginForm,
            @HeaderMap Map<String, String> headers
    );

}
