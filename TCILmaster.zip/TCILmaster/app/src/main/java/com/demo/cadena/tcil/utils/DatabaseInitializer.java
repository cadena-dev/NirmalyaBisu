package com.demo.cadena.tcil.utils;

import android.content.Context;
import android.util.Log;

import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.broadcastReceivers.CheckConnectivity;
import com.demo.cadena.tcil.database.AppDatabase;
import com.demo.cadena.tcil.entity.Form;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.annotations.NonNull;

import static com.demo.cadena.tcil.activities.DigitalFormActivity.mService;

public class DatabaseInitializer {

    private static final String TAG = "DatabaseInit";

    public static void populateAsync(@NonNull final AppDatabase db, AppExecutors executors, Context context, List<Job> jobs) {
        Log.e(TAG, "Populate Async called");
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
//            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            DigitalFormActivity.appDatabase = AppDatabase.getInstance(context.getApplicationContext());
//            APICalls.populateJobFromNetwork(DigitalFormActivity.mService, DigitalFormActivity.appExecutors, context);
            populateJobNetworkToDB(DigitalFormActivity.appDatabase, jobs);
//            populateWithTestData(database);
        });
    }

    public static void populateJobNetworkToDB(AppDatabase db, List<Job> jobs) {

        if ((jobs != null) && (jobs.size() > 0)) { //Exception : checking whether the iist is null or not
            Log.e(TAG, jobs.size() + "");
            for (Job job : jobs) {
                Form form = new Form();
//            form.setJobLocation(job.getJob_location());
                form.setFormid((job.getJobId()));
//            form.setFormStatus(job.getStatus());
                form.setJobDescription(job.getJobType().getName());
//            form.setProject(job.getProject().get));
                form.setClientName(job.getProject().getClient().getClientName());
//            form.setInspector(job.getInspector());
//            form.setScheduleDate(job.getScheduleDate());
//            form.setCompleteDate(job.getCompleteDate());
//            if (job.getActivity_status().equals("N")) {
//                form.setFormStatus(DigitalFormActivity.INBOX);
//            } else if (job.getActivity_status().equals("C")) {
//                form.setFormStatus(DigitalFormActivity.SENT);
//            }
                form.setFormStatus(DigitalFormActivity.INBOX);
                addForm(db, form);
            }

            List<Form> forms = db.formDao().getAllForms();
            Log.e(DatabaseInitializer.TAG, "Rows Count : " + forms.size());
        }
    }
    public static void populateInboxJob(List<Job> jobs) {
        if ((jobs != null) && (jobs.size() > 0)) { //Exception : checking whether the iist is null or not
            Log.e(TAG, jobs.size() + "");
            DigitalFormActivity.INBOXFORMS = new ArrayList<>();
            for (Job job : jobs) {
                Form form = new Form();
//            form.setJobLocation(job.getJob_location());
                form.setFormid(job.getJobId());
//            form.setFormStatus(job.getStatus());
                form.setJobDescription(job.getJobTitle());
                form.setProject(job.getProject().getTitle());
//            form.setProject(job.getProject().get);
                form.setClientName(job.getProject().getClient().getClientName());
//            form.setInspector(job.getInspector());
//            form.setScheduleDate(job.getScheduleDate());
//            form.setCompleteDate(job.getCompleteDate());
//            if (job.getActivity_status().equals("N")) {
//                form.setFormStatus(DigitalFormActivity.INBOX);
//                DigitalFormActivity.INBOXFORMS.add(form);
//            }
                form.setFormStatus(DigitalFormActivity.INBOX);
                DigitalFormActivity.INBOXFORMS.add(form);
            }
        }
    }

    public static void populateSentJob(List<Job> jobs) {

        if ((jobs != null) && (jobs.size() > 0)) { //Exception : checking whether the iist is null or not
            Log.e(TAG, jobs.size() + "");
            DigitalFormActivity.SENTFORMS = new ArrayList<>();
            for (Job job : jobs) {
                Form form = new Form();
//            form.setJobLocation(job.getJob_location());
                form.setFormid(job.getJobId());
//            form.setFormStatus(job.getStatus());
                form.setJobDescription(job.getJobType().getName());
//            form.setProject(job.getProjectName());
                form.setClientName(job.getProject().getClient().getClientName());
//            form.setInspector(job.getInspector());
//            form.setScheduleDate(job.getScheduleDate());
//            form.setCompleteDate(job.getCompleteDate());
//            if (job.getActivity_status().equals("C")) {
//                form.setFormStatus(DigitalFormActivity.SENT);
//                DigitalFormActivity.SENTFORMS.add(form);
//            }
                form.setFormStatus(DigitalFormActivity.INBOX);
            }
        }
    }

    public static void getAllJobs(@NonNull final AppDatabase db, AppExecutors executors, Context context) {
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            DigitalFormActivity.ALLFORMS = database.formDao().getAllForms();
        });
    }

    public static void updateJob(@NonNull final AppDatabase db, AppExecutors executors, Context context, Form form) {
        if (form.getFormStatus().equals(DigitalFormActivity.DRAFT)) {
            APICalls.updateJobStatus(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, context, "updated", form.getFormid()+"");
        } else if (form.getFormStatus().equals(DigitalFormActivity.SENT)) {
            APICalls.updateJobStatus(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, context, "completed", form.getFormid()+"");
        }
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            if (database.formDao().getFormById(form.getFormid()) == null) {
                database.formDao().insertForm(form);
            } else {
                if (form.getFormStatus().equals(DigitalFormActivity.SENT)) {
                    database.formDao().deleteForm(form);
                } else {
                    database.formDao().updateForm(form);
                    Log.e(TAG, "DB updated : " + database.toString());
                }
            }
        });
    }

    public static void getSentJobs(@NonNull final AppDatabase db, AppExecutors executors, Context context) {
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            DigitalFormActivity.SENTFORMS = database.formDao().getSentForms();
            Log.e(TAG, "Get Sent Jobs : " + DigitalFormActivity.SENTFORMS.size());
    });
    }

//    public static void getInboxJobs(AppDatabase db, AppExecutors executors, Context context) {
//        executors.getDiskIO().execute(() -> {
//            // Add delay to simulate long running Action
//            // addDelay();
//            // Generate the data for pre-population
//            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
//            DigitalFormActivity.INBOXFORMS = database.formDao().getInboxForms();
//            Log.e(TAG, "Get Inbox Jobs : " + DigitalFormActivity.INBOXFORMS.size());
//        });
//    }

    public static void getDraftJobs(AppDatabase db, AppExecutors executors, Context context) {
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            DigitalFormActivity.DRAFTFORMS = database.formDao().getDraftForms();
            Log.e(TAG, "Get Draft Jobs : " + DigitalFormActivity.DRAFTFORMS.size());
        });
    }

    public static void getSyncJobs(AppDatabase db, AppExecutors executors, Context context) {
        executors.getDiskIO().execute(() -> {
            // Add delay to simulate long running Action
            // addDelay();
            // Generate the data for pre-population
            AppDatabase database = AppDatabase.getInstance(context.getApplicationContext());
            DigitalFormActivity.SYNCFORMS = database.formDao().getSyncForms();
            Log.e(TAG, "Get Sync Jobs : " + DigitalFormActivity.SYNCFORMS.size());
        });
    }

    private static void addDelay() {
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void populateWithTestData(AppDatabase db) {
        Form form = new Form();
        form.setFormid(1001);
        form.setClientName("Rajesh Sharma");
        form.setProject("Maintenance on building");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1002);
        form.setClientName("Vijay Gupta");
        form.setProject("Blockage in Water Supply");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1003);
        form.setClientName("Avinash Mehta");
        form.setProject("Monthly maintenance in Electricity wiring");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1004);
        form.setClientName("Dinesh Khemka");
        form.setProject("Glass door instalment");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1005);
        form.setClientName("Sumit Mandal");
        form.setProject("Lab Setup");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1006);
        form.setClientName("Amit Banerjee");
        form.setProject("Staircase Repairing");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1007);
        form.setClientName("Mayank Sharma");
        form.setProject("Drainage pipe Blockage");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1008);
        form.setClientName("Tapan Adhikary");
        form.setProject("Earthing Maintenance");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1009);
        form.setClientName("Suraj Gupta");
        form.setProject("Playground Maintenance");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);
        form = new Form();
        form.setFormid(1010);
        form.setClientName("Dilip Dasgupta");
        form.setProject("Community Hall Renovation");
        form.setFormStatus(DigitalFormActivity.INBOX);
        addForm(db, form);

        List<Form> forms = db.formDao().getAllForms();
        Log.e(DatabaseInitializer.TAG, "Rows Count : " + forms.size());
    }

    public static void addForm(AppDatabase db, final Form form) {
        db.runInTransaction(() -> {
            db.formDao().insertForm(form);
        });
    }
}
