package com.demo.cadena.tcil.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Job extends AuditModel {

    @SerializedName("jobId")
    @Expose
    private Integer jobId;
    @SerializedName("jobTitle")
    @Expose
    private String jobTitle;
    @SerializedName("project")
    @Expose
    private Project project;
    @SerializedName("jobType")
    @Expose
    private JobType jobType;
    @SerializedName("assignedTo")
    @Expose
    private AssignedTo assignedTo;
    @SerializedName("status")
    @Expose
    private String status;

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public String getJobTitle() {
        return this.jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public JobType getJobType() {
        return jobType;
    }

    public void setJobType(JobType jobType) {
        this.jobType = jobType;
    }

    public AssignedTo getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(AssignedTo assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
