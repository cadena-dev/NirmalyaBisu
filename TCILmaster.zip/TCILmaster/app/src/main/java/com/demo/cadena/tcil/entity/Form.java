package com.demo.cadena.tcil.entity;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.util.List;

@Entity (tableName = "forms")
public class Form {

    @PrimaryKey (autoGenerate = true)
    @ColumnInfo (name = "form_id")
    private int formid;

    @ColumnInfo (name = "job_id")
    private Long jobid;

    @ColumnInfo (name = "schedule_date_time")
    private String scheduleDate;

    @ColumnInfo (name = "complete_date_time")
    private String completeDate;

    @ColumnInfo (name = "inspector")
    private String inspector;

    @ColumnInfo (name = "client_name")
    private String clientName;

    @ColumnInfo (name = "project")
    private String project;

    @ColumnInfo (name = "job_location")
    private String jobLocation;

    @ColumnInfo (name = "engg_location")
    private String enggLocation = "";

    @ColumnInfo (name = "walked")
    private boolean walked = false;

    @ColumnInfo (name = "live_system")
    private boolean liveSystem = false;

    @ColumnInfo (name = "trained")
    private boolean trained = false;

    @ColumnInfo (name = "msds")
    private boolean msds = false;

    @ColumnInfo (name = "air_monitoring")
    private boolean airMonitoring = false;

    @ColumnInfo (name = "work_permit")
    private boolean workPermits = false;

    @ColumnInfo (name = "evatuation_routes")
    private boolean evacuationRoutes = false;

    @ColumnInfo (name = "ppe")
    private boolean ppe = false;

    @ColumnInfo (name = "image")
    private String image;

    @ColumnInfo (name = "image2")
    private String image2;

    @ColumnInfo (name = "image3")
    private String image3;

    @ColumnInfo (name = "form_image_comment")
    private String imageComment = "";

    @ColumnInfo (name = "form_image_comment_2")
    private String imageComment2 = "";

    @ColumnInfo (name = "form_image_comment_3")
    private String imageComment3 = "";

    @ColumnInfo (name = "image1_lat")
    private String image1Lat;

    @ColumnInfo (name = "image1_long")
    private String image1Long;

    @ColumnInfo (name = "image2_lat")
    private String image2Lat;

    @ColumnInfo (name = "image2_long")
    private String image2Long;

    @ColumnInfo (name = "image3_lat")
    private String image3Lat;

    @ColumnInfo (name = "image3_long")
    private String image3Long;

    @ColumnInfo (name = "image1_timestamp")
    private String image1Timestamp;

    @ColumnInfo (name = "image2_timestamp")
    private String image2Timestamp;

    @ColumnInfo (name = "image3_Timestamp")
    private String image3Timestamp;

    @ColumnInfo (name = "video_uri")
    private String videoURI;

    @ColumnInfo (name = "video_desc")
    private String videoDescription;

    @ColumnInfo (name = "scan_format")
    private String scanFormat;

    @ColumnInfo (name = "scan_content")
    private String scanContent;

    @ColumnInfo (name = "customer_name")
    private String customerName;

//    @ColumnInfo (name = "customer_sign", typeAffinity = ColumnInfo.BLOB)
//    private byte[] customerSignature;

    @ColumnInfo (name = "customer_sign")
    private String customerSignature;

    @ColumnInfo (name = "form_status")
    private String formStatus;

    @ColumnInfo (name = "form_description")
    private String jobDescription;

    @ColumnInfo (name = "well_trained")
    private float wellTrainedEngineer;

    @ColumnInfo (name = "well_supervised")
    private float wellSupervisedEngineer;

    @ColumnInfo (name = "professional_standard")
    private float professionalStandard;

    @ColumnInfo (name = "customer_satisfied")
    private float customerSatisfied;

    @ColumnInfo (name = "customer_comment")
    private String customerComment;

    /*Boundary Wall*/
    @ColumnInfo (name = "concrete_work_1_unit")
    private String concreteWork1Unit;

    @ColumnInfo (name = "sync")
    private boolean sync;

    @ColumnInfo (name = "files")
    private String files;

    public String getImage1Lat() {
        return image1Lat;
    }

    public void setImage1Lat(String image1Lat) {
        this.image1Lat = image1Lat;
    }

    public String getImage1Long() {
        return image1Long;
    }

    public void setImage1Long(String image1Long) {
        this.image1Long = image1Long;
    }

    public String getImage2Lat() {
        return image2Lat;
    }

    public void setImage2Lat(String image2Lat) {
        this.image2Lat = image2Lat;
    }

    public String getImage2Long() {
        return image2Long;
    }

    public void setImage2Long(String image2Long) {
        this.image2Long = image2Long;
    }

    public String getImage3Lat() {
        return image3Lat;
    }

    public void setImage3Lat(String image3Lat) {
        this.image3Lat = image3Lat;
    }

    public String getImage3Long() {
        return image3Long;
    }

    public void setImage3Long(String image3Long) {
        this.image3Long = image3Long;
    }

    public String getImageComment2() {
        return imageComment2;
    }

    public void setImageComment2(String imageComment2) {
        this.imageComment2 = imageComment2;
    }

    public String getImageComment3() {
        return imageComment3;
    }

    public void setImageComment3(String imageComment3) {
        this.imageComment3 = imageComment3;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }

    public String getImage1Timestamp() {
        return image1Timestamp;
    }

    public void setImage1Timestamp(String image1Timestamp) {
        this.image1Timestamp = image1Timestamp;
    }

    public String getImage2Timestamp() {
        return image2Timestamp;
    }

    public void setImage2Timestamp(String image2Timestamp) {
        this.image2Timestamp = image2Timestamp;
    }

    public String getImage3Timestamp() {
        return image3Timestamp;
    }

    public void setImage3Timestamp(String image3Timestamp) {
        this.image3Timestamp = image3Timestamp;
    }

    public String getFiles() {
        return files;
    }

    public void setFiles(String files) {
        this.files = files;
    }

    public boolean isSync() {
        return sync;
    }

    public void setSync(boolean sync) {
        this.sync = sync;
    }

    public String getConcreteWork1Unit(){return concreteWork1Unit;}
    public void setConcreteWork1Unit(String concreteWork1Unit)
    {
        this.concreteWork1Unit = concreteWork1Unit;
    }

    @ColumnInfo (name = "concrete_work_1_rate")
    private String concreteWork1Rate;

    public String getConcreteWork1Rate(){return concreteWork1Rate;}
    public void setConcreteWork1Rate(String concreteWork1Rate)
    {
        this.concreteWork1Rate = concreteWork1Rate;
    }

    @ColumnInfo (name = "concrete_work_1_no")
    private String concreteWork1No;

    public String getConcreteWork1No(){return concreteWork1No;}
    public void setConcreteWork1No(String concreteWork1No)
    {
        this.concreteWork1No = concreteWork1No;
    }

    @ColumnInfo (name = "concrete_work_1_L")
    private String concreteWork1L;

    public String getConcreteWork1L(){return concreteWork1L;}
    public void setConcreteWork1L(String concreteWork1L)
    {
        this.concreteWork1L = concreteWork1L;
    }

    @ColumnInfo (name = "concrete_work_1_B")
    private String concreteWork1B;

    public String getConcreteWork1B(){return concreteWork1B;}
    public void setConcreteWork1B(String concreteWork1B)
    {
        this.concreteWork1B = concreteWork1B;
    }

    @ColumnInfo (name = "concrete_work_1_H")
    private String concreteWork1H;

    public String getConcreteWork1H(){return concreteWork1H;}
    public void setConcreteWork1H(String concreteWork1H)
    {
        this.concreteWork1H = concreteWork1H;
    }

    @ColumnInfo (name = "concrete_work_3_unit")
    private String concreteWork3Unit;

    public String getConcreteWork3Unit(){return concreteWork3Unit;}
    public void setConcreteWork3Unit(String concreteWork3Unit)
    {
        this.concreteWork3Unit = concreteWork3Unit;
    }

    @ColumnInfo (name = "concrete_work_3_rate")
    private String concreteWork3Rate;

    public String getConcreteWork3Rate(){return concreteWork3Rate;}
    public void setConcreteWork3Rate(String concreteWork3Rate)
    {
        this.concreteWork3Rate = concreteWork3Rate;
    }

    @ColumnInfo (name = "concrete_work_3_no")
    private String concreteWork3No;

    public String getConcreteWork3No(){return concreteWork3No;}
    public void setConcreteWork3No(String concreteWork3No)
    {
        this.concreteWork3No = concreteWork3No;
    }

    @ColumnInfo (name = "concrete_work_3_L")
    private String concreteWork3L;

    public String getConcreteWork3L(){return concreteWork3L;}
    public void setConcreteWork3L(String concreteWork3L)
    {
        this.concreteWork3L = concreteWork3L;
    }

    @ColumnInfo (name = "concrete_work_3_B")
    private String concreteWork3B;

    public String getConcreteWork3B(){return concreteWork3B;}
    public void setConcreteWork3B(String concreteWork3B)
    {
        this.concreteWork3B = concreteWork3B;
    }

    @ColumnInfo (name = "concrete_work_3_H")
    private String concreteWork3H;

    public String getConcreteWork3H(){return concreteWork3H;}
    public void setConcreteWork3H(String concreteWork3H)
    {
        this.concreteWork3H = concreteWork3H;
    }

    public Long getJobid() {
        return jobid;
    }

    public void setJobid(Long jobid) {
        this.jobid = jobid;
    }

    public String getCustomerComment() {
        return customerComment;
    }

    public void setCustomerComment(String customerComment) {
        this.customerComment = customerComment;
    }

    public String getImageComment(){return imageComment;}

    public void setImageComment(String imageComment){
        this.imageComment = imageComment;
    }

    public float getWellTrainedEngineer() {
        return wellTrainedEngineer;
    }

    public void setWellTrainedEngineer(float wellTrainedEngineer) {
        this.wellTrainedEngineer = wellTrainedEngineer;
    }

    public float getWellSupervisedEngineer() {
        return wellSupervisedEngineer;
    }

    public void setWellSupervisedEngineer(float wellSupervisedEngineer) {
        this.wellSupervisedEngineer = wellSupervisedEngineer;
    }

    public float getProfessionalStandard() {
        return professionalStandard;
    }

    public void setProfessionalStandard(float professionalStandard) {
        this.professionalStandard = professionalStandard;
    }

    public float getCustomerSatisfied() {
        return customerSatisfied;
    }

    public void setCustomerSatisfied(float customerSatisfied) {
        this.customerSatisfied = customerSatisfied;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getFormStatus() {
        return formStatus;
    }

    public void setFormStatus(String formStatus) {
        this.formStatus = formStatus;
    }

    public int getFormid() {
        return formid;
    }

    public void setFormid(int formid) {
        this.formid = formid;
    }

    public String getInspector() {
        return inspector;
    }

    public void setInspector(String inspector) {
        this.inspector = inspector;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getJobLocation() {
        return jobLocation;
    }

    public void setJobLocation(String jobLocation) {
        this.jobLocation = jobLocation;
    }

    public boolean isWalked() {
        return walked;
    }

    public void setWalked(boolean walked) {
        this.walked = walked;
    }

    public boolean isLiveSystem() {
        return liveSystem;
    }

    public void setLiveSystem(boolean liveSystem) {
        this.liveSystem = liveSystem;
    }

    public boolean isTrained() {
        return trained;
    }

    public void setTrained(boolean trained) {
        this.trained = trained;
    }

    public boolean isMsds() {
        return msds;
    }

    public void setMsds(boolean msds) {
        this.msds = msds;
    }

    public boolean isAirMonitoring() {
        return airMonitoring;
    }

    public void setAirMonitoring(boolean airMonitoring) {
        this.airMonitoring = airMonitoring;
    }

    public boolean isWorkPermits() {
        return workPermits;
    }

    public void setWorkPermits(boolean workPermits) {
        this.workPermits = workPermits;
    }

    public boolean isEvacuationRoutes() {
        return evacuationRoutes;
    }

    public void setEvacuationRoutes(boolean evacuationRoutes) {
        this.evacuationRoutes = evacuationRoutes;
    }

    public boolean isPpe() {
        return ppe;
    }

    public void setPpe(boolean ppe) {
        this.ppe = ppe;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getScanFormat() {
        return scanFormat;
    }

    public void setScanFormat(String scanFormat) {
        this.scanFormat = scanFormat;
    }

    public String getScanContent() {
        return scanContent;
    }

    public void setScanContent(String scanContent) {
        this.scanContent = scanContent;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSignature() {
        return customerSignature;
    }

    public void setCustomerSignature(String customerSignature) {
        this.customerSignature = customerSignature;
    }

    public String getVideoURI() {
        return videoURI;
    }

    public void setVideoURI(String videoURI) {
        this.videoURI = videoURI;
    }

    public String getVideoDescription() {
        return videoDescription;
    }

    public void setVideoDescription(String videoDescription) {
        this.videoDescription = videoDescription;
    }

    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getCompleteDate() {
        return completeDate;
    }

    public void setCompleteDate(String completeDate) {
        this.completeDate = completeDate;
    }

    public String getEnggLocation() {
        return enggLocation;
    }

    public void setEnggLocation(String enggLocation) {
        this.enggLocation = enggLocation;
    }
}
