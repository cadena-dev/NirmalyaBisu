package com.demo.cadena.tcil.entity;

import java.util.Objects;
import java.math.BigDecimal;

/**
 * CumulativeJob
 */

public class CumulativeJob   {
  private String dsrNo = null;

  private String description = null;

  private BigDecimal estQuantity = null;

  private BigDecimal actQuantity = null;

  private BigDecimal rate = null;

  private BigDecimal amount = null;

  public CumulativeJob dsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
    return this;
  }

  /**
   * Get dsrNo
   * @return dsrNo
  **/


  public String getDsrNo() {
    return dsrNo;
  }

  public void setDsrNo(String dsrNo) {
    this.dsrNo = dsrNo;
  }

  public CumulativeJob description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
  **/


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public CumulativeJob estQuantity(BigDecimal estQuantity) {
    this.estQuantity = estQuantity;
    return this;
  }

  /**
   * Get estQuantity
   * @return estQuantity
  **/


  public BigDecimal getEstQuantity() {
    return estQuantity;
  }

  public void setEstQuantity(BigDecimal estQuantity) {
    this.estQuantity = estQuantity;
  }

  public CumulativeJob actQuantity(BigDecimal actQuantity) {
    this.actQuantity = actQuantity;
    return this;
  }

  /**
   * Get actQuantity
   * @return actQuantity
  **/


  public BigDecimal getActQuantity() {
    return actQuantity;
  }

  public void setActQuantity(BigDecimal actQuantity) {
    this.actQuantity = actQuantity;
  }

  public CumulativeJob rate(BigDecimal rate) {
    this.rate = rate;
    return this;
  }

  /**
   * Get rate
   * @return rate
  **/


  public BigDecimal getRate() {
    return rate;
  }

  public void setRate(BigDecimal rate) {
    this.rate = rate;
  }

  public CumulativeJob amount(BigDecimal amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Get amount
   * @return amount
  **/


  public BigDecimal getAmount() {
    return amount;
  }

  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CumulativeJob cumulativeJob = (CumulativeJob) o;
    return Objects.equals(this.dsrNo, cumulativeJob.dsrNo) &&
        Objects.equals(this.description, cumulativeJob.description) &&
        Objects.equals(this.estQuantity, cumulativeJob.estQuantity) &&
        Objects.equals(this.actQuantity, cumulativeJob.actQuantity) &&
        Objects.equals(this.rate, cumulativeJob.rate) &&
        Objects.equals(this.amount, cumulativeJob.amount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dsrNo, description, estQuantity, actQuantity, rate, amount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CumulativeJob {\n");
    
    sb.append("    dsrNo: ").append(toIndentedString(dsrNo)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    estQuantity: ").append(toIndentedString(estQuantity)).append("\n");
    sb.append("    actQuantity: ").append(toIndentedString(actQuantity)).append("\n");
    sb.append("    rate: ").append(toIndentedString(rate)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

