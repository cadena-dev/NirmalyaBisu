package com.demo.cadena.tcil.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.utils.DatabaseInitializer;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link JobDetailsTabFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class JobDetailsTabFragment extends Fragment implements LocationListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private MapView mapView;
    private GoogleMap googleMap;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    private double latitude;
    private double longitude;
    //TextView txtJobAdddress;
    TextView txtJobClientName;
    TextView txtJobTitle;
    TextView txtProjectTitle;
    TextView txtJobId;
    Button btnComplete;

    public static final String TAG = "JobTDetailsTab";


    public JobDetailsTabFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static JobDetailsTabFragment newInstance(String param1, String param2) {
        JobDetailsTabFragment fragment = new JobDetailsTabFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        mGoogleApiClient = new GoogleApiClient.Builder(getActivity().getApplicationContext())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    // ...
                }
            }

            ;
        };
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the

                    // contacts-related task you need to do.

                    Toast.makeText(getActivity(), "Location permission granted", Toast.LENGTH_LONG).show();

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                    Toast.makeText(getActivity(), "You need to grant permission", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_job_details_tab, container, false);

        initializeViews(view);

        loadDBData();

        btnComplete.setOnClickListener(this);

        mapView.onCreate(savedInstanceState);
        mapView.onResume();
        MapsInitializer.initialize(getActivity().getApplicationContext());

        return view;
    }

    private void initializeViews(View view) {
        //txtJobAdddress = (TextView) view.findViewById(R.id.details_job_address);
        txtJobId = (TextView) view.findViewById(R.id.details_job_id);
        mapView = (MapView) view.findViewById(R.id.details_job_mapview);
        txtJobClientName = (TextView) view.findViewById(R.id.details_client_name);
        txtJobTitle = (TextView) view.findViewById(R.id.details_job_title);
        txtProjectTitle = (TextView) view.findViewById(R.id.details_project_title);
        btnComplete = (Button) view.findViewById(R.id.btn_job_tab_complete);
    }

    private void loadDBData() {
        //Toast.makeText(getActivity(), "DB Data Loaded", Toast.LENGTH_LONG).show();
        txtJobId.setText(Integer.toString(DigitalFormActivity.SELECTEDFORM.getFormid()));
        txtJobClientName.setText(DigitalFormActivity.SELECTEDFORM.getClientName());
        txtJobTitle.setText(DigitalFormActivity.SELECTEDFORM.getJobDescription());
        txtProjectTitle.setText(DigitalFormActivity.SELECTEDFORM.getProject());
        //txtJobAdddress.setText(DigitalFormActivity.SELECTEDFORM.getJobLocation());
    }

    @Override
    public void onResume() {
        super.onResume();
        //mapView.onResume();
        mGoogleApiClient.connect();
    }

    @Override
    public void onPause() {
        super.onPause();
        //mapView.onPause();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }

//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mapView.onDestroy();
//    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


    @Override
    public void onLocationChanged(Location location) {

//        String lat = location.getLatitude() + " ";
//        String lon = location.getLongitude() + " ";
        //txtLon.setText(lon);
        //txtLat.setText(lat);
        //Toast.makeText(getContext(), "Lat : " + location.getLatitude() + ", Long : " + location.getLongitude(), Toast.LENGTH_LONG).show();
    }

    public void getLatLong () {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        } else {
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());
            Task<Location> location = mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location == null) {
                                startLocationUpdates();
                            } else {
                                //If everything went fine lets get latitude and longitude
                                latitude = location.getLatitude();
                                longitude = location.getLongitude();

                                //Toast.makeText(getContext(), latitude + " WORKS " + longitude + "", Toast.LENGTH_LONG).show();

                                mapView.getMapAsync(new OnMapReadyCallback() {
                                    @Override
                                    public void onMapReady(GoogleMap map) {
                                        googleMap = map;

//                                        LatLng jobAddr = new LatLng(22.6112, 88.3998);
//                                        googleMap.addMarker(new MarkerOptions().position(jobAddr).title("Job Location"));
//                                        LatLng jobAddr = DigitalFormActivity.SELECTEDFORM.getJobLocation();
//                                        googleMap.addMarker(new MarkerOptions().position())
                                        APICalls.getLatLong(ApiUtils.getMapService(), DigitalFormActivity.appExecutors, getContext(), DigitalFormActivity.SELECTEDFORM.getJobLocation(), false);

                                        LatLng loc = new LatLng(latitude, longitude);
                                        googleMap.addMarker(new MarkerOptions().position(loc).title("Current Location").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));

                                        CameraPosition cameraPosition = new CameraPosition.Builder().target(loc).zoom(12).build();
                                        googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                                    }
                                });

                                Geocoder geocoder;
                                geocoder = new Geocoder(getActivity(), Locale.getDefault());

                                try {
                                    List<Address> addresses;
                                    addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                                    String address = addresses.get(0).getAddressLine(0);
                                    Log.e(TAG, address);
                                    DigitalFormActivity.SELECTEDFORM.setEnggLocation(address);
                                    DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                                    DigitalFormActivity.initializeLists(getActivity());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });

        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        getLatLong();
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_job_tab_complete:
                if (isOnline()) {
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.SENT);
                    DigitalFormActivity.SELECTEDFORM.setSync(false);
                } else {
                    DigitalFormActivity.SELECTEDFORM.setFormStatus(DigitalFormActivity.DRAFT);
                    DigitalFormActivity.SELECTEDFORM.setSync(true);
                }

                DatabaseInitializer.updateJob(DigitalFormActivity.appDatabase, DigitalFormActivity.appExecutors, getActivity().getApplicationContext(), DigitalFormActivity.SELECTEDFORM);
                break;
        }
    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
}
