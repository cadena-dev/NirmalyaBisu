package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.DSRDetails;
import com.demo.cadena.tcil.entity.SteelReinforcement;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.FormService;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.math.BigDecimal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SteelReinforcementFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "SteelReinforcement";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    String str = "5.22.6 Reinforcement for R.C.C. work including straightening, cutting, bending, placing in position and binding all complete upto plinth level.; Thermo Mechanically Treated bars";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewSteelReinforcement;
    String percent = "100";
    Button btnCalculate;
    EditText edtNos;
    EditText edtBreadth;
    TextView txtQuantity;
    LinearLayout layoutSteelReinforcement;

    public SteelReinforcementFragment() {
        // Required empty public constructor
    }

    public static SteelReinforcementFragment newInstance(String param1, String param2) {
        SteelReinforcementFragment fragment = new SteelReinforcementFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_steel_reinforcement, container, false);
        edtNos = (EditText)view.findViewById(R.id.edtNos);
        edtBreadth = (EditText)view.findViewById(R.id.edtBreadth);
        txtQuantity = (TextView)view.findViewById(R.id.txtQuantity);
        layoutSteelReinforcement = (LinearLayout)view.findViewById(R.id.layoutSteelReinforcement);
        expandableTextViewSteelReinforcement = (com.ms.square.android.expandabletextview.ExpandableTextView) view.findViewById(R.id.expand_text_view_steel_reinforcement);
        expandableTextViewSteelReinforcement.setText(str);

        btnCalculate = (Button)view.findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNos.getText().toString().equals("") || edtBreadth.getText().toString().equals("")){
                    Toast.makeText(view.getContext(), "Please enter data in all fields !", Toast.LENGTH_LONG).show();
                }else{
                    Float surfaceArea = Float.parseFloat(edtNos.getText().toString()) * Float.parseFloat(edtBreadth.getText().toString());
                    txtQuantity.setText(surfaceArea.toString());
                    layoutSteelReinforcement.setVisibility(View.VISIBLE);
                }
                SteelReinforcement steelReinforcement = new SteelReinforcement();
                DSRDetails dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("5.22.6");
                steelReinforcement.setDsrNo(dsrDetails);

//                dsrDetails.setId(Long.parseLong(9+""));
//                steelReinforcement.setDsrNo(dsrDetails);
                steelReinforcement.setNoOfPillars(Integer.parseInt(edtNos.getText().toString()));
                steelReinforcement.setBredth(BigDecimal.valueOf(Double.parseDouble(edtBreadth.getText().toString())));
                steelReinforcement.setQuantity(BigDecimal.valueOf(Double.parseDouble(txtQuantity.getText().toString())));
                createSteelReinforcement(ApiUtils.getFormService(), DigitalFormActivity.appExecutors, steelReinforcement);
            }
        });
        return view;
    }

    private void createSteelReinforcement(FormService formService, AppExecutors appExecutors, SteelReinforcement steelReinforcement) {
        appExecutors.getNetworkIO().execute(() -> {
            formService.createSteelReinforcement(steelReinforcement, APICalls.setHeaders()).enqueue(new Callback<SteelReinforcement>() {
                @Override
                public void onResponse(Call<SteelReinforcement> call, Response<SteelReinforcement> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, response.toString());
                        updateActivityById(ApiUtils.getJobService(), appExecutors, DigitalFormActivity.SELECTEDFORM.getJobid()+"", response.body());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<SteelReinforcement> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    private void updateActivityById(JobsService jobService, AppExecutors appExecutors, String activityId, SteelReinforcement steelReinforcement) {
        appExecutors.getNetworkIO().execute(() -> {
            jobService.getActivityById(activityId, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Activity resActivity = response.body();
                        Log.e(TAG, resActivity.toString());
                        resActivity.setSteelReinforcement(steelReinforcement);
                        APICalls.updateActivity(jobService, appExecutors, resActivity);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
