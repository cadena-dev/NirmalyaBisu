package com.demo.cadena.tcil.entity;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * ConcreteWork
 */


public class ConcreteWork  extends AuditModel{

  private Long id = null;

  private DSRDetails dsrNo1 = null;

  private Integer nos1 = null;

  private BigDecimal length1 = null;

  private BigDecimal bredth1 = null;

  private BigDecimal height1 = null;

  private BigDecimal quantity1 = null;

  private DSRDetails dsrNo2 = null;

  private Integer nos2 = null;

  private BigDecimal length2 = null;

  private BigDecimal bredth2 = null;

  private BigDecimal height2 = null;

  private BigDecimal quantity2 = null;

  private DSRDetails dsrNo3 = null;

  private Integer nos3 = null;

  private BigDecimal vol = null;

  private BigDecimal quantity3 = null;

  public ConcreteWork id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ConcreteWork dsrNo1(DSRDetails dsrNo1) {
    this.dsrNo1 = dsrNo1;
    return this;
  }

  /**
   * Get dsrNo1
   * @return dsrNo1
  **/

  public DSRDetails getDsrNo1() {
    return dsrNo1;
  }

  public void setDsrNo1(DSRDetails dsrNo1) {
    this.dsrNo1 = dsrNo1;
  }

  public ConcreteWork nos1(Integer nos1) {
    this.nos1 = nos1;
    return this;
  }

  /**
   * Get nos1
   * @return nos1
  **/


  public Integer getNos1() {
    return nos1;
  }

  public void setNos1(Integer nos1) {
    this.nos1 = nos1;
  }

  public ConcreteWork length1(BigDecimal length1) {
    this.length1 = length1;
    return this;
  }

  /**
   * Get length1
   * @return length1
  **/

  public BigDecimal getLength1() {
    return length1;
  }

  public void setLength1(BigDecimal length1) {
    this.length1 = length1;
  }

  public ConcreteWork bredth1(BigDecimal bredth1) {
    this.bredth1 = bredth1;
    return this;
  }

  /**
   * Get bredth1
   * @return bredth1
  **/

  public BigDecimal getBredth1() {
    return bredth1;
  }

  public void setBredth1(BigDecimal bredth1) {
    this.bredth1 = bredth1;
  }

  public ConcreteWork height1(BigDecimal height1) {
    this.height1 = height1;
    return this;
  }

  /**
   * Get height1
   * @return height1
  **/

  public BigDecimal getHeight1() {
    return height1;
  }

  public void setHeight1(BigDecimal height1) {
    this.height1 = height1;
  }

  public ConcreteWork quantity1(BigDecimal quantity1) {
    this.quantity1 = quantity1;
    return this;
  }

  /**
   * Get quantity1
   * @return quantity1
  **/

  public BigDecimal getQuantity1() {
    return quantity1;
  }

  public void setQuantity1(BigDecimal quantity1) {
    this.quantity1 = quantity1;
  }

  public ConcreteWork dsrNo2(DSRDetails dsrNo2) {
    this.dsrNo2 = dsrNo2;
    return this;
  }

  /**
   * Get dsrNo2
   * @return dsrNo2
  **/


  public DSRDetails getDsrNo2() {
    return dsrNo2;
  }

  public void setDsrNo2(DSRDetails dsrNo2) {
    this.dsrNo2 = dsrNo2;
  }

  public ConcreteWork nos2(Integer nos2) {
    this.nos2 = nos2;
    return this;
  }

  /**
   * Get nos2
   * @return nos2
  **/

  public Integer getNos2() {
    return nos2;
  }

  public void setNos2(Integer nos2) {
    this.nos2 = nos2;
  }

  public ConcreteWork length2(BigDecimal length2) {
    this.length2 = length2;
    return this;
  }

  /**
   * Get length2
   * @return length2
  **/

  public BigDecimal getLength2() {
    return length2;
  }

  public void setLength2(BigDecimal length2) {
    this.length2 = length2;
  }

  public ConcreteWork bredth2(BigDecimal bredth2) {
    this.bredth2 = bredth2;
    return this;
  }

  /**
   * Get bredth2
   * @return bredth2
  **/

  public BigDecimal getBredth2() {
    return bredth2;
  }

  public void setBredth2(BigDecimal bredth2) {
    this.bredth2 = bredth2;
  }

  public ConcreteWork height2(BigDecimal height2) {
    this.height2 = height2;
    return this;
  }

  /**
   * Get height2
   * @return height2
  **/

  public BigDecimal getHeight2() {
    return height2;
  }

  public void setHeight2(BigDecimal height2) {
    this.height2 = height2;
  }

  public ConcreteWork quantity2(BigDecimal quantity2) {
    this.quantity2 = quantity2;
    return this;
  }

  /**
   * Get quantity2
   * @return quantity2
  **/

  public BigDecimal getQuantity2() {
    return quantity2;
  }

  public void setQuantity2(BigDecimal quantity2) {
    this.quantity2 = quantity2;
  }

  public ConcreteWork dsrNo3(DSRDetails dsrNo3) {
    this.dsrNo3 = dsrNo3;
    return this;
  }

  /**
   * Get dsrNo3
   * @return dsrNo3
  **/

  public DSRDetails getDsrNo3() {
    return dsrNo3;
  }

  public void setDsrNo3(DSRDetails dsrNo3) {
    this.dsrNo3 = dsrNo3;
  }

  public ConcreteWork nos3(Integer nos3) {
    this.nos3 = nos3;
    return this;
  }

  /**
   * Get nos3
   * @return nos3
  **/

  public Integer getNos3() {
    return nos3;
  }

  public void setNos3(Integer nos3) {
    this.nos3 = nos3;
  }

  public ConcreteWork vol(BigDecimal vol) {
    this.vol = vol;
    return this;
  }

  /**
   * Get vol
   * @return vol
  **/

  public BigDecimal getVol() {
    return vol;
  }

  public void setVol(BigDecimal vol) {
    this.vol = vol;
  }

  public ConcreteWork quantity3(BigDecimal quantity3) {
    this.quantity3 = quantity3;
    return this;
  }

  /**
   * Get quantity3
   * @return quantity3
  **/

  public BigDecimal getQuantity3() {
    return quantity3;
  }

  public void setQuantity3(BigDecimal quantity3) {
    this.quantity3 = quantity3;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConcreteWork concreteWork = (ConcreteWork) o;
    return Objects.equals(this.id, concreteWork.id) &&
        Objects.equals(this.dsrNo1, concreteWork.dsrNo1) &&
        Objects.equals(this.nos1, concreteWork.nos1) &&
        Objects.equals(this.length1, concreteWork.length1) &&
        Objects.equals(this.bredth1, concreteWork.bredth1) &&
        Objects.equals(this.height1, concreteWork.height1) &&
        Objects.equals(this.quantity1, concreteWork.quantity1) &&
        Objects.equals(this.dsrNo2, concreteWork.dsrNo2) &&
        Objects.equals(this.nos2, concreteWork.nos2) &&
        Objects.equals(this.length2, concreteWork.length2) &&
        Objects.equals(this.bredth2, concreteWork.bredth2) &&
        Objects.equals(this.height2, concreteWork.height2) &&
        Objects.equals(this.quantity2, concreteWork.quantity2) &&
        Objects.equals(this.dsrNo3, concreteWork.dsrNo3) &&
        Objects.equals(this.nos3, concreteWork.nos3) &&
        Objects.equals(this.vol, concreteWork.vol) &&
        Objects.equals(this.quantity3, concreteWork.quantity3);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, dsrNo1, nos1, length1, bredth1, height1, quantity1, dsrNo2, nos2, length2, bredth2, height2, quantity2, dsrNo3, nos3, vol, quantity3);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConcreteWork {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    dsrNo1: ").append(toIndentedString(dsrNo1)).append("\n");
    sb.append("    nos1: ").append(toIndentedString(nos1)).append("\n");
    sb.append("    length1: ").append(toIndentedString(length1)).append("\n");
    sb.append("    bredth1: ").append(toIndentedString(bredth1)).append("\n");
    sb.append("    height1: ").append(toIndentedString(height1)).append("\n");
    sb.append("    quantity1: ").append(toIndentedString(quantity1)).append("\n");
    sb.append("    dsrNo2: ").append(toIndentedString(dsrNo2)).append("\n");
    sb.append("    nos2: ").append(toIndentedString(nos2)).append("\n");
    sb.append("    length2: ").append(toIndentedString(length2)).append("\n");
    sb.append("    bredth2: ").append(toIndentedString(bredth2)).append("\n");
    sb.append("    height2: ").append(toIndentedString(height2)).append("\n");
    sb.append("    quantity2: ").append(toIndentedString(quantity2)).append("\n");
    sb.append("    dsrNo3: ").append(toIndentedString(dsrNo3)).append("\n");
    sb.append("    nos3: ").append(toIndentedString(nos3)).append("\n");
    sb.append("    vol: ").append(toIndentedString(vol)).append("\n");
    sb.append("    quantity3: ").append(toIndentedString(quantity3)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

