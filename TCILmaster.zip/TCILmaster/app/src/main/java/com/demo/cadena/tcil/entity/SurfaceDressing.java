package com.demo.cadena.tcil.entity;

import java.util.Objects;
import java.math.BigDecimal;

/**
 * SurfaceDressing
 */

public class SurfaceDressing extends AuditModel  {

  private Long id = null;

  private DSRDetails dsrNo = null;

  private BigDecimal length = null;

  private BigDecimal bredth = null;

  private BigDecimal quantity = null;

  public SurfaceDressing id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public SurfaceDressing dsrNo(DSRDetails dsrNo) {
    this.dsrNo = dsrNo;
    return this;
  }

  /**
   * Get dsrNo
   * @return dsrNo
  **/

  public DSRDetails getDsrNo() {
    return dsrNo;
  }

  public void setDsrNo(DSRDetails dsrNo) {
    this.dsrNo = dsrNo;
  }

  public SurfaceDressing length(BigDecimal length) {
    this.length = length;
    return this;
  }

  /**
   * Get length
   * @return length
  **/

  public BigDecimal getLength() {
    return length;
  }

  public void setLength(BigDecimal length) {
    this.length = length;
  }

  public SurfaceDressing bredth(BigDecimal bredth) {
    this.bredth = bredth;
    return this;
  }

  /**
   * Get bredth
   * @return bredth
  **/

  public BigDecimal getBredth() {
    return bredth;
  }

  public void setBredth(BigDecimal bredth) {
    this.bredth = bredth;
  }

  public SurfaceDressing quantity(BigDecimal quantity) {
    this.quantity = quantity;
    return this;
  }

  /**
   * Get quantity
   * @return quantity
  **/

  public BigDecimal getQuantity() {
    return quantity;
  }

  public void setQuantity(BigDecimal quantity) {
    this.quantity = quantity;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SurfaceDressing surfaceDressing = (SurfaceDressing) o;
    return Objects.equals(this.id, surfaceDressing.id) &&
        Objects.equals(this.dsrNo, surfaceDressing.dsrNo) &&
        Objects.equals(this.length, surfaceDressing.length) &&
        Objects.equals(this.bredth, surfaceDressing.bredth) &&
        Objects.equals(this.quantity, surfaceDressing.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, dsrNo, length, bredth, quantity);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SurfaceDressing {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    dsrNo: ").append(toIndentedString(dsrNo)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    bredth: ").append(toIndentedString(bredth)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

