package com.demo.cadena.tcil.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.activities.FormActivity;
import com.demo.cadena.tcil.activities.JobActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.fragments.MeasurmentBookFragment;

import java.util.ArrayList;
import java.util.List;


public class ActivityListAdapter extends RecyclerView.Adapter<ActivityListAdapter.ViewHolder> {

    private ArrayList<Activity> activities;
    private JobActivity mActivity;

    public ActivityListAdapter(ArrayList<Activity> as,android.app.Activity activity) {
        mActivity = (JobActivity) activity;
        activities = as;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_activity, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
if((activities!=null)&&(activities.size()>0)) { // Exception : checking the list is null or not.
    holder.txtActivityId.setText(Long.toString(activities.get(position).getActivityId()));
    Log.e("Activity Position", activities.get(position).toString());
    //holder.txtActivityStatus.setText(activities.get(position).getStatus().name());
    holder.txtActivityStartDate.setText(activities.get(position).getCreatedAt() + "");
    holder.txtActivityCompleteDate.setText(activities.get(position).getUpdatedAt() + "");

    holder.mView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//                Fragment fragment = new MeasurmentBookFragment();
            if(mActivity!=null) //Exception : check whether activity is null or not.
            mActivity.startActivity(new Intent(mActivity, FormActivity.class));
        }
    });
}
    }

    @Override
    public int getItemCount() {
        if((activities!=null)&&(activities.size()>0)) { // Exception : checking the list is null or not.
            return activities.size();
        }
        else
            return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        public final TextView txtActivityId;
        public final TextView txtActivityStatus;
        public final TextView txtActivityStartDate;
        public final TextView txtActivityCompleteDate;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txtActivityId = (TextView) view.findViewById(R.id.txt_activity_job_id);
            txtActivityStatus = (TextView) view.findViewById(R.id.txt_activity_status);
            txtActivityStartDate = (TextView) view.findViewById(R.id.txt_activity_start_date);
            txtActivityCompleteDate = (TextView) view.findViewById(R.id.txt_activity_complete_date);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + txtActivityId.getText() + "'";
        }
    }
}
