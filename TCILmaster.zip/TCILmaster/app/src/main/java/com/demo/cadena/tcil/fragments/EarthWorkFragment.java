package com.demo.cadena.tcil.fragments;

import android.app.job.JobService;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.DSRDetails;
import com.demo.cadena.tcil.entity.EarthWork;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.FormService;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.math.BigDecimal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EarthWorkFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private static final String TAG = "EarthWork";

    String str1 = "2.8 Earth work in excavation by manual means in foundation trenches or drains (not exceeding 1.5 m in width or 10 sqm on plan), including dressing of sides and ramming of bottoms, lift upto 1.5 m, including getting out the excavated soil and disposal of surplus excavated soil as directed, within a lead of 50 m.";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewOneEarthWork;
    Button btnCalculate;
    EditText edtEarthWorkTotalPillars;
    EditText edtL;
    EditText edtB;
    EditText edtH;
    //EditText edtEarthWorkBasicCalculation;
    TextView txtTotal;
    TextView txtOrdRockSecond;
    TextView txtHrdRockSecond;
    //TextView txtNetQuantity;
    TextView txtAllKindsOfSoilQty;
    LinearLayout layoutTotal;
    LinearLayout layoutOrdRockSecond;
    LinearLayout layoutHardRockSecond;
    LinearLayout layoutNetQty;
    Float total;
    Float OrdRock;
    Float NetQty;
    EditText edtOrdRockPercent;
    EditText edtHrdRockPercent;
    EditText edtAllKindsOfSoilPercent;
    String percent = "100";

    Float HrdRock;

    public EarthWorkFragment() {
        // Required empty public constructor
    }

    public static EarthWorkFragment newInstance(String param1, String param2) {
        EarthWorkFragment fragment = new EarthWorkFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        getActivityById(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getJobid()+"");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view;
        Log.e("EMP ID :", "Employee ID in Measurment Book : " + DigitalFormActivity.EMPLOYEE_ID);
        view = inflater.inflate(R.layout.fragment_earth_work, container, false);

        expandableTextViewOneEarthWork = (com.ms.square.android.expandabletextview.ExpandableTextView) view.findViewById(R.id.expand_text_view_one_earth_work);
        expandableTextViewOneEarthWork.setText(str1);

        edtEarthWorkTotalPillars = (EditText)view.findViewById(R.id.edtEarthWorkTotalPillars);
        edtL = (EditText)view.findViewById(R.id.edtL);
        edtB = (EditText)view.findViewById(R.id.edtB);
        edtH = (EditText)view.findViewById(R.id.edtH);
        //edtEarthWorkBasicCalculation = (EditText)view.findViewById(R.id.edtEarthWorkBasicCalculation);
        edtOrdRockPercent = (EditText)view.findViewById(R.id.edtEarthWorkOrdinaryRockPercent);
        edtHrdRockPercent = (EditText)view.findViewById(R.id.edtEarthWorkHardRockPercent);
        edtAllKindsOfSoilPercent = (EditText)view.findViewById(R.id.edtAllKindsOfSoilPercent);
        layoutTotal = (LinearLayout)view.findViewById(R.id.layoutTotal);
        layoutOrdRockSecond = (LinearLayout)view.findViewById(R.id.layoutOrdinaryRockSecond);
        layoutHardRockSecond = (LinearLayout)view.findViewById(R.id.layoutHardRockSecond);
        layoutNetQty = (LinearLayout)view.findViewById(R.id.layoutNetQty);

        txtTotal = (TextView)view.findViewById(R.id.txtTotal);
        txtOrdRockSecond = (TextView)view.findViewById(R.id.txtOrdRockSecond);
        txtHrdRockSecond = (TextView)view.findViewById(R.id.txtHrdRockSecond);
        txtAllKindsOfSoilQty = (TextView)view.findViewById(R.id.txtAllKindsOfSoilQty);

        btnCalculate = (Button)view.findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtEarthWorkTotalPillars.getText().toString().equals("") || edtL.getText().toString().equals("") || edtB.getText().toString().equals("") || edtH.getText().toString().equals("") || edtHrdRockPercent.getText().toString().equals("") || edtOrdRockPercent.getText().toString().equals("")){
                    Toast.makeText(view.getContext(), "Please enter data in all fields !", Toast.LENGTH_LONG).show();
                }
                else{
                    total = Float.parseFloat(edtEarthWorkTotalPillars.getText().toString()) * Float.parseFloat(edtL.getText().toString()) * Float.parseFloat(edtB.getText().toString()) * Float.parseFloat(edtH.getText().toString());
                    Float dummy1 = Float.parseFloat(edtOrdRockPercent.getText().toString())/Float.parseFloat(percent);
                    OrdRock = dummy1 * total;
                    Float dummy2 = Float.parseFloat(edtHrdRockPercent.getText().toString())/Float.parseFloat(percent);
                    HrdRock = dummy2 * total;
                    //NetQty = total - OrdRock - HrdRock;
                    Float dummy3 = Float.parseFloat(edtAllKindsOfSoilPercent.getText().toString())/Float.parseFloat(percent);
                    NetQty = dummy3 * total;
                    //Float surfaceArea = Float.parseFloat(edtEarthWorkBasicCalculation.getText().toString()) * Float.parseFloat(edtBSurface.getText().toString());
                    //txtSurfaceArea.setText(surfaceArea.toString());
                    txtTotal.setText(total.toString());
                    //txtLSurface.setText(edtEarthWorkBasicCalculation.getText().toString());
                    txtOrdRockSecond.setText(OrdRock.toString());
                    txtHrdRockSecond.setText(HrdRock.toString());
                    txtAllKindsOfSoilQty.setText(NetQty.toString());
                    layoutTotal.setVisibility(View.VISIBLE);
                    layoutOrdRockSecond.setVisibility(View.VISIBLE);
                    layoutHardRockSecond.setVisibility(View.VISIBLE);
                    layoutNetQty.setVisibility(View.VISIBLE);
                }
                EarthWork reqEarthWork = new EarthWork();
                DSRDetails dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("2.8.1");
                reqEarthWork.setDsrNo1(dsrDetails);
                dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("2.9.1");
                reqEarthWork.setDsrNo2(dsrDetails);
                dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("2.9.3");
                reqEarthWork.setDsrNo3(dsrDetails);

                reqEarthWork.setNoOfPillars(Integer.parseInt(edtEarthWorkTotalPillars.getText().toString()));
                reqEarthWork.setLength(BigDecimal.valueOf(Double.parseDouble(edtL.getText().toString())));
                reqEarthWork.setBredth(BigDecimal.valueOf(Double.parseDouble(edtB.getText().toString())));
                reqEarthWork.setHeight(BigDecimal.valueOf(Double.parseDouble(edtH.getText().toString())));
                reqEarthWork.setQuantity1(txtAllKindsOfSoilQty.getText().toString());
                reqEarthWork.setQuantity2(txtOrdRockSecond.getText().toString());
                reqEarthWork.setQuantity3(txtHrdRockSecond.getText().toString());
                createEarthWork(ApiUtils.getFormService(), DigitalFormActivity.appExecutors, reqEarthWork);
            }
        });

        // Inflate the layout for this fragment
        return view;

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void createEarthWork(FormService mService, AppExecutors executors, EarthWork earthWork) {
        executors.getNetworkIO().execute(() -> {
            mService.createEarthWork(earthWork, APICalls.setHeaders()).enqueue(new Callback<EarthWork>() {
                @Override
                public void onResponse(Call<EarthWork> call, Response<EarthWork> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, "Earth work created");
                        updateActivityById(ApiUtils.getJobService(), executors, DigitalFormActivity.SELECTEDFORM.getJobid()+"", response.body());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<EarthWork> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public void updateEarthWork(FormService mService, AppExecutors executors, EarthWork earthWork) {
        executors.getNetworkIO().execute(() -> {
            mService.updateEarthWork(earthWork, APICalls.setHeaders()).enqueue(new Callback<EarthWork>() {
                @Override
                public void onResponse(Call<EarthWork> call, Response<EarthWork> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, "Earth work updated");
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<EarthWork> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public void getEarthWorkById(FormService mService, AppExecutors executors, String id) {
        executors.getNetworkIO().execute(() -> {
            mService.getEarthWorkById(id, APICalls.setHeaders()).enqueue(new Callback<EarthWork>() {
                @Override
                public void onResponse(Call<EarthWork> call, Response<EarthWork> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        EarthWork resEarthWork = response.body();
                        edtH.setText(resEarthWork.getHeight()+"");
                        edtB.setText(resEarthWork.getBredth()+"");
                        edtL.setText(resEarthWork.getLength()+"");

                        edtEarthWorkTotalPillars.setText(resEarthWork.getLength()+"");
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<EarthWork> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public void updateActivityById(JobsService mService, AppExecutors executors, String activityId, EarthWork earthWork) {
        executors.getNetworkIO().execute(() -> {
            mService.getActivityById(activityId, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Activity resActivity = response.body();
                        Log.e(TAG, resActivity.toString());
                        resActivity.setEarthWork(earthWork);
                        APICalls.updateActivity(mService, executors, resActivity);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public void getActivityById(JobsService mService, AppExecutors executors, String activityId) {
        executors.getNetworkIO().execute(() -> {
            mService.getActivityById(activityId, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        if (response.body().getEarthWork() != null) {
                            getEarthWorkById(ApiUtils.getFormService(), executors, response.body().getEarthWork().getId()+"");
                        }
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

}
