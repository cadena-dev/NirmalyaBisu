package com.demo.cadena.tcil.retrofit;

import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.ConcreteWork;
import com.demo.cadena.tcil.entity.EarthWork;
import com.demo.cadena.tcil.entity.FencingWire;
import com.demo.cadena.tcil.entity.Job;
import com.demo.cadena.tcil.entity.SteelReinforcement;
import com.demo.cadena.tcil.entity.SurfaceDressing;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface FormService {

    @GET("earthwork/{earthWorkId}")
    Call<EarthWork> getEarthWorkById(
            @Path("earthWorkId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @GET("concretework/{concreteWorkId}")
    Call<ConcreteWork> getConcreteWorkById(
            @Path("concreteWorkId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @GET("fencing_wire/{fencingWireId}")
    Call<FencingWire> getFencingWireById(
            @Path("fencingWireId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @GET("steel_reinforcement/{steelReinforcementId}")
    Call<SteelReinforcement> getSteelReinforcementById(
            @Path("steelReinforcementId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @GET("surface_dressing/{surfaceDressingId}")
    Call<SurfaceDressing> getSurfaceDressingById(
            @Path("surfaceDressingId") String jobId,
            @HeaderMap Map<String, String> headers
    );

    @POST("earthwork")
    Call<EarthWork> createEarthWork(
            @Body EarthWork earthWork,
            @HeaderMap Map<String, String> headers
    );

    @POST("concretework")
    Call<ConcreteWork> createConcreteWork(
            @Body ConcreteWork concreteWork,
            @HeaderMap Map<String, String> headers
    );

    @POST("fencing_wire")
    Call<FencingWire> createFencingWire(
            @Body FencingWire fencingWire,
            @HeaderMap Map<String, String> headers
    );

    @POST("steel_reinforcement")
    Call<SteelReinforcement> createSteelReinforcement(
            @Body SteelReinforcement steelReinforcement,
            @HeaderMap Map<String, String> headers
    );

    @POST("surface_dressing")
    Call<SurfaceDressing> createSurfaceDressing(
            @Body SurfaceDressing surfaceDressing,
            @HeaderMap Map<String, String> headers
    );

    @PUT("earthwork")
    Call<EarthWork> updateEarthWork(
            @Body EarthWork earthWork,
            @HeaderMap Map<String, String> headers
    );

}
