package com.demo.cadena.tcil.retrofit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Suman on 08-03-2018.
 */

public class ApiUtils {

//    public static final String BASE_URL = "http://35.154.85.196:8080/FieldSurveyManagement/";
    public static final String JOB_URL = "http://ec2-13-233-124-222.ap-south-1.compute.amazonaws.com:8100/api/TCIL/job/";
    public static final String USER_URL = "http://ec2-13-233-124-222.ap-south-1.compute.amazonaws.com:8098/api/TCIL/";
    public static final String FORM_URL = "http://ec2-13-233-124-222.ap-south-1.compute.amazonaws.com:8101/api/TCIL/form/";

    private static Retrofit.Builder builder =
            new Retrofit.Builder()
                    .baseUrl(JOB_URL)
                    .addConverterFactory(GsonConverterFactory.create());

    private static Retrofit retrofit = builder.build();

    private static OkHttpClient.Builder httpClient =
            new OkHttpClient.Builder();

    public static <S> S createService(
            Class<S> serviceClass) {
        return retrofit.create(serviceClass);
    }

    public static JobsService getJobService() {
        return RetrofitClient.getClient(JOB_URL).create(JobsService.class);
    }

    public static UserService getUserService() {
        return RetrofitClient.getClient(USER_URL).create(UserService.class);
    }

    public static FormService getFormService() {
        return RetrofitClient.getClient(FORM_URL).create(FormService.class);
    }

    public static ItemsService getItemsService() {
        return RetrofitClient.getClient(USER_URL).create(ItemsService.class);
    }

    private static final String MAP_API = "https://maps.google.com/maps/api/geocode/json/";
    public static ItemsService getMapService() {
        return RetrofitClient.getClient(MAP_API).create(ItemsService.class);
    }

}
