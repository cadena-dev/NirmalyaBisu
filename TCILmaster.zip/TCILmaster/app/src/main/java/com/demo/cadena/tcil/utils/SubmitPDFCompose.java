package com.demo.cadena.tcil.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfDocument.PageInfo;
import android.graphics.pdf.PdfDocument.Page;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
import android.support.v4.widget.NestedScrollView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.retrofit.APICalls;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class SubmitPDFCompose {

    private static final String TAG = "SubmitPDF";

    public static void getSubmitPDF (Activity activity) {

        // create a new document
        PdfDocument pdfDocument = new PdfDocument();

        // crate a page description
        PageInfo pageInfo = new PageInfo.Builder(1200, 2500, 1).create();

        // start a page
        Page page = pdfDocument.startPage(pageInfo);

        // draw something on the page
//        String screenshot = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL" + "/FormImg.png";
//        View u = activity.findViewById(R.id.sent_scroll);
//        NestedScrollView z = (NestedScrollView) activity.findViewById(R.id.sent_scroll); // parent view
//        int totalHeight = z.getChildAt(0).getHeight();// parent view height
//        int totalWidth = z.getChildAt(0).getWidth();// parent view width
//        File imgFile = new File(screenshot);
//        Bitmap b = activity.get

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
//        canvas.drawPaint(paint);
        paint.setColor(Color.BLACK);
        paint.setTextSize(20);
        String emailBody = "DOCUMENTATION AND MEMOS";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="=========================================================================";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 50);
        paint.setTextSize(15);
        emailBody = "SITE INFORMATION DETAIL";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="===============================================";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="Job Id : "+ Integer.toString(DigitalFormActivity.SELECTEDFORM.getFormid());
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="Client Name : "+ DigitalFormActivity.SELECTEDFORM.getClientName();
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="Job Title : "+DigitalFormActivity.SELECTEDFORM.getProject();
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
//        if(DigitalFormActivity.SELECTEDFORM.getJobDescription() != null){
//            emailBody = "Description : "+DigitalFormActivity.SELECTEDFORM.getJobDescription();
//        }else {
//            emailBody ="Description : "+" ";
//        }
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        if(DigitalFormActivity.SELECTEDFORM.getInspector() != null) {
//            emailBody ="Inspector : " + DigitalFormActivity.SELECTEDFORM.getInspector();
//        }else {
//            emailBody ="Inspector : "+" ";
//        }
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getJobLocation() != null) {
            emailBody = "Job Location : " + DigitalFormActivity.SELECTEDFORM.getJobLocation();
        }else
        {
            emailBody ="Job Location : "+" ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        canvas.drawText("", 50,50, paint);
        canvas.translate(0, 20);
//        emailBody ="EVALUATING YOUR WORK AREA";
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="===============================================";
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Do you have appropriate labor license? : "+DigitalFormActivity.SELECTEDFORM.isWalked();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Do you have certified labor resources? : "+DigitalFormActivity.SELECTEDFORM.isLiveSystem();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Do you have any site access hours? : "+DigitalFormActivity.SELECTEDFORM.isTrained();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Hazardous material facility? : "+DigitalFormActivity.SELECTEDFORM.isMsds();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Any specific truck capacity? : "+DigitalFormActivity.SELECTEDFORM.isAirMonitoring();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="Do workers have the necessary tools and equipments to get the jobs completed on schedule, avoiding cost overruns and penalties? : "+DigitalFormActivity.SELECTEDFORM.isWorkPermits();
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        canvas.drawText("", 50,50, paint);
//        canvas.translate(0, 20);
        emailBody ="PICTURES";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="===============================================";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody ="IMAGE 1 DETAILS : ";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if (DigitalFormActivity.SELECTEDFORM.getImage() != null) {
            Uri imageUri = Uri.parse(DigitalFormActivity.SELECTEDFORM.getImage());
            File file = new File(imageUri.getPath());
            try {
                InputStream ims = new FileInputStream(file);
                Bitmap imageBitmap = BitmapFactory.decodeStream(ims);
//                  canvas.drawBitmap(imageBitmap, 50, 50, null);
                canvas.drawBitmap(imageBitmap, null, new Rect(50, 50, 400, 400), null);
                canvas.translate(0, 400+20);
            } catch (FileNotFoundException e) {
                return;
            }

        }
        if(DigitalFormActivity.SELECTEDFORM.getImageComment() != null){
            emailBody ="Comment : "+DigitalFormActivity.SELECTEDFORM.getImageComment();
        }else {
            emailBody ="Comment : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage1Lat() != null && DigitalFormActivity.SELECTEDFORM.getImage1Long() != null){
            emailBody ="Lat-Lon : "+DigitalFormActivity.SELECTEDFORM.getImage1Lat()+" , "+DigitalFormActivity.SELECTEDFORM.getImage1Long();
        }else {
            emailBody ="Lat-Lon : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage1Timestamp() != null){
            emailBody ="Timestamp : "+DigitalFormActivity.SELECTEDFORM.getImage1Timestamp();
        }else {
            emailBody ="Timestamp : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        canvas.drawText("", 50,50, paint);
        canvas.translate(0, 20);

        emailBody ="IMAGE 2 DETAILS : ";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if (DigitalFormActivity.SELECTEDFORM.getImage2() != null) {
            Bitmap imageBitmap = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getImage2());
//        canvas.drawBitmap(imageBitmap, 50, 50, null);
            canvas.drawBitmap(imageBitmap, null, new Rect(50, 50, 400, 400), null);
            canvas.translate(0, 400+20);
        }
        if(DigitalFormActivity.SELECTEDFORM.getImageComment2() != null){
            emailBody ="Comment : "+DigitalFormActivity.SELECTEDFORM.getImageComment2();
        }else {
            emailBody ="Comment : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage2Lat() != null && DigitalFormActivity.SELECTEDFORM.getImage2Long() != null){
            emailBody ="Lat-Lon : "+DigitalFormActivity.SELECTEDFORM.getImage2Lat()+" , "+DigitalFormActivity.SELECTEDFORM.getImage2Long();
        }else {
            emailBody ="Lat-Lon : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage2Timestamp() != null){
            emailBody ="Timestamp : "+DigitalFormActivity.SELECTEDFORM.getImage2Timestamp();
        }else {
            emailBody ="Timestamp : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        canvas.drawText("", 50,50, paint);
        canvas.translate(0, 20);

        emailBody ="IMAGE 3 DETAILS : ";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if (DigitalFormActivity.SELECTEDFORM.getImage3() != null) {
            Bitmap imageBitmap = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getImage3());
//        canvas.drawBitmap(imageBitmap, 50, 50, null);
            canvas.drawBitmap(imageBitmap, null, new Rect(50, 50, 400, 400), null);
            canvas.translate(0, 400+20);
        }
        if(DigitalFormActivity.SELECTEDFORM.getImageComment3() != null){
            emailBody ="Comment : "+DigitalFormActivity.SELECTEDFORM.getImageComment3();
        }else {
            emailBody ="Comment : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage3Lat() != null && DigitalFormActivity.SELECTEDFORM.getImage3Long() != null){
            emailBody ="Lat-Lon : "+DigitalFormActivity.SELECTEDFORM.getImage3Lat()+" , "+DigitalFormActivity.SELECTEDFORM.getImage3Long();
        }else {
            emailBody ="Lat-Lon : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getImage1Timestamp() != null){
            emailBody ="Timestamp : "+DigitalFormActivity.SELECTEDFORM.getImage3Timestamp();
        }else {
            emailBody ="Timestamp : " + " ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        canvas.drawText("", 50,50, paint);
        canvas.translate(0, 20);
//        emailBody="EQUIPMENT DETAILS";
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        emailBody="===============================================";
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        if(DigitalFormActivity.SELECTEDFORM.getScanContent() != null){
//            emailBody ="Barcode / QR Value : "+DigitalFormActivity.SELECTEDFORM.getScanContent();
//        }else {
//            emailBody ="Barcode / QR Value : " + " ";
//        }
//        canvas.drawText(emailBody, 50,50, paint);
//        canvas.translate(0, 20);
//        canvas.drawText("", 50,50, paint);
//        canvas.translate(0, 20);
        emailBody ="SIGN OFF";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        emailBody="===============================================";
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getCustomerComment() != null){
            emailBody="Comment : "+DigitalFormActivity.SELECTEDFORM.getCustomerComment();
        }else {
            emailBody="Comment : "+" ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if(DigitalFormActivity.SELECTEDFORM.getCustomerName() != null){
            emailBody="Engineer Name : "+DigitalFormActivity.SELECTEDFORM.getCustomerName();
        }else {
            emailBody="Engineer Name : "+" ";
        }
        canvas.drawText(emailBody, 50,50, paint);
        canvas.translate(0, 20);
        if (DigitalFormActivity.SELECTEDFORM.getCustomerSignature() != null) {
            Bitmap imageBitmap = BitmapFactory.decodeFile(DigitalFormActivity.SELECTEDFORM.getCustomerSignature());
//            canvas.drawBitmap(imageBitmap, 50, 50, null);
            canvas.drawBitmap(imageBitmap, null, new Rect(50, 50, 200, 200), null);
            canvas.translate(0, imageBitmap.getHeight()+20);
        }


//        View view = View.inflate(activity, R.layout.fragment_sent_job_details, null); // LayoutInflater.from(activity).inflate(R.layout.fragment_sent_job_details, null);
//        view.draw(page.getCanvas());

        // finish the page
        pdfDocument.finishPage(page);

        // write the document content
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TCIL" + "/Form" + DigitalFormActivity.SELECTEDFORM.getFormid() + ".pdf";
        Log.e(TAG, "PDF Path : " + path);
        File file = new File(path);
        try {
            pdfDocument.writeTo(new FileOutputStream(file));
            Log.e(TAG, "PDF Created");
            Toast.makeText(activity, "PDF created", Toast.LENGTH_LONG).show();
            APICalls.uploadFile(DigitalFormActivity.mService, DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getFormid(), file);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(activity, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show();
        }

        // close the document
        pdfDocument.close();

    }

}