package com.demo.cadena.tcil.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.Activity;
import com.demo.cadena.tcil.entity.DSRDetails;
import com.demo.cadena.tcil.entity.FencingWire;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.FormService;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.math.BigDecimal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FencingWireFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "FencingWire";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    String str = "16.17.1 Fencing with R.C.C. post placed at required distance, embedded in cement concrete blocks, every 15th post, last but one end post and corner post shall be strutted on both sides and end post one side only, provided with horizontal lines and two diagonals of barbed wire weighing 9.38 kg per 100 metres (minimum), between the two posts fitted and fixed with G.I. staples on wooden plugs or G.I. binding wire tied to 6 mm bar nibs fixed while casting the post (cost of R.C.C. posts, struts, earth work and concrete to be paid for separately) :- Payment to be made per metre cost of total length of barbed wire used : With G.I. Barbed Wire";
    private com.ms.square.android.expandabletextview.ExpandableTextView expandableTextViewSteelReinforcement;
    String percent = "100";
    Button btnCalculate;

    EditText edtFencingWireTotalPillars;
    EditText edtFencingWireLength;
    EditText edtFencingWirePercentage;
    LinearLayout layoutFencingWire;
    TextView txtQuantity;

    public FencingWireFragment() {
        // Required empty public constructor
    }

    public static FencingWireFragment newInstance(String param1, String param2) {
        FencingWireFragment fragment = new FencingWireFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_fencing_wire, container, false);

        edtFencingWireTotalPillars = (EditText)view.findViewById(R.id.edtNos);
        edtFencingWirePercentage = (EditText)view.findViewById(R.id.edtFencingWirePercent);
        edtFencingWireLength = (EditText)view.findViewById(R.id.edtLength);
        txtQuantity = (TextView)view.findViewById(R.id.txtQuantity);
        layoutFencingWire = (LinearLayout) view.findViewById(R.id.layoutFencingWire);

        btnCalculate = (Button)view.findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtFencingWireTotalPillars.getText().toString().equals("") || edtFencingWirePercentage.getText().toString().equals("") ||  edtFencingWireLength.getText().toString().equals("")){
                    Toast.makeText(view.getContext(), "Please enter data in all fields !", Toast.LENGTH_LONG).show();
                }else{
                    Float dummy = Float.parseFloat(edtFencingWirePercentage.getText().toString()) / Float.parseFloat(percent);
                    Float quantity = Float.parseFloat(edtFencingWireTotalPillars.getText().toString()) * dummy * Float.parseFloat(edtFencingWireLength.getText().toString());
                    txtQuantity.setText(quantity.toString());
                    layoutFencingWire.setVisibility(View.VISIBLE);
                }
                FencingWire fencingWire = new FencingWire();
                DSRDetails dsrDetails = new DSRDetails();
                dsrDetails.setDsrNo("16.17.1");
                fencingWire.setDsrNo(dsrDetails);

//                dsrDetails.setId(Long.parseLong(15+""));
//                fencingWire.setDsrNo(dsrDetails);
                fencingWire.setLength(BigDecimal.valueOf(Double.parseDouble(edtFencingWireLength.getText().toString())));
                fencingWire.setNoOfPillars(Integer.parseInt(edtFencingWireTotalPillars.getText().toString()));
                fencingWire.setQuantity(BigDecimal.valueOf(Double.parseDouble(txtQuantity.getText().toString())));
                createFencingWire(ApiUtils.getFormService(), DigitalFormActivity.appExecutors, fencingWire);
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

    private void createFencingWire(FormService formService, AppExecutors appExecutors, FencingWire fencingWire) {
        appExecutors.getNetworkIO().execute(() -> {
            formService.createFencingWire(fencingWire, APICalls.setHeaders()).enqueue(new Callback<FencingWire>() {
                @Override
                public void onResponse(Call<FencingWire> call, Response<FencingWire> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==201) {
                        Log.e(TAG, response.toString());
                        updateActivityById(ApiUtils.getJobService(), appExecutors, DigitalFormActivity.SELECTEDFORM.getJobid()+"", response.body());
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.raw());
                    }
                }

                @Override
                public void onFailure(Call<FencingWire> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    private void updateActivityById(JobsService jobService, AppExecutors appExecutors, String activityId, FencingWire fencingWire) {
        appExecutors.getNetworkIO().execute(() -> {
            jobService.getActivityById(activityId, APICalls.setHeaders()).enqueue(new Callback<Activity>() {
                @Override
                public void onResponse(Call<Activity> call, Response<Activity> response) {
                    Log.e(TAG, call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Activity resActivity = response.body();
                        Log.e(TAG, resActivity.toString());
                        resActivity.setFencingWire(fencingWire);
                        APICalls.updateActivity(jobService, appExecutors, resActivity);
                    } else {
                        int statusCode = response.code();
                        Log.e(TAG, "Status Code : " + statusCode + "; Error : " + response.errorBody());
                    }
                }

                @Override
                public void onFailure(Call<Activity> call, Throwable t) {
                    Log.e(TAG, "Error during API call" + call.request().url() + " : " + t);
                }
            });
        });
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
