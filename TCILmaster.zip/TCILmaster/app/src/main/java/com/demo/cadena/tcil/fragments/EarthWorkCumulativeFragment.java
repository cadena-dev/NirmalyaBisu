package com.demo.cadena.tcil.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.activities.DigitalFormActivity;
import com.demo.cadena.tcil.entity.CumulativeJob;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;
import com.demo.cadena.tcil.retrofit.JobsService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link EarthWorkCumulativeFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link EarthWorkCumulativeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EarthWorkCumulativeFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    TextView cumEWdsr1;
    TextView cumEWdsr2;
    TextView cumEWdsr3;
    TextView cumEWquantity1;
    TextView cumEWquantity2;
    TextView cumEWquantity3;
    View view;

    public EarthWorkCumulativeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EarthWorkCumulativeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static EarthWorkCumulativeFragment newInstance(String param1, String param2) {
        EarthWorkCumulativeFragment fragment = new EarthWorkCumulativeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        getCumulativeByJob(ApiUtils.getJobService(), DigitalFormActivity.appExecutors, DigitalFormActivity.SELECTEDFORM.getFormid()+"");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_earth_work_cumulative, container, false);

        cumEWdsr1 = (TextView)view.findViewById(R.id.cumEWdsr1);
        cumEWdsr2 = (TextView)view.findViewById(R.id.cumEWdsr2);
        cumEWdsr3 = (TextView)view.findViewById(R.id.cumEWdsr3);
        cumEWquantity1 = (TextView)view.findViewById(R.id.cumEWquantity1);
        cumEWquantity2 = (TextView)view.findViewById(R.id.cumEWquantity2);
        cumEWquantity3 = (TextView)view.findViewById(R.id.cumEWquantity3);
        return view;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void getCumulativeByJob(JobsService mService, AppExecutors executors, String jobId) {
        executors.getNetworkIO().execute(() -> {
            mService.getJobCumulative(jobId, APICalls.setHeaders(DigitalFormActivity.sharedPreferences)).enqueue(new Callback<List<CumulativeJob>>() {
                @Override
                public void onResponse(Call<List<CumulativeJob>> call, Response<List<CumulativeJob>> response) {
                    Log.e("Call Request", call.request().url().toString());
                    if (response.isSuccessful() && response.code()==200) {
                        Log.e("Response", response.body()+"");
                        List<CumulativeJob> cumulativeJobs = response.body();
                        if (cumulativeJobs.isEmpty()){
                            //Toast.makeText(view.getContext(), "No Data to be fetched !", Toast.LENGTH_LONG).show();
                        }else{
                            if(cumulativeJobs.get(0) == null){
                                cumEWdsr1.setText("0");
                                cumEWquantity1.setText("0");
                            }else{
                                cumEWdsr1.setText(cumulativeJobs.get(0).getDsrNo().toString());
                                String quanitity1 = String.format("%.2f", cumulativeJobs.get(0).getActQuantity());
                                cumEWquantity1.setText(quanitity1);
                                //cumEWquantity1.setText(cumulativeJobs.get(0).getActQuantity().toString());
                            }

                            if (cumulativeJobs.get(1) == null){
                                cumEWdsr2.setText("0");
                                cumEWquantity2.setText("0");
                            }else{
                                cumEWdsr2.setText(cumulativeJobs.get(1).getDsrNo().toString());
                                String quantity2 = String.format("%.2f", cumulativeJobs.get(1).getActQuantity());
                                cumEWquantity2.setText(quantity2);
                                //cumEWquantity2.setText(cumulativeJobs.get(1).getActQuantity().toString());
                            }

                            if(cumulativeJobs.get(2) == null){
                                cumEWdsr3.setText("0");
                                cumEWquantity3.setText("0");
                            }else{
                                cumEWdsr3.setText(cumulativeJobs.get(2).getDsrNo().toString());
                                String quantity3 = String.format("%.2f", cumulativeJobs.get(2).getActQuantity());
                                cumEWquantity3.setText(quantity3);
                                //cumEWquantity3.setText(cumulativeJobs.get(2).getActQuantity().toString());
                            }

                        }
                    } else {
                        int statusCode = response.code();
                        Log.e("Status Code", "Status Code : " + statusCode + "; Error : " + response.errorBody());
                        //Toast.makeText(view.getContext(), "No Data to be fetched !", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<List<CumulativeJob>> call, Throwable t) {
                    Log.e("Error", "Error during API call" + call.toString() + t);
                }
            });
        });
    }
}
