package com.demo.cadena.tcil.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.demo.cadena.tcil.R;
import com.demo.cadena.tcil.executor.AppExecutors;
import com.demo.cadena.tcil.fragments.MeasurmentBookFragment;
import com.demo.cadena.tcil.retrofit.APICalls;
import com.demo.cadena.tcil.retrofit.ApiUtils;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    public EditText inputUsername;
    public EditText inputPassword;
    public AppCompatButton btnLogin;

    public static SharedPreferences sharedPreferences;

    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inputUsername = (EditText) findViewById(R.id.input_username);
        inputPassword = (EditText) findViewById(R.id.input_password);
        btnLogin = (AppCompatButton) findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(this);

//        btnLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (inputUsername.getText().toString() == "user1" && inputPassword.getText().toString() == "user1") {
//                    Intent intent = new Intent(LoginActivity.this, DigitalFormActivity.class);
//                    startActivity(intent);
//                }
//                else{
//                    Toast.makeText(getApplicationContext(),"Incorrect Username or Password !",Toast.LENGTH_LONG).show();
//                }
//            }
//        });

        sharedPreferences = getPreferences(MODE_PRIVATE);
        String jwtToken = sharedPreferences.getString(getString(R.string.jwtToken), null);
        Log.e(TAG, "JWT Token in Login : " + jwtToken);
        jwtToken = sharedPreferences.getString(getString(R.string.jwtToken), null);
        DigitalFormActivity.EMPLOYEE_ID = sharedPreferences.getString(getString(R.string.employee_id), null);
//        DigitalFormActivity.EMPLOYEE_ID = "1234";
        if (jwtToken != null) {
              Intent intent = new Intent(LoginActivity.this, DigitalFormActivity.class);
              startActivity(intent);
        }

    }

    @Override
    public void onClick(View v) {
//        APICalls.loginUserWithNetwork(ApiUtils.getItemsService(), new AppExecutors(), this, inputUsername.getText().toString(), inputPassword.getText().toString());
        APICalls.login(ApiUtils.getUserService(), new AppExecutors(), this, inputUsername.getText().toString(), inputPassword.getText().toString());
//        String username = inputUsername.getText().toString();
//        String password = inputPassword.getText().toString();
//        if (username.contentEquals("user1") && password.contentEquals("user1")) {
//            Intent intent = new Intent(LoginActivity.this, DigitalFormActivity.class);
//            startActivity(intent);
//        }
//        else if(username.contentEquals("user2") && password.contentEquals("user2")){
//            Intent intent = new Intent(LoginActivity.this, DigitalFormActivity.class);
//            startActivity(intent);
//        }
//        else{
//            Toast.makeText(getApplicationContext(),"Incorrect Username or Password !",Toast.LENGTH_LONG).show();
//        }
    }
}
